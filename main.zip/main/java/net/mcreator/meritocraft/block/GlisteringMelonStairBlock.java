package net.mcreator.meritocraft.block;

import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Blocks;

public class GlisteringMelonStairBlock extends StairBlock {
	public GlisteringMelonStairBlock(BlockBehaviour.Properties properties) {
		super(Blocks.AIR.defaultBlockState(),
				properties.sound(SoundType.WOOD).strength(1.2f, 10f).lightLevel(blockstate -> 7).speedFactor(1.2f).jumpFactor(1.2f).noOcclusion().isRedstoneConductor((bs, br, bp) -> false).instrument(NoteBlockInstrument.BASS));
	}

	@Override
	public float getExplosionResistance() {
		return 10f;
	}
}