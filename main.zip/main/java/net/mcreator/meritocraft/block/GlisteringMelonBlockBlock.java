package net.mcreator.meritocraft.block;

import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;

public class GlisteringMelonBlockBlock extends Block {
	public GlisteringMelonBlockBlock(BlockBehaviour.Properties properties) {
		super(properties.sound(SoundType.WOOD).strength(1.2f, 10f).lightLevel(blockstate -> 7).speedFactor(1.2f).jumpFactor(1.2f).instrument(NoteBlockInstrument.BASS));
	}
}