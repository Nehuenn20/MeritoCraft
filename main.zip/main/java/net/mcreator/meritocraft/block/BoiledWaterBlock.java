package net.mcreator.meritocraft.block;

import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.Level;
import net.minecraft.core.BlockPos;

import net.mcreator.meritocraft.procedures.BoiledWaterTransformProcedure;
import net.mcreator.meritocraft.init.MeritocraftModFluids;

public class BoiledWaterBlock extends LiquidBlock {
	public BoiledWaterBlock(BlockBehaviour.Properties properties) {
		super(MeritocraftModFluids.BOILED_WATER.get(), properties.mapColor(MapColor.WATER).strength(100f).noCollission().noLootTable().liquid().pushReaction(PushReaction.DESTROY).sound(SoundType.EMPTY).replaceable());
	}

	@Override
	public void onPlace(BlockState blockstate, Level world, BlockPos pos, BlockState oldState, boolean moving) {
		super.onPlace(blockstate, world, pos, oldState, moving);
		BoiledWaterTransformProcedure.execute(world, pos.getX(), pos.getY(), pos.getZ());
	}
}