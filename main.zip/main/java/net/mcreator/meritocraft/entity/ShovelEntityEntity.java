package net.mcreator.meritocraft.entity;

import net.neoforged.neoforge.fluids.FluidType;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.*;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.Difficulty;
import net.minecraft.util.RandomSource;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.BlockPos;

import net.mcreator.meritocraft.procedures.*;
import net.mcreator.meritocraft.init.MeritocraftModEntities;

import javax.annotation.Nullable;

import java.util.EnumSet;

public class ShovelEntityEntity extends Monster {
	public static final EntityDataAccessor<Integer> DATA_actionState = SynchedEntityData.defineId(ShovelEntityEntity.class, EntityDataSerializers.INT);
	public static final EntityDataAccessor<Integer> DATA_type = SynchedEntityData.defineId(ShovelEntityEntity.class, EntityDataSerializers.INT);
	public final AnimationState animationState0 = new AnimationState();

	public ShovelEntityEntity(EntityType<ShovelEntityEntity> type, Level world) {
		super(type, world);
		xpReward = 0;
		setNoAi(false);
		this.moveControl = new FlyingMoveControl(this, 10, true);
	}

	@Override
	protected void defineSynchedData(SynchedEntityData.Builder builder) {
		super.defineSynchedData(builder);
		builder.define(DATA_actionState, 0);
		builder.define(DATA_type, 0);
	}

	@Override
	protected PathNavigation createNavigation(Level world) {
		return new FlyingPathNavigation(this, world);
	}

	@Override
	protected void registerGoals() {
		super.registerGoals();
		this.goalSelector.addGoal(1, new Goal() {
			{
				this.setFlags(EnumSet.of(Goal.Flag.MOVE));
			}

			public boolean canUse() {
				if (ShovelEntityEntity.this.getTarget() != null && !ShovelEntityEntity.this.getMoveControl().hasWanted()) {
					double x = ShovelEntityEntity.this.getX();
					double y = ShovelEntityEntity.this.getY();
					double z = ShovelEntityEntity.this.getZ();
					Entity entity = ShovelEntityEntity.this;
					Level world = ShovelEntityEntity.this.level();
					return ShovelEntityIdleConditionProcedure.execute(entity);
				} else {
					return false;
				}
			}

			@Override
			public boolean canContinueToUse() {
				double x = ShovelEntityEntity.this.getX();
				double y = ShovelEntityEntity.this.getY();
				double z = ShovelEntityEntity.this.getZ();
				Entity entity = ShovelEntityEntity.this;
				Level world = ShovelEntityEntity.this.level();
				return ShovelEntityIdleConditionProcedure.execute(entity) && ShovelEntityEntity.this.getMoveControl().hasWanted() && ShovelEntityEntity.this.getTarget() != null && ShovelEntityEntity.this.getTarget().isAlive();
			}

			@Override
			public void start() {
				LivingEntity livingentity = ShovelEntityEntity.this.getTarget();
				Vec3 vec3d = livingentity.getEyePosition(1);
				ShovelEntityEntity.this.moveControl.setWantedPosition(vec3d.x, vec3d.y, vec3d.z, 1);
			}

			@Override
			public void tick() {
				LivingEntity livingentity = ShovelEntityEntity.this.getTarget();
				if (ShovelEntityEntity.this.getBoundingBox().intersects(livingentity.getBoundingBox())) {
					ShovelEntityEntity.this.doHurtTarget(this.getServerLevel(livingentity), livingentity);
				} else {
					double d0 = ShovelEntityEntity.this.distanceToSqr(livingentity);
					if (d0 < 16) {
						Vec3 vec3d = livingentity.getEyePosition(1);
						ShovelEntityEntity.this.moveControl.setWantedPosition(vec3d.x, vec3d.y, vec3d.z, 1);
					}
				}
			}
		});
		this.goalSelector.addGoal(2, new RandomStrollGoal(this, 1, 20) {
			@Override
			protected Vec3 getPosition() {
				RandomSource random = ShovelEntityEntity.this.getRandom();
				double dir_x = ShovelEntityEntity.this.getX() + ((random.nextFloat() * 2 - 1) * 16);
				double dir_y = ShovelEntityEntity.this.getY() + ((random.nextFloat() * 2 - 1) * 16);
				double dir_z = ShovelEntityEntity.this.getZ() + ((random.nextFloat() * 2 - 1) * 16);
				return new Vec3(dir_x, dir_y, dir_z);
			}

			@Override
			public boolean canUse() {
				double x = ShovelEntityEntity.this.getX();
				double y = ShovelEntityEntity.this.getY();
				double z = ShovelEntityEntity.this.getZ();
				Entity entity = ShovelEntityEntity.this;
				Level world = ShovelEntityEntity.this.level();
				return super.canUse() && ShovelEntityIdleConditionProcedure.execute(entity);
			}

			@Override
			public boolean canContinueToUse() {
				double x = ShovelEntityEntity.this.getX();
				double y = ShovelEntityEntity.this.getY();
				double z = ShovelEntityEntity.this.getZ();
				Entity entity = ShovelEntityEntity.this;
				Level world = ShovelEntityEntity.this.level();
				return super.canContinueToUse() && ShovelEntityIdleConditionProcedure.execute(entity);
			}

		});
		this.goalSelector.addGoal(3, new RandomLookAroundGoal(this) {
			@Override
			public boolean canUse() {
				double x = ShovelEntityEntity.this.getX();
				double y = ShovelEntityEntity.this.getY();
				double z = ShovelEntityEntity.this.getZ();
				Entity entity = ShovelEntityEntity.this;
				Level world = ShovelEntityEntity.this.level();
				return super.canUse() && ShovelEntityIdleConditionProcedure.execute(entity);
			}

			@Override
			public boolean canContinueToUse() {
				double x = ShovelEntityEntity.this.getX();
				double y = ShovelEntityEntity.this.getY();
				double z = ShovelEntityEntity.this.getZ();
				Entity entity = ShovelEntityEntity.this;
				Level world = ShovelEntityEntity.this.level();
				return super.canContinueToUse() && ShovelEntityIdleConditionProcedure.execute(entity);
			}
		});
		this.targetSelector.addGoal(4, new NearestAttackableTargetGoal(this, Player.class, false, false) {
			@Override
			public boolean canUse() {
				double x = ShovelEntityEntity.this.getX();
				double y = ShovelEntityEntity.this.getY();
				double z = ShovelEntityEntity.this.getZ();
				Entity entity = ShovelEntityEntity.this;
				Level world = ShovelEntityEntity.this.level();
				return super.canUse() && ShovelEntityCanAttackConditionProcedure.execute(entity);
			}

			@Override
			public boolean canContinueToUse() {
				double x = ShovelEntityEntity.this.getX();
				double y = ShovelEntityEntity.this.getY();
				double z = ShovelEntityEntity.this.getZ();
				Entity entity = ShovelEntityEntity.this;
				Level world = ShovelEntityEntity.this.level();
				return super.canContinueToUse() && ShovelEntityCanAttackConditionProcedure.execute(entity);
			}
		});
		this.targetSelector.addGoal(5, new HurtByTargetGoal(this) {
			@Override
			public boolean canUse() {
				double x = ShovelEntityEntity.this.getX();
				double y = ShovelEntityEntity.this.getY();
				double z = ShovelEntityEntity.this.getZ();
				Entity entity = ShovelEntityEntity.this;
				Level world = ShovelEntityEntity.this.level();
				return super.canUse() && ShovelEntityCanAttackConditionProcedure.execute(entity);
			}

			@Override
			public boolean canContinueToUse() {
				double x = ShovelEntityEntity.this.getX();
				double y = ShovelEntityEntity.this.getY();
				double z = ShovelEntityEntity.this.getZ();
				Entity entity = ShovelEntityEntity.this;
				Level world = ShovelEntityEntity.this.level();
				return super.canContinueToUse() && ShovelEntityCanAttackConditionProcedure.execute(entity);
			}
		}.setAlertOthers());
	}

	@Override
	public SoundEvent getAmbientSound() {
		return BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("meritocraft:pablo01"));
	}

	@Override
	public SoundEvent getHurtSound(DamageSource ds) {
		return BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("meritocraft:pablo03"));
	}

	@Override
	public SoundEvent getDeathSound() {
		return BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("meritocraft:pablo02"));
	}

	@Override
	public boolean causeFallDamage(double l, float d, DamageSource source) {
		return false;
	}

	@Override
	public void die(DamageSource source) {
		super.die(source);
		ShovelEntityDiesProcedure.execute(this.level(), this.getX(), this.getY(), this.getZ(), this);
	}

	@Override
	public SpawnGroupData finalizeSpawn(ServerLevelAccessor world, DifficultyInstance difficulty, EntitySpawnReason reason, @Nullable SpawnGroupData livingdata) {
		SpawnGroupData retval = super.finalizeSpawn(world, difficulty, reason, livingdata);
		ShovelEntityOnSpawnProcedure.execute(this);
		return retval;
	}

	@Override
	public void addAdditionalSaveData(ValueOutput valueOutput) {
		super.addAdditionalSaveData(valueOutput);
		valueOutput.putInt("DataactionState", this.entityData.get(DATA_actionState));
		valueOutput.putInt("Datatype", this.entityData.get(DATA_type));
	}

	@Override
	public void readAdditionalSaveData(ValueInput valueInput) {
		super.readAdditionalSaveData(valueInput);
		this.entityData.set(DATA_actionState, valueInput.getIntOr("DataactionState", 0));
		this.entityData.set(DATA_type, valueInput.getIntOr("Datatype", 0));
	}

	@Override
	public void tick() {
		super.tick();
		if (this.level().isClientSide()) {
			this.animationState0.animateWhen(ShovelEntityAttackConditionProcedure.execute(this), this.tickCount);
		}
	}

	@Override
	public void baseTick() {
		super.baseTick();
		ShovelEntityTickProcedure.execute(this);
	}

	@Override
	public boolean canDrownInFluidType(FluidType type) {
		double x = this.getX();
		double y = this.getY();
		double z = this.getZ();
		Level world = this.level();
		Entity entity = this;
		return false;
	}

	@Override
	public void travel(Vec3 dir) {
		this.travelFlying(dir, (float) this.getAttributeValue(Attributes.FLYING_SPEED));
	}

	@Override
	protected void checkFallDamage(double y, boolean onGroundIn, BlockState state, BlockPos pos) {
	}

	@Override
	public void setNoGravity(boolean ignored) {
		super.setNoGravity(true);
	}

	public void aiStep() {
		super.aiStep();
		this.setNoGravity(true);
	}

	public static void init(RegisterSpawnPlacementsEvent event) {
		event.register(MeritocraftModEntities.SHOVEL_ENTITY.get(), SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
				(entityType, world, reason, pos, random) -> (world.getDifficulty() != Difficulty.PEACEFUL && Monster.isDarkEnoughToSpawn(world, pos, random) && Mob.checkMobSpawnRules(entityType, world, reason, pos, random)),
				RegisterSpawnPlacementsEvent.Operation.REPLACE);
	}

	public static AttributeSupplier.Builder createAttributes() {
		AttributeSupplier.Builder builder = Mob.createMobAttributes();
		builder = builder.add(Attributes.MOVEMENT_SPEED, 0.2);
		builder = builder.add(Attributes.MAX_HEALTH, 6);
		builder = builder.add(Attributes.ARMOR, 0);
		builder = builder.add(Attributes.ATTACK_DAMAGE, 2);
		builder = builder.add(Attributes.FOLLOW_RANGE, 16);
		builder = builder.add(Attributes.STEP_HEIGHT, 0.4);
		builder = builder.add(Attributes.FLYING_SPEED, 0.2);
		return builder;
	}
}