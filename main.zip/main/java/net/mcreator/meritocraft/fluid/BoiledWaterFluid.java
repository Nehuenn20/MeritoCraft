package net.mcreator.meritocraft.fluid;

import org.apache.logging.log4j.core.util.Source;

import net.neoforged.neoforge.fluids.BaseFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.ParticleOptions;

import net.mcreator.meritocraft.init.MeritocraftModItems;
import net.mcreator.meritocraft.init.MeritocraftModFluids;
import net.mcreator.meritocraft.init.MeritocraftModFluidTypes;
import net.mcreator.meritocraft.init.MeritocraftModBlocks;

public abstract class BoiledWaterFluid extends BaseFlowingFluid {
	public static final BaseFlowingFluid.Properties PROPERTIES = new BaseFlowingFluid.Properties(() -> MeritocraftModFluidTypes.BOILED_WATER_TYPE.get(), () -> MeritocraftModFluids.BOILED_WATER.get(),
			() -> MeritocraftModFluids.FLOWING_BOILED_WATER.get()).explosionResistance(100f).tickRate(4).bucket(() -> MeritocraftModItems.BOILED_WATER_BUCKET.get()).block(() -> (LiquidBlock) MeritocraftModBlocks.BOILED_WATER.get());

	private BoiledWaterFluid() {
		super(PROPERTIES);
	}

	@Override
	public ParticleOptions getDripParticle() {
		return ParticleTypes.DRIPPING_WATER;
	}

	public static class Source extends BoiledWaterFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends BoiledWaterFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}