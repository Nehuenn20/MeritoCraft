package net.mcreator.meritocraft.client.gui;

import net.neoforged.neoforge.client.network.ClientPacketDistributor;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.util.Mth;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.WidgetSprites;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.GuiGraphics;

import net.mcreator.meritocraft.world.inventory.PotionBookGUIMenu;
import net.mcreator.meritocraft.procedures.*;
import net.mcreator.meritocraft.network.PotionBookGUIButtonMessage;
import net.mcreator.meritocraft.init.MeritocraftModScreens;

public class PotionBookGUIScreen extends AbstractContainerScreen<PotionBookGUIMenu> implements MeritocraftModScreens.ScreenAccessor {
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	private boolean menuStateUpdateActive = false;
	private ImageButton imagebutton_book_page_back;
	private ImageButton imagebutton_book_page_forward;
	private static final ResourceLocation SPRITE_0 = ResourceLocation.parse("meritocraft:textures/screens/potion_book.png");
	private static final ResourceLocation SPRITE_1 = ResourceLocation.parse("meritocraft:textures/screens/potion_book_recipe.png");
	private static final ResourceLocation SPRITE_2 = ResourceLocation.parse("meritocraft:textures/screens/potion_book_recipe.png");
	private static final ResourceLocation SPRITE_3 = ResourceLocation.parse("meritocraft:textures/screens/potion_book_sprites.png");
	private static final ResourceLocation SPRITE_4 = ResourceLocation.parse("meritocraft:textures/screens/potion_book_sprites.png");
	private static final ResourceLocation SPRITE_5 = ResourceLocation.parse("meritocraft:textures/screens/potion_book_sprites.png");
	private static final ResourceLocation SPRITE_6 = ResourceLocation.parse("meritocraft:textures/screens/potion_book_sprites.png");

	public PotionBookGUIScreen(PotionBookGUIMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 0;
		this.imageHeight = 0;
	}

	@Override
	public void updateMenuState(int elementType, String name, Object elementState) {
		menuStateUpdateActive = true;
		menuStateUpdateActive = false;
	}

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int mouseX, int mouseY) {
		guiGraphics.blit(RenderPipelines.GUI_TEXTURED, SPRITE_0, this.leftPos + -144, this.topPos + -90, 0, 0, 287, 180, 287, 180);
		guiGraphics.blit(RenderPipelines.GUI_TEXTURED, SPRITE_1, this.leftPos + -124, this.topPos + -49, 0, 0, 111, 93, 111, 93);
		if (PotionBookRecipe2Procedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, SPRITE_2, this.leftPos + 11, this.topPos + -49, 0, 0, 111, 93, 111, 93);
		}
		guiGraphics.blit(RenderPipelines.GUI_TEXTURED, SPRITE_3, this.leftPos + -83, this.topPos + -47, Mth.clamp((int) PotionBookSprite1Procedure.execute(entity) * 29, 0, 116), 0, 29, 28, 145, 28);
		guiGraphics.blit(RenderPipelines.GUI_TEXTURED, SPRITE_4, this.leftPos + -83, this.topPos + 15, Mth.clamp((int) PotionBookSprite2Procedure.execute(entity) * 29, 0, 116), 0, 29, 28, 145, 28);
		if (PotionBookRecipe2Procedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, SPRITE_5, this.leftPos + 52, this.topPos + -47, Mth.clamp((int) PotionBookSprite3Procedure.execute(entity) * 29, 0, 116), 0, 29, 28, 145, 28);
		}
		if (PotionBookRecipe2Procedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, SPRITE_6, this.leftPos + 52, this.topPos + 15, Mth.clamp((int) PotionBookSprite4Procedure.execute(entity) * 29, 0, 116), 0, 29, 28, 145, 28);
		}
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
	}

	@Override
	public void init() {
		super.init();
		imagebutton_book_page_back = new ImageButton(this.leftPos + -122, this.topPos + 66, 23, 13,
				new WidgetSprites(ResourceLocation.parse("meritocraft:textures/screens/book_page_back.png"), ResourceLocation.parse("meritocraft:textures/screens/book_page_back_highlighted.png")), e -> {
					int x = PotionBookGUIScreen.this.x;
					int y = PotionBookGUIScreen.this.y;
					if (PotionBookPageBackwardsConditionProcedure.execute(entity)) {
						ClientPacketDistributor.sendToServer(new PotionBookGUIButtonMessage(0, x, y, z));
						PotionBookGUIButtonMessage.handleButtonAction(entity, 0, x, y, z);
					}
				}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
				int x = PotionBookGUIScreen.this.x;
				int y = PotionBookGUIScreen.this.y;
				if (PotionBookPageBackwardsConditionProcedure.execute(entity))
					guiGraphics.blit(RenderPipelines.GUI_TEXTURED, sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		this.addRenderableWidget(imagebutton_book_page_back);
		imagebutton_book_page_forward = new ImageButton(this.leftPos + 98, this.topPos + 66, 23, 13,
				new WidgetSprites(ResourceLocation.parse("meritocraft:textures/screens/book_page_forward.png"), ResourceLocation.parse("meritocraft:textures/screens/book_page_forward_highlighted.png")), e -> {
					int x = PotionBookGUIScreen.this.x;
					int y = PotionBookGUIScreen.this.y;
					if (PotionBookPageForwardsConditionProcedure.execute(entity)) {
						ClientPacketDistributor.sendToServer(new PotionBookGUIButtonMessage(1, x, y, z));
						PotionBookGUIButtonMessage.handleButtonAction(entity, 1, x, y, z);
					}
				}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
				int x = PotionBookGUIScreen.this.x;
				int y = PotionBookGUIScreen.this.y;
				if (PotionBookPageForwardsConditionProcedure.execute(entity))
					guiGraphics.blit(RenderPipelines.GUI_TEXTURED, sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		this.addRenderableWidget(imagebutton_book_page_forward);
	}
}