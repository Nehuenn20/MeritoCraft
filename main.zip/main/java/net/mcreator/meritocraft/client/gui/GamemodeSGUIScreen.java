package net.mcreator.meritocraft.client.gui;

import net.neoforged.neoforge.client.network.ClientPacketDistributor;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.util.Mth;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.WidgetSprites;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.GuiGraphics;

import net.mcreator.meritocraft.world.inventory.GamemodeSGUIMenu;
import net.mcreator.meritocraft.procedures.GSProcTrueProcedure;
import net.mcreator.meritocraft.procedures.GSProcFalseProcedure;
import net.mcreator.meritocraft.procedures.GSProcButtonSpriteProcedure;
import net.mcreator.meritocraft.network.GamemodeSGUIButtonMessage;
import net.mcreator.meritocraft.init.MeritocraftModScreens;

public class GamemodeSGUIScreen extends AbstractContainerScreen<GamemodeSGUIMenu> implements MeritocraftModScreens.ScreenAccessor {
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	private boolean menuStateUpdateActive = false;
	private ImageButton imagebutton_switch_on;
	private static final ResourceLocation BACKGROUND = ResourceLocation.parse("meritocraft:textures/screens/gamemode_sgui.png");
	private static final ResourceLocation SPRITE_0 = ResourceLocation.parse("meritocraft:textures/screens/switch_sprite.png");

	public GamemodeSGUIScreen(GamemodeSGUIMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 89;
		this.imageHeight = 75;
	}

	@Override
	public void updateMenuState(int elementType, String name, Object elementState) {
		menuStateUpdateActive = true;
		menuStateUpdateActive = false;
	}

	@Override
	public boolean isPauseScreen() {
		return true;
	}

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int mouseX, int mouseY) {
		guiGraphics.blit(RenderPipelines.GUI_TEXTURED, BACKGROUND, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
		guiGraphics.blit(RenderPipelines.GUI_TEXTURED, SPRITE_0, this.leftPos + 4, this.topPos + 20, Mth.clamp((int) GSProcButtonSpriteProcedure.execute(entity) * 80, 0, 160), 0, 80, 30, 240, 30);
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
		if (GSProcTrueProcedure.execute(entity))
			guiGraphics.drawString(this.font, Component.translatable("gui.meritocraft.gamemode_sgui.label_activado"), 21, 55, -16738048, false);
		if (GSProcFalseProcedure.execute(entity))
			guiGraphics.drawString(this.font, Component.translatable("gui.meritocraft.gamemode_sgui.label_desactivado"), 13, 55, -52429, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.meritocraft.gamemode_sgui.label_modo_creativo"), 8, 5, -12829636, false);
	}

	@Override
	public void init() {
		super.init();
		imagebutton_switch_on = new ImageButton(this.leftPos + 4, this.topPos + 19, 80, 30,
				new WidgetSprites(ResourceLocation.parse("meritocraft:textures/screens/switch_inv.png"), ResourceLocation.parse("meritocraft:textures/screens/switch_inv.png")), e -> {
					int x = GamemodeSGUIScreen.this.x;
					int y = GamemodeSGUIScreen.this.y;
					if (true) {
						ClientPacketDistributor.sendToServer(new GamemodeSGUIButtonMessage(0, x, y, z));
						GamemodeSGUIButtonMessage.handleButtonAction(entity, 0, x, y, z);
					}
				}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
				guiGraphics.blit(RenderPipelines.GUI_TEXTURED, sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		this.addRenderableWidget(imagebutton_switch_on);
	}
}