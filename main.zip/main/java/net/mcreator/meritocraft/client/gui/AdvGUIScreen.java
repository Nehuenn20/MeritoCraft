package net.mcreator.meritocraft.client.gui;

import net.neoforged.neoforge.client.network.ClientPacketDistributor;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.WidgetSprites;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.GuiGraphics;

import net.mcreator.meritocraft.world.inventory.AdvGUIMenu;
import net.mcreator.meritocraft.procedures.*;
import net.mcreator.meritocraft.network.AdvGUIButtonMessage;
import net.mcreator.meritocraft.init.MeritocraftModScreens;

import java.util.stream.Collectors;
import java.util.Arrays;

public class AdvGUIScreen extends AbstractContainerScreen<AdvGUIMenu> implements MeritocraftModScreens.ScreenAccessor {
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	private boolean menuStateUpdateActive = false;
	private ImageButton imagebutton_book_page_back;
	private ImageButton imagebutton_book_page_forward;
	private static final ResourceLocation IMAGE_0 = ResourceLocation.parse("meritocraft:textures/screens/book.png");

	public AdvGUIScreen(AdvGUIMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 0;
		this.imageHeight = 0;
	}

	@Override
	public void updateMenuState(int elementType, String name, Object elementState) {
		menuStateUpdateActive = true;
		menuStateUpdateActive = false;
	}

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		boolean customTooltipShown = false;
		if (HintCondition1Procedure.execute(entity))
			if (mouseX > leftPos + -130 && mouseX < leftPos + 130 && mouseY > topPos + -68 && mouseY < topPos + -54) {
				String hoverText = Hint1Procedure.execute(entity);
				if (hoverText != null) {
					guiGraphics.setComponentTooltipForNextFrame(font, Arrays.stream(hoverText.split("\n")).map(Component::literal).collect(Collectors.toList()), mouseX, mouseY);
				}
				customTooltipShown = true;
			}
		if (HintCondition2Procedure.execute(entity))
			if (mouseX > leftPos + -130 && mouseX < leftPos + 130 && mouseY > topPos + -53 && mouseY < topPos + -39) {
				String hoverText = Hint2Procedure.execute(entity);
				if (hoverText != null) {
					guiGraphics.setComponentTooltipForNextFrame(font, Arrays.stream(hoverText.split("\n")).map(Component::literal).collect(Collectors.toList()), mouseX, mouseY);
				}
				customTooltipShown = true;
			}
		if (HintCondition3Procedure.execute(entity))
			if (mouseX > leftPos + -130 && mouseX < leftPos + 130 && mouseY > topPos + -38 && mouseY < topPos + -24) {
				String hoverText = Hint3Procedure.execute(entity);
				if (hoverText != null) {
					guiGraphics.setComponentTooltipForNextFrame(font, Arrays.stream(hoverText.split("\n")).map(Component::literal).collect(Collectors.toList()), mouseX, mouseY);
				}
				customTooltipShown = true;
			}
		if (HintCondition4Procedure.execute(entity))
			if (mouseX > leftPos + -130 && mouseX < leftPos + 130 && mouseY > topPos + -23 && mouseY < topPos + -9) {
				String hoverText = Hint4Procedure.execute(entity);
				if (hoverText != null) {
					guiGraphics.setComponentTooltipForNextFrame(font, Arrays.stream(hoverText.split("\n")).map(Component::literal).collect(Collectors.toList()), mouseX, mouseY);
				}
				customTooltipShown = true;
			}
		if (HintCondition5Procedure.execute(entity))
			if (mouseX > leftPos + -130 && mouseX < leftPos + 130 && mouseY > topPos + -8 && mouseY < topPos + 6) {
				String hoverText = Hint5Procedure.execute(entity);
				if (hoverText != null) {
					guiGraphics.setComponentTooltipForNextFrame(font, Arrays.stream(hoverText.split("\n")).map(Component::literal).collect(Collectors.toList()), mouseX, mouseY);
				}
				customTooltipShown = true;
			}
		if (HintCondition6Procedure.execute(entity))
			if (mouseX > leftPos + -130 && mouseX < leftPos + 130 && mouseY > topPos + 7 && mouseY < topPos + 21) {
				String hoverText = Hint6Procedure.execute(entity);
				if (hoverText != null) {
					guiGraphics.setComponentTooltipForNextFrame(font, Arrays.stream(hoverText.split("\n")).map(Component::literal).collect(Collectors.toList()), mouseX, mouseY);
				}
				customTooltipShown = true;
			}
		if (HintCondition7Procedure.execute(entity))
			if (mouseX > leftPos + -130 && mouseX < leftPos + 130 && mouseY > topPos + 22 && mouseY < topPos + 36) {
				String hoverText = Hint7Procedure.execute(entity);
				if (hoverText != null) {
					guiGraphics.setComponentTooltipForNextFrame(font, Arrays.stream(hoverText.split("\n")).map(Component::literal).collect(Collectors.toList()), mouseX, mouseY);
				}
				customTooltipShown = true;
			}
		if (HintCondition8Procedure.execute(entity))
			if (mouseX > leftPos + -130 && mouseX < leftPos + 130 && mouseY > topPos + 37 && mouseY < topPos + 51) {
				String hoverText = Hint8Procedure.execute(entity);
				if (hoverText != null) {
					guiGraphics.setComponentTooltipForNextFrame(font, Arrays.stream(hoverText.split("\n")).map(Component::literal).collect(Collectors.toList()), mouseX, mouseY);
				}
				customTooltipShown = true;
			}
		if (HintCondition9Procedure.execute(entity))
			if (mouseX > leftPos + -130 && mouseX < leftPos + 130 && mouseY > topPos + 52 && mouseY < topPos + 66) {
				String hoverText = Hint9Procedure.execute(entity);
				if (hoverText != null) {
					guiGraphics.setComponentTooltipForNextFrame(font, Arrays.stream(hoverText.split("\n")).map(Component::literal).collect(Collectors.toList()), mouseX, mouseY);
				}
				customTooltipShown = true;
			}
		if (!customTooltipShown)
			this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int mouseX, int mouseY) {
		guiGraphics.blit(RenderPipelines.GUI_TEXTURED, IMAGE_0, this.leftPos + -143, this.topPos + -90, 0, 0, 287, 180, 287, 180);
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
		guiGraphics.drawString(this.font, Adv1Procedure.execute(entity), -129, -66, -12829636, false);
		guiGraphics.drawString(this.font, Adv2Procedure.execute(entity), -129, -51, -12829636, false);
		guiGraphics.drawString(this.font, Adv3Procedure.execute(entity), -129, -36, -12829636, false);
		guiGraphics.drawString(this.font, Adv4Procedure.execute(entity), -129, -21, -12829636, false);
		guiGraphics.drawString(this.font, Adv5Procedure.execute(entity), -129, -6, -12829636, false);
		guiGraphics.drawString(this.font, Adv6Procedure.execute(entity), -129, 9, -12829636, false);
		guiGraphics.drawString(this.font, Adv7Procedure.execute(entity), -129, 24, -12829636, false);
		guiGraphics.drawString(this.font, Adv8Procedure.execute(entity), -129, 39, -12829636, false);
		guiGraphics.drawString(this.font, Adv9Procedure.execute(entity), -129, 54, -12829636, false);
	}

	@Override
	public void init() {
		super.init();
		imagebutton_book_page_back = new ImageButton(this.leftPos + -122, this.topPos + 66, 23, 13,
				new WidgetSprites(ResourceLocation.parse("meritocraft:textures/screens/book_page_back.png"), ResourceLocation.parse("meritocraft:textures/screens/book_page_back_highlighted.png")), e -> {
					int x = AdvGUIScreen.this.x;
					int y = AdvGUIScreen.this.y;
					if (AdvBookPageBackwardsConditionProcedure.execute(entity)) {
						ClientPacketDistributor.sendToServer(new AdvGUIButtonMessage(0, x, y, z));
						AdvGUIButtonMessage.handleButtonAction(entity, 0, x, y, z);
					}
				}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
				int x = AdvGUIScreen.this.x;
				int y = AdvGUIScreen.this.y;
				if (AdvBookPageBackwardsConditionProcedure.execute(entity))
					guiGraphics.blit(RenderPipelines.GUI_TEXTURED, sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		this.addRenderableWidget(imagebutton_book_page_back);
		imagebutton_book_page_forward = new ImageButton(this.leftPos + 98, this.topPos + 66, 23, 13,
				new WidgetSprites(ResourceLocation.parse("meritocraft:textures/screens/book_page_forward.png"), ResourceLocation.parse("meritocraft:textures/screens/book_page_forward_highlighted.png")), e -> {
					int x = AdvGUIScreen.this.x;
					int y = AdvGUIScreen.this.y;
					if (AdvBookPageForwardsConditionProcedure.execute(entity)) {
						ClientPacketDistributor.sendToServer(new AdvGUIButtonMessage(1, x, y, z));
						AdvGUIButtonMessage.handleButtonAction(entity, 1, x, y, z);
					}
				}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
				int x = AdvGUIScreen.this.x;
				int y = AdvGUIScreen.this.y;
				if (AdvBookPageForwardsConditionProcedure.execute(entity))
					guiGraphics.blit(RenderPipelines.GUI_TEXTURED, sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		this.addRenderableWidget(imagebutton_book_page_forward);
	}
}