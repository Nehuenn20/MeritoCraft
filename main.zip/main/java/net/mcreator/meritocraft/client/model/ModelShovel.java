package net.mcreator.meritocraft.client.model;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.EntityModel;

// Made with Blockbench 5.1.4
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports
public class ModelShovel extends EntityModel<LivingEntityRenderState> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath("meritocraft", "model_shovel"), "main");
	public final ModelPart Paleta2;
	public final ModelPart Paleta;
	public final ModelPart Palo;

	public ModelShovel(ModelPart root) {
		super(root);
		this.Paleta2 = root.getChild("Paleta2");
		this.Paleta = this.Paleta2.getChild("Paleta");
		this.Palo = this.Paleta2.getChild("Palo");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();
		PartDefinition Paleta2 = partdefinition.addOrReplaceChild("Paleta2", CubeListBuilder.create(), PartPose.offsetAndRotation(-0.5F, 16.87F, -0.6676F, 0.0F, 3.1416F, 0.0F));
		PartDefinition Paleta = Paleta2.addOrReplaceChild("Paleta",
				CubeListBuilder.create().texOffs(4, 15).addBox(-0.5F, 0.0F, -4.4048F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(16, 4).addBox(-0.5F, 3.0F, -1.4048F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(16, 12)
						.addBox(-0.5F, 2.0F, -1.4048F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(4, 0).addBox(-0.5F, -2.0F, -1.4048F, 1.0F, 4.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(16, 6)
						.addBox(-0.5F, 2.0F, -0.4048F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(16, 16).addBox(-0.5F, 0.0F, -0.4048F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(8, 18)
						.addBox(-0.5F, -2.0F, -0.4048F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 18).addBox(-0.5F, -1.0F, -0.4048F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(16, 14)
						.addBox(-0.5F, 1.0F, -0.4048F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(8, 16).addBox(-0.5F, 1.0F, 0.5952F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(4, 17)
						.addBox(-0.5F, 0.0F, 0.5952F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(12, 18).addBox(-0.5F, -1.0F, 0.5952F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(16, 18)
						.addBox(-0.5F, -2.0F, 0.5952F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(16, 8).addBox(-0.5F, 0.0F, 1.5952F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(16, 10)
						.addBox(-0.5F, -1.0F, 1.5952F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(12, 16).addBox(-0.5F, -2.0F, 1.5952F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 5)
						.addBox(-0.5F, -1.0F, -3.4048F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 0).addBox(-0.5F, -2.0F, -2.4048F, 1.0F, 4.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 16)
						.addBox(-0.5F, -3.0F, -1.4048F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(16, 0).addBox(-0.5F, -3.0F, -0.4048F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(16, 2)
						.addBox(-0.5F, -3.0F, 0.5952F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, -2.87F, 3.0724F));
		PartDefinition Palo = Paleta2.addOrReplaceChild("Palo",
				CubeListBuilder.create().texOffs(4, 5).addBox(-0.5F, 2.26F, -4.26F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(4, 7).addBox(-0.5F, 1.26F, -4.26F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 8)
						.addBox(-0.5F, 2.26F, -3.26F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 10).addBox(-0.5F, 1.26F, -2.26F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(8, 10)
						.addBox(-0.5F, 0.26F, -1.26F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(4, 11).addBox(-0.5F, -0.74F, -0.26F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 12)
						.addBox(-0.5F, -1.74F, 0.74F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(12, 0).addBox(-0.5F, -2.74F, 1.74F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(12, 2)
						.addBox(-0.5F, -3.74F, 2.74F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(8, 0).addBox(-0.5F, 3.26F, -3.26F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(8, 2)
						.addBox(-0.5F, 3.26F, -2.26F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(8, 4).addBox(-0.5F, 2.26F, -2.26F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(4, 9)
						.addBox(-0.5F, 1.26F, -1.26F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(12, 8).addBox(-0.5F, 0.26F, -0.26F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(12, 10)
						.addBox(-0.5F, -0.74F, 0.74F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(12, 12).addBox(-0.5F, -1.74F, 1.74F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(4, 13)
						.addBox(-0.5F, -2.74F, 2.74F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 14).addBox(-0.5F, -3.74F, 3.74F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(8, 6)
						.addBox(-0.5F, 1.26F, -3.26F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(8, 8).addBox(-0.5F, 0.26F, -2.26F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(12, 4)
						.addBox(-0.5F, -0.74F, -1.26F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(12, 6).addBox(-0.5F, -1.74F, -0.26F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(8, 12)
						.addBox(-0.5F, -2.74F, 0.74F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(8, 14).addBox(-0.5F, -3.74F, 1.74F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(12, 14)
						.addBox(-0.5F, -4.74F, 2.74F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 2.87F, -3.0724F));
		return LayerDefinition.create(meshdefinition, 32, 32);
	}

	public void setupAnim(LivingEntityRenderState state) {
		float limbSwing = state.walkAnimationPos;
		float limbSwingAmount = state.walkAnimationSpeed;
		float ageInTicks = state.ageInTicks;
		float netHeadYaw = state.yRot;
		float headPitch = state.xRot;

	}
}