package net.mcreator.meritocraft.configuration;

import net.neoforged.neoforge.common.ModConfigSpec;

public class MainConfigurationConfiguration {
	public static final ModConfigSpec.Builder BUILDER = new ModConfigSpec.Builder();
	public static final ModConfigSpec SPEC;
	public static final ModConfigSpec.ConfigValue<Boolean> COMPLETEMODE;
	public static final ModConfigSpec.ConfigValue<Boolean> ENDERMANAGGRO;
	public static final ModConfigSpec.ConfigValue<Boolean> COMMANDSNERF;
	static {
		COMPLETEMODE = BUILDER.comment("Enable the full MeritoCraft experience").define("full_experience", true);
		ENDERMANAGGRO = BUILDER.comment("Enable aggressive enderman in the overworld").define("endermanoverworldaggro", false);
		COMMANDSNERF = BUILDER.comment("Enable nerfs to vanilla commands").define("commandsnerf", true);

		SPEC = BUILDER.build();
	}

}