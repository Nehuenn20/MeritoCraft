package net.mcreator.meritocraft.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.meritocraft.network.MeritocraftModVariables;

public class Hint8Procedure {
	public static String execute(Entity entity) {
		if (entity == null)
			return "";
		String hint = "";
		if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).adv_book_page == 0) {
			hint = "Utiliza un poderoso \u00EDtem m\u00E1gico para debilitar a tus enemigos";
		} else if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).adv_book_page == 1) {
			hint = "Intenta saquear una aldea";
		} else if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).adv_book_page == 2) {
			hint = "Derrota al minijefe que puedes llegar a encontrar en aldeas";
		} else if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).adv_book_page == 3) {
			hint = "Pesca mala fortuna";
		} else if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).adv_book_page == 4) {
			hint = "Obt\u00E9n este libro de una forma m\u00E1s legal";
		}
		return hint;
	}
}