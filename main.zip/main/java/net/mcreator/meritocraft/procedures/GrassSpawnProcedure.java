package net.mcreator.meritocraft.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.BlockPos;

import net.mcreator.meritocraft.entity.GrassEntity;

public class GrassSpawnProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (entity.getPersistentData().getBooleanOr("Textured", false) == false) {
			if (world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("badlands")) || world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("wooded_badlands"))
					|| world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("eroded_badlands"))) {
				if (entity instanceof GrassEntity _datEntSetI)
					_datEntSetI.getEntityData().set(GrassEntity.DATA_SkinID, 1);
			} else if (world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("cherry_grove"))) {
				if (entity instanceof GrassEntity _datEntSetI)
					_datEntSetI.getEntityData().set(GrassEntity.DATA_SkinID, 2);
			} else if (world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("desert")) || world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("savanna"))
					|| world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("savanna_plateau")) || world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("windswept_savanna"))
					|| world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("nether_wastes")) || world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("soul_sand_valley"))
					|| world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("basalt_deltas"))) {
				if ((world.getBlockState(BlockPos.containing(x, y - 1, z))).is(BlockTags.create(ResourceLocation.parse("minecraft:can_drygrass")))) {
					if (0.5 < Math.random()) {
						if (entity instanceof GrassEntity _datEntSetI)
							_datEntSetI.getEntityData().set(GrassEntity.DATA_SkinID, 23);
					} else {
						if (entity instanceof GrassEntity _datEntSetI)
							_datEntSetI.getEntityData().set(GrassEntity.DATA_SkinID, 24);
					}
				} else {
					if (entity instanceof GrassEntity _datEntSetI)
						_datEntSetI.getEntityData().set(GrassEntity.DATA_SkinID, 3);
				}
			} else if (world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("stony_peaks"))) {
				if (entity instanceof GrassEntity _datEntSetI)
					_datEntSetI.getEntityData().set(GrassEntity.DATA_SkinID, 4);
			} else if (world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("jungle")) || world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("bamboo_jungle"))) {
				if (entity instanceof GrassEntity _datEntSetI)
					_datEntSetI.getEntityData().set(GrassEntity.DATA_SkinID, 5);
			} else if (world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("sparse_jungle"))) {
				if (entity instanceof GrassEntity _datEntSetI)
					_datEntSetI.getEntityData().set(GrassEntity.DATA_SkinID, 6);
			} else if (world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("mushroom_fields"))) {
				if (entity instanceof GrassEntity _datEntSetI)
					_datEntSetI.getEntityData().set(GrassEntity.DATA_SkinID, 7);
			} else if (world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("swamp"))
					|| world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("mangrove_swamp")) && world.getBiome(BlockPos.containing(x, y, z)).value().getBaseTemperature() * 100f > -0.1) {
				if (entity instanceof GrassEntity _datEntSetI)
					_datEntSetI.getEntityData().set(GrassEntity.DATA_SkinID, 8);
			} else if (world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("mangrove_swamp")) && world.getBiome(BlockPos.containing(x, y, z)).value().getBaseTemperature() * 100f < -0.1) {
				if (entity instanceof GrassEntity _datEntSetI)
					_datEntSetI.getEntityData().set(GrassEntity.DATA_SkinID, 9);
			} else if (world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("forest")) || world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("flower_forest"))) {
				if (entity instanceof GrassEntity _datEntSetI)
					_datEntSetI.getEntityData().set(GrassEntity.DATA_SkinID, 10);
			} else if (world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("dark_forest"))) {
				if (entity instanceof GrassEntity _datEntSetI)
					_datEntSetI.getEntityData().set(GrassEntity.DATA_SkinID, 11);
			} else if (world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("pale_garden"))) {
				if (entity instanceof GrassEntity _datEntSetI)
					_datEntSetI.getEntityData().set(GrassEntity.DATA_SkinID, 12);
			} else if (world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("birch_forest")) || world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("old_growth_birch_forest"))) {
				if (entity instanceof GrassEntity _datEntSetI)
					_datEntSetI.getEntityData().set(GrassEntity.DATA_SkinID, 13);
			} else if (world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("ocean")) || world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("deep_ocean"))
					|| world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("warm_ocean")) || world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("lukewarm_ocean"))
					|| world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("deep_lukewarm_ocean")) || world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("cold_ocean"))
					|| world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("deep_cold_ocean")) || world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("deep_frozen_ocean"))
					|| world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("river")) || world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("lush_caves"))
					|| world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("the_end")) || world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("small_end_islands"))
					|| world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("end_barrens")) || world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("end_midlands"))
					|| world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("end_highlands")) || world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("the_void"))) {
				if (entity instanceof GrassEntity _datEntSetI)
					_datEntSetI.getEntityData().set(GrassEntity.DATA_SkinID, 14);
			} else if (world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("meadow"))) {
				if (entity instanceof GrassEntity _datEntSetI)
					_datEntSetI.getEntityData().set(GrassEntity.DATA_SkinID, 15);
			} else if (world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("old_growth_pine_taiga"))) {
				if (entity instanceof GrassEntity _datEntSetI)
					_datEntSetI.getEntityData().set(GrassEntity.DATA_SkinID, 16);
			} else if (world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("taiga")) || world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("old_growth_spruce_taiga"))) {
				if (entity instanceof GrassEntity _datEntSetI)
					_datEntSetI.getEntityData().set(GrassEntity.DATA_SkinID, 17);
			} else if (world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("windswept_hills")) || world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("windswept_gravelly_hills"))
					|| world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("windswept_forest")) || world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("stony_shore"))) {
				if (entity instanceof GrassEntity _datEntSetI)
					_datEntSetI.getEntityData().set(GrassEntity.DATA_SkinID, 18);
			} else if (world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("snowy_beach"))) {
				if (entity instanceof GrassEntity _datEntSetI)
					_datEntSetI.getEntityData().set(GrassEntity.DATA_SkinID, 19);
			} else if (world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("snowy_plains")) || world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("ice_spikes"))
					|| world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("snowy_taiga")) || world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("frozen_ocean"))
					|| world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("frozen_river")) || world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("grove"))
					|| world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("snowy_slopes")) || world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("frozen_peaks"))
					|| world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("jagged_peaks"))) {
				if (entity instanceof GrassEntity _datEntSetI)
					_datEntSetI.getEntityData().set(GrassEntity.DATA_SkinID, 20);
			} else if (world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("crimson_forest"))) {
				if (entity instanceof GrassEntity _datEntSetI)
					_datEntSetI.getEntityData().set(GrassEntity.DATA_SkinID, 21);
			} else if (world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("warped_forest"))) {
				if (entity instanceof GrassEntity _datEntSetI)
					_datEntSetI.getEntityData().set(GrassEntity.DATA_SkinID, 22);
			}
			entity.getPersistentData().putBoolean("Textured", true);
		}
	}
}