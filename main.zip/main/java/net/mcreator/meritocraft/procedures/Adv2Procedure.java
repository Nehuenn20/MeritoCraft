package net.mcreator.meritocraft.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.meritocraft.network.MeritocraftModVariables;

public class Adv2Procedure {
	public static String execute(Entity entity) {
		if (entity == null)
			return "";
		boolean check1 = false;
		return entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).adv2;
	}
}