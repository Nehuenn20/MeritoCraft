package net.mcreator.meritocraft.procedures;

import net.neoforged.neoforge.event.tick.EntityTickEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.mcreator.meritocraft.init.MeritocraftModEntities;
import net.mcreator.meritocraft.entity.VillagerBanditEntity;

import javax.annotation.Nullable;

import java.util.Comparator;

@EventBusSubscriber
public class VillagerBanditSpawnProcedure {
	@SubscribeEvent
	public static void onEntityTick(EntityTickEvent.Pre event) {
		execute(event, event.getEntity().level(), event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getEntity());
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		execute(null, world, x, y, z, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		Entity bandit = null;
		double professionN = 0;
		double typeN = 0;
		if (entity instanceof Villager) {
			if (!(!world.getEntitiesOfClass(VillagerBanditEntity.class, new AABB(Vec3.ZERO, Vec3.ZERO).move(new Vec3(x, y, z)).inflate(100 / 2d), e -> true).isEmpty())) {
				if ((executeCommandGetResult(entity, "data get entity @s VillagerData.profession")).contains("\"minecraft:armorer\"")) {
					professionN = 1;
				} else if ((executeCommandGetResult(entity, "data get entity @s VillagerData.profession")).contains("\"minecraft:butcher\"")) {
					professionN = 2;
				} else if ((executeCommandGetResult(entity, "data get entity @s VillagerData.profession")).contains("\"minecraft:cartographer\"")) {
					professionN = 3;
				} else if ((executeCommandGetResult(entity, "data get entity @s VillagerData.profession")).contains("\"minecraft:cleric\"")) {
					professionN = 4;
				} else if ((executeCommandGetResult(entity, "data get entity @s VillagerData.profession")).contains("\"minecraft:farmer\"")) {
					professionN = 5;
				} else if ((executeCommandGetResult(entity, "data get entity @s VillagerData.profession")).contains("\"minecraft:fisherman\"")) {
					professionN = 6;
				} else if ((executeCommandGetResult(entity, "data get entity @s VillagerData.profession")).contains("\"minecraft:fletcher\"")) {
					professionN = 7;
				} else if ((executeCommandGetResult(entity, "data get entity @s VillagerData.profession")).contains("\"minecraft:leatherworker\"")) {
					professionN = 8;
				} else if ((executeCommandGetResult(entity, "data get entity @s VillagerData.profession")).contains("\"minecraft:librarian\"")) {
					professionN = 9;
				} else if ((executeCommandGetResult(entity, "data get entity @s VillagerData.profession")).contains("\"minecraft:mason\"")) {
					professionN = 10;
				} else if ((executeCommandGetResult(entity, "data get entity @s VillagerData.profession")).contains("\"minecraft:nitwit\"")) {
					professionN = 11;
				} else if ((executeCommandGetResult(entity, "data get entity @s VillagerData.profession")).contains("\"minecraft:shepherd\"")) {
					professionN = 12;
				} else if ((executeCommandGetResult(entity, "data get entity @s VillagerData.profession")).contains("\"minecraft:toolsmith\"")) {
					professionN = 13;
				} else if ((executeCommandGetResult(entity, "data get entity @s VillagerData.profession")).contains("\"minecraft:weaponsmith\"")) {
					professionN = 14;
				} else {
					professionN = 0;
				}
				if ((executeCommandGetResult(entity, "data get entity @s VillagerData.type")).contains("\"minecraft:desert\"")) {
					typeN = 1;
				} else if ((executeCommandGetResult(entity, "data get entity @s VillagerData.type")).contains("\"minecraft:jungle\"")) {
					typeN = 2;
				} else if ((executeCommandGetResult(entity, "data get entity @s VillagerData.type")).contains("\"minecraft:plains\"")) {
					typeN = 3;
				} else if ((executeCommandGetResult(entity, "data get entity @s VillagerData.type")).contains("\"minecraft:savanna\"")) {
					typeN = 4;
				} else if ((executeCommandGetResult(entity, "data get entity @s VillagerData.type")).contains("\"minecraft:snow\"")) {
					typeN = 5;
				} else if ((executeCommandGetResult(entity, "data get entity @s VillagerData.type")).contains("\"minecraft:swamp\"")) {
					typeN = 6;
				} else if ((executeCommandGetResult(entity, "data get entity @s VillagerData.type")).contains("\"minecraft:taiga\"")) {
					typeN = 7;
				} else {
					typeN = 0;
				}
				if (!entity.level().isClientSide())
					entity.discard();
				if (world instanceof ServerLevel _level) {
					Entity entityToSpawn = MeritocraftModEntities.VILLAGER_BANDIT.get().spawn(_level, BlockPos.containing(x, y, z), EntitySpawnReason.MOB_SUMMONED);
					if (entityToSpawn != null) {
						entityToSpawn.setYRot(world.getRandom().nextFloat() * 360F);
					}
				}
				bandit = findEntityInWorldRange(world, VillagerBanditEntity.class, x, y, z, 1);
				if (bandit instanceof VillagerBanditEntity _datEntSetI)
					_datEntSetI.getEntityData().set(VillagerBanditEntity.DATA_profession, (int) professionN);
				if (bandit instanceof VillagerBanditEntity _datEntSetI)
					_datEntSetI.getEntityData().set(VillagerBanditEntity.DATA_type, (int) typeN);
			}
		}
	}

	private static String executeCommandGetResult(Entity entity, String command) {
		StringBuilder result = new StringBuilder();
		if (!entity.level().isClientSide() && entity.getServer() != null) {
			CommandSource dataConsumer = new CommandSource() {
				@Override
				public void sendSystemMessage(Component message) {
					result.append(message.getString());
				}

				@Override
				public boolean acceptsSuccess() {
					return true;
				}

				@Override
				public boolean acceptsFailure() {
					return true;
				}

				@Override
				public boolean shouldInformAdmins() {
					return false;
				}
			};
			entity.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(dataConsumer, entity.position(), entity.getRotationVector(), entity.level() instanceof ServerLevel ? (ServerLevel) entity.level() : null, 4,
					entity.getName().getString(), entity.getDisplayName(), entity.level().getServer(), entity), command);
		}
		return result.toString();
	}

	private static Entity findEntityInWorldRange(LevelAccessor world, Class<? extends Entity> clazz, double x, double y, double z, double range) {
		return (Entity) world.getEntitiesOfClass(clazz, AABB.ofSize(new Vec3(x, y, z), range, range, range), e -> true).stream().sorted(Comparator.comparingDouble(e -> e.distanceToSqr(x, y, z))).findFirst().orElse(null);
	}
}