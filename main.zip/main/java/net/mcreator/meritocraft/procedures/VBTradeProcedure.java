package net.mcreator.meritocraft.procedures;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;

import net.mcreator.meritocraft.init.MeritocraftModMenus;

public class VBTradeProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (!((entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof MeritocraftModMenus.MenuAccessor _menu0 ? _menu0.getSlots().get(1).getItem() : ItemStack.EMPTY).getItem() == Blocks.AIR.asItem())) {
			entity.getPersistentData().putBoolean("hasItem", true);
		} else {
			if (entity.getPersistentData().getBooleanOr("hasItem", false) == true) {
				if (entity instanceof Player _player && _player.containerMenu instanceof MeritocraftModMenus.MenuAccessor _menu) {
					_menu.getSlots().get(0).set(ItemStack.EMPTY);
					_player.containerMenu.broadcastChanges();
				}
				entity.getPersistentData().putBoolean("hasItem", false);
			}
		}
	}
}