package net.mcreator.meritocraft.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.tags.TagKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.BlockPos;

import net.mcreator.meritocraft.entity.HerobrineEntity;

import java.util.Comparator;

public class HerobrineSpawnProcedure {
	public static boolean execute(LevelAccessor world, double x, double y, double z) {
		boolean found = false;
		double sx = 0;
		double sy = 0;
		double sz = 0;
		sx = -3;
		found = false;
		for (int index0 = 0; index0 < 6; index0++) {
			sy = -3;
			for (int index1 = 0; index1 < 6; index1++) {
				sz = -3;
				for (int index2 = 0; index2 < 6; index2++) {
					if ((world.getBlockState(BlockPos.containing(
							(!world.getEntitiesOfClass(Player.class, new AABB(Vec3.ZERO, Vec3.ZERO).move(new Vec3(x, y, z)).inflate(100 / 2d), e -> true).isEmpty() ? (findEntityInWorldRange(world, Player.class, x, y, z, 100)).getX() : x) + sx,
							(!world.getEntitiesOfClass(Player.class, new AABB(Vec3.ZERO, Vec3.ZERO).move(new Vec3(x, y, z)).inflate(100 / 2d), e -> true).isEmpty() ? (findEntityInWorldRange(world, Player.class, x, y, z, 100)).getY() : y) + sy,
							(!world.getEntitiesOfClass(Player.class, new AABB(Vec3.ZERO, Vec3.ZERO).move(new Vec3(x, y, z)).inflate(100 / 2d), e -> true).isEmpty() ? (findEntityInWorldRange(world, Player.class, x, y, z, 100)).getZ() : z) + sz)))
							.getBlock() == Blocks.DEEPSLATE_DIAMOND_ORE
							|| (world.getBlockState(BlockPos.containing(
									(!world.getEntitiesOfClass(Player.class, new AABB(Vec3.ZERO, Vec3.ZERO).move(new Vec3(x, y, z)).inflate(100 / 2d), e -> true).isEmpty() ? (findEntityInWorldRange(world, Player.class, x, y, z, 100)).getX() : x)
											+ sx,
									(!world.getEntitiesOfClass(Player.class, new AABB(Vec3.ZERO, Vec3.ZERO).move(new Vec3(x, y, z)).inflate(100 / 2d), e -> true).isEmpty() ? (findEntityInWorldRange(world, Player.class, x, y, z, 100)).getY() : y)
											+ sy,
									(!world.getEntitiesOfClass(Player.class, new AABB(Vec3.ZERO, Vec3.ZERO).move(new Vec3(x, y, z)).inflate(100 / 2d), e -> true).isEmpty() ? (findEntityInWorldRange(world, Player.class, x, y, z, 100)).getZ() : z)
											+ sz)))
									.getBlock() == Blocks.DIAMOND_ORE) {
						found = true;
					}
					sz = sz + 1;
				}
				sy = sy + 1;
			}
			sx = sx + 1;
		}
		return world.isEmptyBlock(BlockPos.containing(x, y, z)) && world.isEmptyBlock(BlockPos.containing(x, y + 1, z))
				&& (world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("deep_dark")) || world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("dark_forest")) || 0.5 > Math.random())
				&& y < world.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (int) x, (int) z) && world.getBlockState(BlockPos.containing(x, y - 1, z)).canOcclude()
				&& world.getBiome(BlockPos.containing(x, y, z)).is(TagKey.create(Registries.BIOME, ResourceLocation.parse("minecraft:is_overworld")))
				&& !(!world.getEntitiesOfClass(HerobrineEntity.class, new AABB(Vec3.ZERO, Vec3.ZERO).move(new Vec3(x, y, z)).inflate(99999 / 2d), e -> true).isEmpty())
				&& !world.getEntitiesOfClass(Player.class, new AABB(Vec3.ZERO, Vec3.ZERO).move(new Vec3(x, y, z)).inflate(100 / 2d), e -> true).isEmpty()
				&& !world.getEntitiesOfClass(Player.class, new AABB(Vec3.ZERO, Vec3.ZERO)
						.move(new Vec3((!world.getEntitiesOfClass(Player.class, new AABB(Vec3.ZERO, Vec3.ZERO).move(new Vec3(x, y, z)).inflate(100 / 2d), e -> true).isEmpty() ? (findEntityInWorldRange(world, Player.class, x, y, z, 100)).getX() : x),
								y, (!world.getEntitiesOfClass(Player.class, new AABB(Vec3.ZERO, Vec3.ZERO).move(new Vec3(x, y, z)).inflate(100 / 2d), e -> true).isEmpty() ? (findEntityInWorldRange(world, Player.class, x, y, z, 100)).getZ() : z)))
						.inflate(6 / 2d), e -> true).isEmpty()
				&& !(!world.getEntitiesOfClass(Player.class, new AABB(Vec3.ZERO, Vec3.ZERO).move(new Vec3(x, y, z)).inflate(5 / 2d), e -> true).isEmpty()) && (found == true ? true : 0.3 > Math.random());
	}

	private static Entity findEntityInWorldRange(LevelAccessor world, Class<? extends Entity> clazz, double x, double y, double z, double range) {
		return (Entity) world.getEntitiesOfClass(clazz, AABB.ofSize(new Vec3(x, y, z), range, range, range), e -> true).stream().sorted(Comparator.comparingDouble(e -> e.distanceToSqr(x, y, z))).findFirst().orElse(null);
	}
}