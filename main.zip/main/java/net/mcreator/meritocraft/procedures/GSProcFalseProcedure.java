package net.mcreator.meritocraft.procedures;

import net.minecraft.world.level.GameType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;

import net.mcreator.meritocraft.network.MeritocraftModVariables;

public class GSProcFalseProcedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		if (entity instanceof Player _plr0 && _plr0.gameMode() == GameType.ADVENTURE) {
			return true;
		}
		return !entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).creative;
	}
}