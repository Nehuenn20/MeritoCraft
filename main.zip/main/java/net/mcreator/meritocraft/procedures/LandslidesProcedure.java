package net.mcreator.meritocraft.procedures;

import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.BlockPos;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.advancements.AdvancementHolder;

import javax.annotation.Nullable;

@EventBusSubscriber
public class LandslidesProcedure {
	@SubscribeEvent
	public static void onLeftClickBlock(PlayerInteractEvent.LeftClickBlock event) {
		execute(event, event.getLevel(), event.getPos().getX(), event.getPos().getY(), event.getPos().getZ(), event.getLevel().getBlockState(event.getPos()), event.getEntity());
	}

	public static void execute(LevelAccessor world, double x, double y, double z, BlockState blockstate, Entity entity) {
		execute(null, world, x, y, z, blockstate, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, BlockState blockstate, Entity entity) {
		if (entity == null)
			return;
		double ystring = 0;
		if (blockstate.getBlock() == Blocks.SAND && world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("desert")) && world.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (int) x, (int) z) - 6 < y
				&& world.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (int) x, (int) z) + 3 > y) {
			ystring = y;
			for (int index0 = 0; index0 < 15; index0++) {
				if ((world.getBlockState(BlockPos.containing(x, ystring, z))).getBlock() == Blocks.SAND || (world.getBlockState(BlockPos.containing(x, ystring, z))).getBlock() == Blocks.AIR) {
					ystring = ystring - 1;
				} else if ((world.getBlockState(BlockPos.containing(x, ystring, z))).getBlock() == Blocks.STONE || (world.getBlockState(BlockPos.containing(x, ystring, z))).getBlock() == Blocks.SANDSTONE) {
					for (int index1 = 0; index1 < Mth.nextInt(RandomSource.create(), 3, 10); index1++) {
						if (world instanceof ServerLevel _level)
							_level.holderOrThrow(ResourceKey.create(Registries.CONFIGURED_FEATURE, ResourceLocation.parse("meritocraft:landslide"))).value().place(_level, _level.getChunkSource().getGenerator(), _level.getRandom(),
									BlockPos.containing(x, y, z));
					}
					if (entity instanceof ServerPlayer _player && _player.level() instanceof ServerLevel _level) {
						AdvancementHolder _adv = _level.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_landslide"));
						if (_adv != null) {
							AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv);
							if (!_ap.isDone()) {
								for (String criteria : _ap.getRemainingCriteria())
									_player.getAdvancements().award(_adv, criteria);
							}
						}
					}
					break;
				}
			}
		}
	}
}