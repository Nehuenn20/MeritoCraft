package net.mcreator.meritocraft.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.meritocraft.entity.VillagerBanditEntity;

public class VBTextureT5Procedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		if ((entity instanceof VillagerBanditEntity _datEntI ? _datEntI.getEntityData().get(VillagerBanditEntity.DATA_type) : 0) == 5) {
			return true;
		}
		return false;
	}
}