package net.mcreator.meritocraft.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.animal.horse.Horse;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;

import java.util.Comparator;

public class AsthmaEndsProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof LivingEntity _entity) {
			_entity.getAttribute(Attributes.MOVEMENT_SPEED).removeModifier(ResourceLocation.parse("meritocraft:asthma"));
		}
		if (entity instanceof Player) {
			entity.getPersistentData().putDouble("asthmalevel", 0);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("El ataque de asma ha cesado"), true);
		}
		if (entity instanceof Horse && entity instanceof LivingEntity _livingEntity5 && _livingEntity5.getAttribute(Attributes.MOVEMENT_SPEED).hasModifier(ResourceLocation.parse("meritocraft:asthma.base"))) {
			if ((findEntityInWorldRange(world, Player.class, x, y, z, 4)) instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("El ataque de asma de tu caballo ha cesado"), true);
		}
	}

	private static Entity findEntityInWorldRange(LevelAccessor world, Class<? extends Entity> clazz, double x, double y, double z, double range) {
		return (Entity) world.getEntitiesOfClass(clazz, AABB.ofSize(new Vec3(x, y, z), range, range, range), e -> true).stream().sorted(Comparator.comparingDouble(e -> e.distanceToSqr(x, y, z))).findFirst().orElse(null);
	}
}