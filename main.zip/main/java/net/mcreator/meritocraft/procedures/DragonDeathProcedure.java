package net.mcreator.meritocraft.procedures;

import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.ChatFormatting;

import net.mcreator.meritocraft.network.MeritocraftModVariables;

import javax.annotation.Nullable;

import java.util.ArrayList;

@EventBusSubscriber
public class DragonDeathProcedure {
	@SubscribeEvent
	public static void onEntityAttacked(LivingIncomingDamageEvent event) {
		if (event.getEntity() != null) {
			execute(event, event.getEntity().level(), event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getSource(), event.getEntity(), event.getAmount());
		}
	}

	public static void execute(LevelAccessor world, double x, double y, double z, DamageSource damagesource, Entity entity, double amount) {
		execute(null, world, x, y, z, damagesource, entity, amount);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, DamageSource damagesource, Entity entity, double amount) {
		if (damagesource == null || entity == null)
			return;
		double slayers = 0;
		if (entity instanceof EnderDragon) {
			if ((entity.level().dimension()) == Level.END) {
				if (damagesource.is(DamageTypes.EXPLOSION)) {
					if (event instanceof LivingIncomingDamageEvent _event) {
						_event.setAmount(0);
					}
				} else {
					if (amount > (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)) {
						if (event instanceof LivingIncomingDamageEvent _event) {
							_event.setAmount(0);
						}
						if (entity == MeritocraftModVariables.dragon_king) {
							if (!(MeritocraftModVariables.dragon_queen == null)) {
								if (MeritocraftModVariables.dragon_queen instanceof LivingEntity _entity)
									_entity.setHealth(400);
								if (MeritocraftModVariables.dragon_queen instanceof LivingEntity _livingEntity9 && _livingEntity9.getAttributes().hasAttribute(Attributes.SCALE))
									_livingEntity9.getAttribute(Attributes.SCALE).setBaseValue(1.5);
								for (Entity entityiterator : new ArrayList<>(world.players())) {
									if ((entityiterator.level().dimension()) == Level.END) {
										if (Math.abs(entityiterator.getZ()) <= 300 && Math.abs(entityiterator.getX()) <= 300) {
											if (entityiterator instanceof Player _player17 && !_player17.level().isClientSide()) {
												_player17.displayClientMessage(Component.literal("\u00A1La Reina Drag\u00F3n se ha enfurecido!").withStyle(ChatFormatting.DARK_PURPLE), false);
											}
										}
									}
								}
							}
							if (!entity.level().isClientSide())
								entity.discard();
							if (world instanceof ServerLevel _level)
								_level.sendParticles(ParticleTypes.EXPLOSION, x, y, z, 5, 4, 4, 4, 1);
							if (world instanceof Level _level && !_level.isClientSide())
								_level.explode(null, x, y, z, 2, Level.ExplosionInteraction.MOB);
						} else if (entity == MeritocraftModVariables.dragon_queen) {
							if (MeritocraftModVariables.dragon_king == null) {
								for (Entity entityiterator : new ArrayList<>(world.players())) {
									if ((entityiterator.level().dimension()) == Level.END) {
										if (Math.abs(entityiterator.getZ()) <= 300 && Math.abs(entityiterator.getX()) <= 300) {
											{
												MeritocraftModVariables.PlayerVariables _vars = entityiterator.getData(MeritocraftModVariables.PLAYER_VARIABLES);
												_vars.dragonSlayer = true;
												_vars.markSyncDirty();
											}
											slayers = slayers + 1;
											if (entityiterator instanceof Player _player31 && !_player31.level().isClientSide()) {
												_player31.displayClientMessage(
														Component.literal("Solo quienes, en su vida actual, sean testigos de la muerte del drag\u00F3n pueden traspasar la barrera del End").withStyle(ChatFormatting.LIGHT_PURPLE), false);
											}
										}
									}
								}
								if (slayers > 1) {
									for (Entity entityiterator : new ArrayList<>(world.players())) {
										if ((entityiterator.level().dimension()) == Level.END) {
											if (Math.abs(entityiterator.getZ()) <= 300 && Math.abs(entityiterator.getX()) <= 300) {
												if (entityiterator instanceof Player _player40 && !_player40.level().isClientSide()) {
													_player40.displayClientMessage(Component.literal("Pero solo un jugador testigo puede abandonar el End con vida...").withStyle(ChatFormatting.DARK_PURPLE), false);
												}
											}
										}
									}
								}
							} else {
								if (entity instanceof LivingEntity _entity)
									_entity.setHealth(100);
								for (Entity entityiterator : new ArrayList<>(world.players())) {
									if ((entityiterator.level().dimension()) == Level.END) {
										if (Math.abs(entityiterator.getZ()) <= 300 && Math.abs(entityiterator.getX()) <= 300) {
											if (entityiterator instanceof Player _player50 && !_player50.level().isClientSide()) {
												_player50.displayClientMessage(Component.literal("\u00A1La Reina Drag\u00F3n se recupera gracias al poder del Rey Drag\u00F3n!").withStyle(ChatFormatting.LIGHT_PURPLE), false);
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}