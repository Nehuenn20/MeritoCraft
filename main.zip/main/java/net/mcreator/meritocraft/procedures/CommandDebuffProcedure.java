package net.mcreator.meritocraft.procedures;

public class CommandDebuffProcedure {
	public static void execute() {
	}
}