package net.mcreator.meritocraft.procedures;

import net.neoforged.neoforge.event.tick.EntityTickEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.animal.horse.Horse;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.advancements.AdvancementHolder;

import net.mcreator.meritocraft.init.MeritocraftModMobEffects;

import javax.annotation.Nullable;

import java.util.Comparator;

@EventBusSubscriber
public class AsthmaticHorseProcedure {
	@SubscribeEvent
	public static void onEntityTick(EntityTickEvent.Pre event) {
		execute(event, event.getEntity().level(), event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getEntity());
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		execute(null, world, x, y, z, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		double asthma = 0;
		if (entity instanceof Horse) {
			if (entity instanceof LivingEntity _livingEntity1 && _livingEntity1.getAttribute(Attributes.MOVEMENT_SPEED).hasModifier(ResourceLocation.parse("meritocraft:asthma.base"))) {
				if (!(entity instanceof LivingEntity _livEnt2 && _livEnt2.hasEffect(MeritocraftModMobEffects.CLEAR_BREATHING))) {
					if (entity.isVehicle()) {
						entity.getPersistentData().putDouble("asthma", (entity.getPersistentData().getDoubleOr("asthma", 0) + 1));
						asthma = entity.getPersistentData().getDoubleOr("asthma", 0);
						if (asthma == 400) {
							if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
								_entity.addEffect(new MobEffectInstance(MeritocraftModMobEffects.ASTHMA, -1, 0, false, false));
							if ((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(MeritocraftModMobEffects.ASTHMA) ? _livEnt.getEffect(MeritocraftModMobEffects.ASTHMA).getAmplifier() : 0) == 0) {
								if ((findEntityInWorldRange(world, Player.class, x, y, z, 4)) instanceof Player _player && !_player.level().isClientSide())
									_player.displayClientMessage(Component.literal("\u00A1Tu caballo tiene un ataque de asma!"), true);
							}
						}
						if (asthma == 800) {
							if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
								_entity.addEffect(new MobEffectInstance(MeritocraftModMobEffects.ASTHMA, -1, 1, false, false));
							if ((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(MeritocraftModMobEffects.ASTHMA) ? _livEnt.getEffect(MeritocraftModMobEffects.ASTHMA).getAmplifier() : 0) == 1) {
								if ((findEntityInWorldRange(world, Player.class, x, y, z, 4)) instanceof Player _player && !_player.level().isClientSide())
									_player.displayClientMessage(Component.literal("\u00A1El asma de tu caballo acaba de empeorar!"), true);
							}
						}
						if (asthma == 1200) {
							if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
								_entity.addEffect(new MobEffectInstance(MeritocraftModMobEffects.ASTHMA, -1, 2, false, false));
							if ((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(MeritocraftModMobEffects.ASTHMA) ? _livEnt.getEffect(MeritocraftModMobEffects.ASTHMA).getAmplifier() : 0) == 2) {
								if ((findEntityInWorldRange(world, Player.class, x, y, z, 4)) instanceof Player _player && !_player.level().isClientSide())
									_player.displayClientMessage(Component.literal("\u00A1El asma de tu caballo acaba de empeorar!"), true);
								if ((findEntityInWorldRange(world, Player.class, x, y, z, 4)) instanceof ServerPlayer _player && _player.level() instanceof ServerLevel _level) {
									AdvancementHolder _adv = _level.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_asthma"));
									if (_adv != null) {
										AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv);
										if (!_ap.isDone()) {
											for (String criteria : _ap.getRemainingCriteria())
												_player.getAdvancements().award(_adv, criteria);
										}
									}
								}
							}
						}
						if (asthma == 1600) {
							if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
								_entity.addEffect(new MobEffectInstance(MeritocraftModMobEffects.ASTHMA, -1, 3, false, false));
							if ((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(MeritocraftModMobEffects.ASTHMA) ? _livEnt.getEffect(MeritocraftModMobEffects.ASTHMA).getAmplifier() : 0) == 3) {
								if ((findEntityInWorldRange(world, Player.class, x, y, z, 4)) instanceof Player _player && !_player.level().isClientSide())
									_player.displayClientMessage(Component.literal("\u00A1El asma de tu caballo acaba de empeorar!"), true);
							}
						}
						if (asthma == 2000) {
							if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
								_entity.addEffect(new MobEffectInstance(MeritocraftModMobEffects.ASTHMA, -1, 4, false, false));
							if ((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(MeritocraftModMobEffects.ASTHMA) ? _livEnt.getEffect(MeritocraftModMobEffects.ASTHMA).getAmplifier() : 0) == 4) {
								if ((findEntityInWorldRange(world, Player.class, x, y, z, 4)) instanceof Player _player && !_player.level().isClientSide())
									_player.displayClientMessage(Component.literal("\u00A1El asma de tu caballo acaba de empeorar!"), true);
							}
						}
						if (asthma == 2400) {
							if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
								_entity.addEffect(new MobEffectInstance(MeritocraftModMobEffects.ASTHMA, -1, 5, false, false));
							if ((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(MeritocraftModMobEffects.ASTHMA) ? _livEnt.getEffect(MeritocraftModMobEffects.ASTHMA).getAmplifier() : 0) == 5) {
								if ((findEntityInWorldRange(world, Player.class, x, y, z, 4)) instanceof Player _player && !_player.level().isClientSide())
									_player.displayClientMessage(Component.literal("\u00A1El asma de tu caballo acaba de empeorar!"), true);
							}
						}
						if (asthma == 2800) {
							if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
								_entity.addEffect(new MobEffectInstance(MeritocraftModMobEffects.ASTHMA, -1, 6, false, false));
							if ((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(MeritocraftModMobEffects.ASTHMA) ? _livEnt.getEffect(MeritocraftModMobEffects.ASTHMA).getAmplifier() : 0) == 6) {
								if ((findEntityInWorldRange(world, Player.class, x, y, z, 4)) instanceof Player _player && !_player.level().isClientSide())
									_player.displayClientMessage(Component.literal("\u00A1El asma de tu caballo acaba de empeorar!"), true);
							}
						}
						if (asthma == 3200) {
							if ((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(MeritocraftModMobEffects.ASTHMA) ? _livEnt.getEffect(MeritocraftModMobEffects.ASTHMA).getAmplifier() : 0) == 6) {
								if ((findEntityInWorldRange(world, Player.class, x, y, z, 4)) instanceof Player _player && !_player.level().isClientSide())
									_player.displayClientMessage(Component.literal("\u00A1El asma de tu caballo acaba de empeorar!"), true);
							}
							if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
								_entity.addEffect(new MobEffectInstance(MeritocraftModMobEffects.ASTHMA, -1, 7, false, false));
						}
					} else {
						if (entity.getPersistentData().getDoubleOr("asthma", 0) >= 2) {
							entity.getPersistentData().putDouble("asthma", (entity.getPersistentData().getDoubleOr("asthma", 0) - 2));
							asthma = entity.getPersistentData().getDoubleOr("asthma", 0);
						}
					}
					if (entity instanceof LivingEntity _livEnt45 && _livEnt45.hasEffect(MeritocraftModMobEffects.ASTHMA) && asthma < 2
							&& (entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(MeritocraftModMobEffects.ASTHMA) ? _livEnt.getEffect(MeritocraftModMobEffects.ASTHMA).getAmplifier() : 0) == 0) {
						if (entity instanceof LivingEntity _entity)
							_entity.removeEffect(MeritocraftModMobEffects.ASTHMA);
					}
				}
			}
		}
	}

	private static Entity findEntityInWorldRange(LevelAccessor world, Class<? extends Entity> clazz, double x, double y, double z, double range) {
		return (Entity) world.getEntitiesOfClass(clazz, AABB.ofSize(new Vec3(x, y, z), range, range, range), e -> true).stream().sorted(Comparator.comparingDouble(e -> e.distanceToSqr(x, y, z))).findFirst().orElse(null);
	}
}