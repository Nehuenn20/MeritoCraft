package net.mcreator.meritocraft.procedures;

import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.entity.animal.horse.Mule;
import net.minecraft.world.entity.animal.horse.Horse;
import net.minecraft.world.entity.animal.horse.Donkey;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.resources.ResourceLocation;

import javax.annotation.Nullable;

@EventBusSubscriber
public class HorseSpawnProcedure {
	@SubscribeEvent
	public static void onEntitySpawned(EntityJoinLevelEvent event) {
		execute(event, event.getEntity());
	}

	public static void execute(Entity entity) {
		execute(null, entity);
	}

	private static void execute(@Nullable Event event, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Horse && entity.getPersistentData().getBooleanOr("asthma.healed", false) == false) {
			if (!(entity instanceof LivingEntity _livingEntity2 && _livingEntity2.getAttribute(Attributes.MOVEMENT_SPEED).hasModifier(ResourceLocation.parse("meritocraft:asthma.base")))) {
				if (entity instanceof LivingEntity _entity) {
					AttributeModifier modifier = new AttributeModifier(ResourceLocation.parse("meritocraft:asthma.base"), (Mth.nextDouble(RandomSource.create(), -0.3, -0.1)), AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
					if (!_entity.getAttribute(Attributes.MOVEMENT_SPEED).hasModifier(modifier.id())) {
						_entity.getAttribute(Attributes.MOVEMENT_SPEED).addPermanentModifier(modifier);
					}
				}
			}
		} else if (entity instanceof Donkey) {
			if (!(entity instanceof LivingEntity _livingEntity6 && _livingEntity6.getAttribute(Attributes.MOVEMENT_SPEED).hasModifier(ResourceLocation.parse("meritocraft:laziness.base")))) {
				if (entity instanceof LivingEntity _entity) {
					AttributeModifier modifier = new AttributeModifier(ResourceLocation.parse("meritocraft:laziness.base"), (Mth.nextDouble(RandomSource.create(), -0.2, -0.1)), AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
					if (!_entity.getAttribute(Attributes.MOVEMENT_SPEED).hasModifier(modifier.id())) {
						_entity.getAttribute(Attributes.MOVEMENT_SPEED).addPermanentModifier(modifier);
					}
				}
			}
		} else if (entity instanceof Mule) {
			if (!(entity instanceof LivingEntity _livingEntity10 && _livingEntity10.getAttribute(Attributes.MOVEMENT_SPEED).hasModifier(ResourceLocation.parse("meritocraft:laziness.base")))) {
				if (entity instanceof LivingEntity _entity) {
					AttributeModifier modifier = new AttributeModifier(ResourceLocation.parse("meritocraft:laziness.base"), (Mth.nextDouble(RandomSource.create(), -0.4, -0.2)), AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
					if (!_entity.getAttribute(Attributes.MOVEMENT_SPEED).hasModifier(modifier.id())) {
						_entity.getAttribute(Attributes.MOVEMENT_SPEED).addPermanentModifier(modifier);
					}
				}
			}
		}
	}
}