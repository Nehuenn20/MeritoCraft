package net.mcreator.meritocraft.procedures;

import net.neoforged.neoforge.items.IItemHandlerModifiable;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.InteractionHand;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.advancements.AdvancementHolder;

import javax.annotation.Nullable;

@EventBusSubscriber
public class VillagerThiefProcedure {
	@SubscribeEvent
	public static void onRightClickEntity(PlayerInteractEvent.EntityInteract event) {
		if (event.getHand() != InteractionHand.MAIN_HAND)
			return;
		execute(event, event.getLevel(), event.getTarget(), event.getEntity());
	}

	public static void execute(LevelAccessor world, Entity entity, Entity sourceentity) {
		execute(null, world, entity, sourceentity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		double randomnumber = 0;
		double emeraldsmainhand = 0;
		double emeraldsoffhand = 0;
		double emeralds = 0;
		if (entity instanceof Villager) {
			if ((sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.EMERALD) {
				emeraldsmainhand = (sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getCount();
			}
			if ((sourceentity instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY).getItem() == Items.EMERALD) {
				emeraldsoffhand = (sourceentity instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY).getCount();
			}
			if (sourceentity.getCapability(Capabilities.ItemHandler.ENTITY, null) instanceof IItemHandlerModifiable _modHandlerIter) {
				for (int _idx = 0; _idx < _modHandlerIter.getSlots(); _idx++) {
					ItemStack itemstackiterator = _modHandlerIter.getStackInSlot(_idx).copy();
					if (itemstackiterator.getItem() == Items.EMERALD) {
						emeralds = emeralds + itemstackiterator.getCount();
					}
				}
			}
			if (emeralds - (emeraldsmainhand + emeraldsoffhand) > 0) {
				if (sourceentity instanceof ServerPlayer _player && _player.level() instanceof ServerLevel _level) {
					AdvancementHolder _adv = _level.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_villager_thief"));
					if (_adv != null) {
						AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv);
						if (!_ap.isDone()) {
							for (String criteria : _ap.getRemainingCriteria())
								_player.getAdvancements().award(_adv, criteria);
						}
					}
				}
				randomnumber = Math.random();
				if (0.2 > randomnumber) {
					if (sourceentity instanceof Player _player && !_player.level().isClientSide())
						_player.displayClientMessage(Component.literal("<Aldeano> Gracias por la donaci\u00F3n"), false);
				} else if (0.4 > randomnumber) {
					if (sourceentity instanceof Player _player && !_player.level().isClientSide())
						_player.displayClientMessage(Component.literal("<Aldeano> No las volv\u00E9s a ver, gato"), false);
				} else if (0.6 > randomnumber) {
					if (sourceentity instanceof Player _player && !_player.level().isClientSide())
						_player.displayClientMessage(Component.literal("<Aldeano> Uh, justo lo que me faltaba para el pan"), false);
				} else if (0.8 > randomnumber) {
					if (sourceentity instanceof Player _player && !_player.level().isClientSide())
						_player.displayClientMessage(Component.literal("<Aldeano> Nos re vimos gil"), false);
				} else {
					if (sourceentity instanceof Player _player && !_player.level().isClientSide())
						_player.displayClientMessage(Component.literal("<Aldeano> \u00A1DAME TODO O TE METO UN TIRO!"), false);
				}
				if (sourceentity instanceof Player _player) {
					ItemStack _stktoremove = new ItemStack(Items.EMERALD);
					_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove.getItem() == p.getItem(), (int) emeralds, _player.inventoryMenu.getCraftSlots());
				}
				if (emeraldsmainhand > 0) {
					if (sourceentity instanceof LivingEntity _entity) {
						ItemStack _setstack21 = new ItemStack(Items.EMERALD).copy();
						_setstack21.setCount((int) emeraldsmainhand);
						_entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack21);
						if (_entity instanceof Player _player)
							_player.getInventory().setChanged();
					}
				}
				if (emeraldsoffhand > 0) {
					if (sourceentity instanceof LivingEntity _entity) {
						ItemStack _setstack22 = new ItemStack(Items.EMERALD).copy();
						_setstack22.setCount((int) emeraldsoffhand);
						_entity.setItemInHand(InteractionHand.OFF_HAND, _setstack22);
						if (_entity instanceof Player _player)
							_player.getInventory().setChanged();
					}
				}
			}
		}
	}
}