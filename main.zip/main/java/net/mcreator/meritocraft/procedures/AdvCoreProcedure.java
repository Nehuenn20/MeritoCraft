package net.mcreator.meritocraft.procedures;

import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.event.entity.player.AdvancementEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.meritocraft.network.ToastPackageMessage;
import net.mcreator.meritocraft.network.MeritocraftModVariables;

import javax.annotation.Nullable;

@EventBusSubscriber
public class AdvCoreProcedure {
	@SubscribeEvent
	public static void onAdvancement(AdvancementEvent.AdvancementEarnEvent event) {
		execute(event, event.getEntity());
	}

	public static void execute(Entity entity) {
		execute(null, entity);
	}

	private static void execute(@Nullable Event event, Entity entity) {
		if (entity == null)
			return;
		if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).mainAdvs == false) {
			if (entity instanceof ServerPlayer _plr0 && _plr0.level() instanceof ServerLevel _serverLevel0
					&& _plr0.getAdvancements().getOrStartProgress(_serverLevel0.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_mod"))).isDone() && entity instanceof ServerPlayer _plr1
					&& _plr1.level() instanceof ServerLevel _serverLevel1 && _plr1.getAdvancements().getOrStartProgress(_serverLevel1.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_exploding_wood"))).isDone()
					&& entity instanceof ServerPlayer _plr2 && _plr2.level() instanceof ServerLevel _serverLevel2
					&& _plr2.getAdvancements().getOrStartProgress(_serverLevel2.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_lightning"))).isDone() && entity instanceof ServerPlayer _plr3
					&& _plr3.level() instanceof ServerLevel _serverLevel3 && _plr3.getAdvancements().getOrStartProgress(_serverLevel3.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_magic_catalyst"))).isDone()
					&& entity instanceof ServerPlayer _plr4 && _plr4.level() instanceof ServerLevel _serverLevel4
					&& _plr4.getAdvancements().getOrStartProgress(_serverLevel4.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_fake_pig"))).isDone() && entity instanceof ServerPlayer _plr5
					&& _plr5.level() instanceof ServerLevel _serverLevel5 && _plr5.getAdvancements().getOrStartProgress(_serverLevel5.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_crapest"))).isDone()
					&& entity instanceof ServerPlayer _plr6 && _plr6.level() instanceof ServerLevel _serverLevel6
					&& _plr6.getAdvancements().getOrStartProgress(_serverLevel6.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_no_peaceful"))).isDone() && entity instanceof ServerPlayer _plr7
					&& _plr7.level() instanceof ServerLevel _serverLevel7 && _plr7.getAdvancements().getOrStartProgress(_serverLevel7.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_difficulty_item"))).isDone()
					&& entity instanceof ServerPlayer _plr8 && _plr8.level() instanceof ServerLevel _serverLevel8
					&& _plr8.getAdvancements().getOrStartProgress(_serverLevel8.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_shield_slowness"))).isDone() && entity instanceof ServerPlayer _plr9
					&& _plr9.level() instanceof ServerLevel _serverLevel9 && _plr9.getAdvancements().getOrStartProgress(_serverLevel9.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_curse"))).isDone()
					&& entity instanceof ServerPlayer _plr10 && _plr10.level() instanceof ServerLevel _serverLevel10
					&& _plr10.getAdvancements().getOrStartProgress(_serverLevel10.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_hot_potato"))).isDone() && entity instanceof ServerPlayer _plr11
					&& _plr11.level() instanceof ServerLevel _serverLevel11 && _plr11.getAdvancements().getOrStartProgress(_serverLevel11.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_hot_bucket"))).isDone()
					&& entity instanceof ServerPlayer _plr12 && _plr12.level() instanceof ServerLevel _serverLevel12
					&& _plr12.getAdvancements().getOrStartProgress(_serverLevel12.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_creeper"))).isDone() && entity instanceof ServerPlayer _plr13
					&& _plr13.level() instanceof ServerLevel _serverLevel13 && _plr13.getAdvancements().getOrStartProgress(_serverLevel13.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_gei"))).isDone()
					&& entity instanceof ServerPlayer _plr14 && _plr14.level() instanceof ServerLevel _serverLevel14
					&& _plr14.getAdvancements().getOrStartProgress(_serverLevel14.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_ice_death"))).isDone() && entity instanceof ServerPlayer _plr15
					&& _plr15.level() instanceof ServerLevel _serverLevel15 && _plr15.getAdvancements().getOrStartProgress(_serverLevel15.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_boiled_water"))).isDone()
					&& entity instanceof ServerPlayer _plr16 && _plr16.level() instanceof ServerLevel _serverLevel16
					&& _plr16.getAdvancements().getOrStartProgress(_serverLevel16.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_explosive_chest"))).isDone() && entity instanceof ServerPlayer _plr17
					&& _plr17.level() instanceof ServerLevel _serverLevel17 && _plr17.getAdvancements().getOrStartProgress(_serverLevel17.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_villager_thief"))).isDone()
					&& entity instanceof ServerPlayer _plr18 && _plr18.level() instanceof ServerLevel _serverLevel18
					&& _plr18.getAdvancements().getOrStartProgress(_serverLevel18.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_raw_food"))).isDone() && entity instanceof ServerPlayer _plr19
					&& _plr19.level() instanceof ServerLevel _serverLevel19 && _plr19.getAdvancements().getOrStartProgress(_serverLevel19.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_bugrock"))).isDone()
					&& entity instanceof ServerPlayer _plr20 && _plr20.level() instanceof ServerLevel _serverLevel20
					&& _plr20.getAdvancements().getOrStartProgress(_serverLevel20.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_spontaneous_combustion"))).isDone() && entity instanceof ServerPlayer _plr21
					&& _plr21.level() instanceof ServerLevel _serverLevel21 && _plr21.getAdvancements().getOrStartProgress(_serverLevel21.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_otk"))).isDone()
					&& entity instanceof ServerPlayer _plr22 && _plr22.level() instanceof ServerLevel _serverLevel22
					&& _plr22.getAdvancements().getOrStartProgress(_serverLevel22.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_wither"))).isDone() && entity instanceof ServerPlayer _plr23
					&& _plr23.level() instanceof ServerLevel _serverLevel23 && _plr23.getAdvancements().getOrStartProgress(_serverLevel23.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_herobrine"))).isDone()
					&& entity instanceof ServerPlayer _plr24 && _plr24.level() instanceof ServerLevel _serverLevel24
					&& _plr24.getAdvancements().getOrStartProgress(_serverLevel24.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_herobrine_2"))).isDone() && entity instanceof ServerPlayer _plr25
					&& _plr25.level() instanceof ServerLevel _serverLevel25 && _plr25.getAdvancements().getOrStartProgress(_serverLevel25.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_elite_golem"))).isDone()
					&& entity instanceof ServerPlayer _plr26 && _plr26.level() instanceof ServerLevel _serverLevel26
					&& _plr26.getAdvancements().getOrStartProgress(_serverLevel26.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_player_message"))).isDone() && entity instanceof ServerPlayer _plr27
					&& _plr27.level() instanceof ServerLevel _serverLevel27 && _plr27.getAdvancements().getOrStartProgress(_serverLevel27.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_bandit"))).isDone()
					&& entity instanceof ServerPlayer _plr28 && _plr28.level() instanceof ServerLevel _serverLevel28
					&& _plr28.getAdvancements().getOrStartProgress(_serverLevel28.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_bandit_guard"))).isDone() && entity instanceof ServerPlayer _plr29
					&& _plr29.level() instanceof ServerLevel _serverLevel29 && _plr29.getAdvancements().getOrStartProgress(_serverLevel29.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_claustrophobia"))).isDone()
					&& entity instanceof ServerPlayer _plr30 && _plr30.level() instanceof ServerLevel _serverLevel30
					&& _plr30.getAdvancements().getOrStartProgress(_serverLevel30.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_insomnio"))).isDone() && entity instanceof ServerPlayer _plr31
					&& _plr31.level() instanceof ServerLevel _serverLevel31 && _plr31.getAdvancements().getOrStartProgress(_serverLevel31.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_goloso"))).isDone()
					&& entity instanceof ServerPlayer _plr32 && _plr32.level() instanceof ServerLevel _serverLevel32
					&& _plr32.getAdvancements().getOrStartProgress(_serverLevel32.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_slime_eat"))).isDone() && entity instanceof ServerPlayer _plr33
					&& _plr33.level() instanceof ServerLevel _serverLevel33 && _plr33.getAdvancements().getOrStartProgress(_serverLevel33.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_landslide"))).isDone()
					&& entity instanceof ServerPlayer _plr34 && _plr34.level() instanceof ServerLevel _serverLevel34
					&& _plr34.getAdvancements().getOrStartProgress(_serverLevel34.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_fish_tnt"))).isDone() && entity instanceof ServerPlayer _plr35
					&& _plr35.level() instanceof ServerLevel _serverLevel35 && _plr35.getAdvancements().getOrStartProgress(_serverLevel35.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_raw_bread"))).isDone()
					&& entity instanceof ServerPlayer _plr36 && _plr36.level() instanceof ServerLevel _serverLevel36
					&& _plr36.getAdvancements().getOrStartProgress(_serverLevel36.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_steel_wool"))).isDone() && entity instanceof ServerPlayer _plr37
					&& _plr37.level() instanceof ServerLevel _serverLevel37 && _plr37.getAdvancements().getOrStartProgress(_serverLevel37.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_blaze_snowball"))).isDone()
					&& entity instanceof ServerPlayer _plr38 && _plr38.level() instanceof ServerLevel _serverLevel38
					&& _plr38.getAdvancements().getOrStartProgress(_serverLevel38.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_angry_wolf"))).isDone() && entity instanceof ServerPlayer _plr39
					&& _plr39.level() instanceof ServerLevel _serverLevel39 && _plr39.getAdvancements().getOrStartProgress(_serverLevel39.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_pendejo"))).isDone()
					&& entity instanceof ServerPlayer _plr40 && _plr40.level() instanceof ServerLevel _serverLevel40
					&& _plr40.getAdvancements().getOrStartProgress(_serverLevel40.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_asthma"))).isDone() && entity instanceof ServerPlayer _plr41
					&& _plr41.level() instanceof ServerLevel _serverLevel41 && _plr41.getAdvancements().getOrStartProgress(_serverLevel41.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_asthma_2"))).isDone()
					&& entity instanceof ServerPlayer _plr42 && _plr42.level() instanceof ServerLevel _serverLevel42
					&& _plr42.getAdvancements().getOrStartProgress(_serverLevel42.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_asthma_3"))).isDone() && entity instanceof ServerPlayer _plr43
					&& _plr43.level() instanceof ServerLevel _serverLevel43 && _plr43.getAdvancements().getOrStartProgress(_serverLevel43.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_dragon"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.mainAdvs = true;
					_vars.markSyncDirty();
				}
				if (entity instanceof ServerPlayer player44)
					PacketDistributor.sendToPlayer(player44, new ToastPackageMessage("merit"));
			}
		}
	}
}