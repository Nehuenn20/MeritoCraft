package net.mcreator.meritocraft.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.meritocraft.network.MeritocraftModVariables;

public class HintCondition4Procedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		if ((entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).adv4).equals("???")) {
			return true;
		}
		return false;
	}
}