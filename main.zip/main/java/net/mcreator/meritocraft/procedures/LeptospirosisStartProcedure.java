package net.mcreator.meritocraft.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.tags.TagKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class LeptospirosisStartProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity.getType().is(TagKey.create(Registries.ENTITY_TYPE, ResourceLocation.parse("meritocraft:leptospirosis"))) || entity instanceof Player) {
			if (entity instanceof LivingEntity _entity) {
				AttributeModifier modifier = new AttributeModifier(ResourceLocation.parse("meritocraft:leptospirosis"), (-0.1), AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
				if (!_entity.getAttribute(Attributes.MOVEMENT_SPEED).hasModifier(modifier.id())) {
					_entity.getAttribute(Attributes.MOVEMENT_SPEED).addPermanentModifier(modifier);
				}
			}
			if (entity instanceof LivingEntity _entity) {
				AttributeModifier modifier = new AttributeModifier(ResourceLocation.parse("meritocraft:leptospirosis"), (-0.1), AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
				if (!_entity.getAttribute(Attributes.JUMP_STRENGTH).hasModifier(modifier.id())) {
					_entity.getAttribute(Attributes.JUMP_STRENGTH).addPermanentModifier(modifier);
				}
			}
			if (entity instanceof Player) {
				if (entity instanceof LivingEntity _entity) {
					AttributeModifier modifier = new AttributeModifier(ResourceLocation.parse("meritocraft:leptospirosis"), (-0.2), AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
					if (!_entity.getAttribute(Attributes.ATTACK_SPEED).hasModifier(modifier.id())) {
						_entity.getAttribute(Attributes.ATTACK_SPEED).addPermanentModifier(modifier);
					}
				}
			}
		}
	}
}