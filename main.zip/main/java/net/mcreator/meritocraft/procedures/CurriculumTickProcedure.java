package net.mcreator.meritocraft.procedures;

import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.entity.Entity;

import net.mcreator.meritocraft.network.MeritocraftModVariables;

import javax.annotation.Nullable;

@EventBusSubscriber
public class CurriculumTickProcedure {
	@SubscribeEvent
	public static void onPlayerTick(PlayerTickEvent.Post event) {
		execute(event, event.getEntity());
	}

	public static boolean execute(Entity entity) {
		return execute(null, entity);
	}

	private static boolean execute(@Nullable Event event, Entity entity) {
		if (entity == null)
			return false;
		if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).curriculum != 0) {
			{
				MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
				_vars.curriculum = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).curriculum - 1;
				_vars.markSyncDirty();
			}
			return true;
		}
		return false;
	}
}