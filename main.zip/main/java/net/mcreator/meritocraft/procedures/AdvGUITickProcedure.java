package net.mcreator.meritocraft.procedures;

import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.meritocraft.network.MeritocraftModVariables;

public class AdvGUITickProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).adv_book_page == 0) {
			if (entity instanceof ServerPlayer _plr0 && _plr0.level() instanceof ServerLevel _serverLevel0
					&& _plr0.getAdvancements().getOrStartProgress(_serverLevel0.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_mod"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv1 = "Mod instalado satisfactoriamente \u00A1Enhorabuena!";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr1 && _plr1.level() instanceof ServerLevel _serverLevel1
					&& _plr1.getAdvancements().getOrStartProgress(_serverLevel1.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_exploding_wood"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv2 = "Con una es suficiente";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr2 && _plr2.level() instanceof ServerLevel _serverLevel2
					&& _plr2.getAdvancements().getOrStartProgress(_serverLevel2.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_fake_pig"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv3 = "\u00BFEs un creeper? \u00BFEs un cerdo? \u00BFEs un avi\u00F3n?";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr3 && _plr3.level() instanceof ServerLevel _serverLevel3
					&& _plr3.getAdvancements().getOrStartProgress(_serverLevel3.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_crapest"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv4 = "\u00BFFu xo eufgsft? \u00BFHt wq dgueq? \u00BFHt wq bxlpp?";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr4 && _plr4.level() instanceof ServerLevel _serverLevel4
					&& _plr4.getAdvancements().getOrStartProgress(_serverLevel4.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_lightning"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv5 = "\u00A11 GW de potencia!";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr5 && _plr5.level() instanceof ServerLevel _serverLevel5
					&& _plr5.getAdvancements().getOrStartProgress(_serverLevel5.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_pendejo"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv6 = "Pendejo no dura nada";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr6 && _plr6.level() instanceof ServerLevel _serverLevel6
					&& _plr6.getAdvancements().getOrStartProgress(_serverLevel6.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_no_peaceful"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv7 = "\u00A1Aqui no queremos cobardes!";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr7 && _plr7.level() instanceof ServerLevel _serverLevel7
					&& _plr7.getAdvancements().getOrStartProgress(_serverLevel7.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_difficulty_item"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv8 = "\u00A1No cheating!";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr8 && _plr8.level() instanceof ServerLevel _serverLevel8
					&& _plr8.getAdvancements().getOrStartProgress(_serverLevel8.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_shield_slowness"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv9 = "El peso del mundo";
					_vars.markSyncDirty();
				}
			}
		} else if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).adv_book_page == 1) {
			if (entity instanceof ServerPlayer _plr9 && _plr9.level() instanceof ServerLevel _serverLevel9
					&& _plr9.getAdvancements().getOrStartProgress(_serverLevel9.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_curse"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv1 = "Ellos te observan...";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr10 && _plr10.level() instanceof ServerLevel _serverLevel10
					&& _plr10.getAdvancements().getOrStartProgress(_serverLevel10.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_hot_potato"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv2 = "Papa caliente";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr11 && _plr11.level() instanceof ServerLevel _serverLevel11
					&& _plr11.getAdvancements().getOrStartProgress(_serverLevel11.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_hot_bucket"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv3 = "Balde caliente";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr12 && _plr12.level() instanceof ServerLevel _serverLevel12
					&& _plr12.getAdvancements().getOrStartProgress(_serverLevel12.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_creeper"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv4 = "\"T\u00E9cnicamente una opci\u00F3n\"";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr13 && _plr13.level() instanceof ServerLevel _serverLevel13
					&& _plr13.getAdvancements().getOrStartProgress(_serverLevel13.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_gei"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv5 = "Gei gei gei...";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr14 && _plr14.level() instanceof ServerLevel _serverLevel14
					&& _plr14.getAdvancements().getOrStartProgress(_serverLevel14.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_ice_death"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv6 = "33% de chances...";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr15 && _plr15.level() instanceof ServerLevel _serverLevel15
					&& _plr15.getAdvancements().getOrStartProgress(_serverLevel15.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_boiled_water"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv7 = "No todo lo caliente es lava";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr16 && _plr16.level() instanceof ServerLevel _serverLevel16
					&& _plr16.getAdvancements().getOrStartProgress(_serverLevel16.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_explosive_chest"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv8 = "Seguro anti-robos";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr17 && _plr17.level() instanceof ServerLevel _serverLevel17
					&& _plr17.getAdvancements().getOrStartProgress(_serverLevel17.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_villager_thief"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv9 = "\u00A1Bienvenido al conurbano!";
					_vars.markSyncDirty();
				}
			}
		} else if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).adv_book_page == 2) {
			if (entity instanceof ServerPlayer _plr18 && _plr18.level() instanceof ServerLevel _serverLevel18
					&& _plr18.getAdvancements().getOrStartProgress(_serverLevel18.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_raw_food"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv1 = "Intoxicaci\u00F3n alimentaria";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr19 && _plr19.level() instanceof ServerLevel _serverLevel19
					&& _plr19.getAdvancements().getOrStartProgress(_serverLevel19.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_bugrock"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv2 = "\u00A1Bienvenido a Bugrock!";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr20 && _plr20.level() instanceof ServerLevel _serverLevel20
					&& _plr20.getAdvancements().getOrStartProgress(_serverLevel20.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_spontaneous_combustion"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv3 = "Para la pr\u00F3xima trae resistencia al fuego";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr21 && _plr21.level() instanceof ServerLevel _serverLevel21
					&& _plr21.getAdvancements().getOrStartProgress(_serverLevel21.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_otk"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv4 = "\u00A1ONE PUUUUNCH!";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr22 && _plr22.level() instanceof ServerLevel _serverLevel22
					&& _plr22.getAdvancements().getOrStartProgress(_serverLevel22.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_wither"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv5 = "Mitosis";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr23 && _plr23.level() instanceof ServerLevel _serverLevel23
					&& _plr23.getAdvancements().getOrStartProgress(_serverLevel23.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_herobrine"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv6 = "Siempre vigilandote...";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr24 && _plr24.level() instanceof ServerLevel _serverLevel24
					&& _plr24.getAdvancements().getOrStartProgress(_serverLevel24.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_herobrine_2"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv7 = "Regresar\u00E1... Cu\u00E1ndo menos lo esperes...";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr25 && _plr25.level() instanceof ServerLevel _serverLevel25
					&& _plr25.getAdvancements().getOrStartProgress(_serverLevel25.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_elite_golem"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv8 = "Minijefe accidental";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr26 && _plr26.level() instanceof ServerLevel _serverLevel26
					&& _plr26.getAdvancements().getOrStartProgress(_serverLevel26.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_player_message"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv9 = "Lo supon\u00EDa.";
					_vars.markSyncDirty();
				}
			}
		} else if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).adv_book_page == 3) {
			if (entity instanceof ServerPlayer _plr27 && _plr27.level() instanceof ServerLevel _serverLevel27
					&& _plr27.getAdvancements().getOrStartProgress(_serverLevel27.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_bandit"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv1 = "Esto servir\u00E1 para pagar tus impuestos";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr28 && _plr28.level() instanceof ServerLevel _serverLevel28
					&& _plr28.getAdvancements().getOrStartProgress(_serverLevel28.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_bandit_guard"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv2 = "Mala idea...";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr29 && _plr29.level() instanceof ServerLevel _serverLevel29
					&& _plr29.getAdvancements().getOrStartProgress(_serverLevel29.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_claustrophobia"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv3 = "Claustrofobia explosiva";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr30 && _plr30.level() instanceof ServerLevel _serverLevel30
					&& _plr30.getAdvancements().getOrStartProgress(_serverLevel30.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_insomnio"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv4 = "Insomnio explosivo";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr31 && _plr31.level() instanceof ServerLevel _serverLevel31
					&& _plr31.getAdvancements().getOrStartProgress(_serverLevel31.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_goloso"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv5 = "Golosa";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr32 && _plr32.level() instanceof ServerLevel _serverLevel32
					&& _plr32.getAdvancements().getOrStartProgress(_serverLevel32.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_slime_eat"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv6 = "Disfunci\u00F3n er\u00E9ctil";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr33 && _plr33.level() instanceof ServerLevel _serverLevel33
					&& _plr33.getAdvancements().getOrStartProgress(_serverLevel33.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_landslide"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv7 = "Terreno altamente inestable";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr34 && _plr34.level() instanceof ServerLevel _serverLevel34
					&& _plr34.getAdvancements().getOrStartProgress(_serverLevel34.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_fish_tnt"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv8 = "Pesca explosiva inversa";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr35 && _plr35.level() instanceof ServerLevel _serverLevel35
					&& _plr35.getAdvancements().getOrStartProgress(_serverLevel35.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_raw_bread"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv9 = "No pensas comerlo as\u00ED \u00BFo si?";
					_vars.markSyncDirty();
				}
			}
		} else if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).adv_book_page == 4) {
			if (entity instanceof ServerPlayer _plr36 && _plr36.level() instanceof ServerLevel _serverLevel36
					&& _plr36.getAdvancements().getOrStartProgress(_serverLevel36.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_steel_wool"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv1 = "Lana de acero";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr37 && _plr37.level() instanceof ServerLevel _serverLevel37
					&& _plr37.getAdvancements().getOrStartProgress(_serverLevel37.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_blaze_snowball"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv2 = "Mejor trae bolas de nieve :D";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr38 && _plr38.level() instanceof ServerLevel _serverLevel38
					&& _plr38.getAdvancements().getOrStartProgress(_serverLevel38.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_angry_wolf"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv3 = "El mejor amigo del hombre";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr39 && _plr39.level() instanceof ServerLevel _serverLevel39
					&& _plr39.getAdvancements().getOrStartProgress(_serverLevel39.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_magic_catalyst"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv4 = "Boss rush";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr40 && _plr40.level() instanceof ServerLevel _serverLevel40
					&& _plr40.getAdvancements().getOrStartProgress(_serverLevel40.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_asthma"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv5 = "Deber\u00EDas llevar el inhalador contigo";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr41 && _plr41.level() instanceof ServerLevel _serverLevel41
					&& _plr41.getAdvancements().getOrStartProgress(_serverLevel41.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_asthma_2"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv6 = "Se ha ido por ahora, pero volver\u00E1";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr42 && _plr42.level() instanceof ServerLevel _serverLevel42
					&& _plr42.getAdvancements().getOrStartProgress(_serverLevel42.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_asthma_3"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv7 = "El asma de tu caballo se ha curado para siempre";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr43 && _plr43.level() instanceof ServerLevel _serverLevel43
					&& _plr43.getAdvancements().getOrStartProgress(_serverLevel43.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_dragon"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv8 = "Parece que no tienes suficientes m\u00E9ritos a\u00FAn";
					_vars.markSyncDirty();
				}
			}
			if (entity instanceof ServerPlayer _plr44 && _plr44.level() instanceof ServerLevel _serverLevel44
					&& _plr44.getAdvancements().getOrStartProgress(_serverLevel44.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_fin"))).isDone()) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.adv9 = "\u00A1Fin del juego!";
					_vars.markSyncDirty();
				}
			}
		}
	}
}