package net.mcreator.meritocraft.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.meritocraft.network.MeritocraftModVariables;

public class PotionBookSprite3Procedure {
	public static double execute(Entity entity) {
		if (entity == null)
			return 0;
		if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).adv_book_page == 1) {
			return 0;
		}
		return 0;
	}
}