package net.mcreator.meritocraft.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.InteractionHand;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerLevel;

import net.mcreator.meritocraft.entity.CraperEntity;

public class CraperGunpowderStickUseProcedure {
	public static void execute(LevelAccessor world, Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		Entity craper = null;
		double speedMultiplier = 0;
		if (entity.isPassenger()) {
			if ((entity.getVehicle()) instanceof CraperEntity && entity instanceof Player) {
				craper = entity.getVehicle();
				if (craper.getPersistentData().getDoubleOr("boostTime", 0) == craper.getPersistentData().getDoubleOr("boostTotal", 0)) {
					craper.getPersistentData().putDouble("boostTotal", (Mth.nextInt(RandomSource.create(), 140, 980)));
					craper.getPersistentData().putDouble("boostTime", 0);
					if (7 < itemstack.getMaxDamage() - itemstack.getDamageValue()) {
						if (world instanceof ServerLevel _level) {
							itemstack.hurtAndBreak(7, _level, null, _stkprov -> {
							});
						}
					} else {
						if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == itemstack.getItem()) {
							if (entity instanceof LivingEntity _entity) {
								ItemStack _setstack19 = new ItemStack(Items.FISHING_ROD).copy();
								_setstack19.setCount(1);
								_entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack19);
								if (_entity instanceof Player _player)
									_player.getInventory().setChanged();
							}
						} else {
							if (entity instanceof LivingEntity _entity) {
								ItemStack _setstack20 = new ItemStack(Items.FISHING_ROD).copy();
								_setstack20.setCount(1);
								_entity.setItemInHand(InteractionHand.OFF_HAND, _setstack20);
								if (_entity instanceof Player _player)
									_player.getInventory().setChanged();
							}
						}
					}
				}
			}
		}
	}
}