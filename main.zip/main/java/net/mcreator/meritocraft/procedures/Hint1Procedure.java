package net.mcreator.meritocraft.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.meritocraft.network.MeritocraftModVariables;

public class Hint1Procedure {
	public static String execute(Entity entity) {
		if (entity == null)
			return "";
		String hint = "";
		if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).adv_book_page == 0) {
			hint = "Ser\u00EDa un problema si no lo tuvieses...";
		} else if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).adv_book_page == 1) {
			hint = "Intenta usar un item para revivir";
		} else if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).adv_book_page == 2) {
			hint = "Come algo antes de descubrir el fuego";
		} else if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).adv_book_page == 3) {
			hint = "Interact\u00FAa con un tipo de aldeano en concreto";
		} else if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).adv_book_page == 4) {
			hint = "Intenta esquilar el color m\u00E1s raro de cierta criatura";
		}
		return hint;
	}
}