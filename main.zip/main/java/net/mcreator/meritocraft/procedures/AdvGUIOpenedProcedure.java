package net.mcreator.meritocraft.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.meritocraft.network.MeritocraftModVariables;

public class AdvGUIOpenedProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		double page = 0;
		{
			MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
			_vars.adv_book_page = 0;
			_vars.adv1 = "???";
			_vars.adv2 = "???";
			_vars.adv3 = "???";
			_vars.adv4 = "???";
			_vars.adv5 = "???";
			_vars.adv6 = "???";
			_vars.adv7 = "???";
			_vars.adv8 = "???";
			_vars.adv9 = "???";
			_vars.markSyncDirty();
		}
	}
}