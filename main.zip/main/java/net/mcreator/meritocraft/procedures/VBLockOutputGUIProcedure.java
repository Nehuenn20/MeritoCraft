package net.mcreator.meritocraft.procedures;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;

import net.mcreator.meritocraft.init.MeritocraftModMenus;

public class VBLockOutputGUIProcedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		if (getAmountInGUISlot(entity, 0) >= 64
				&& (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof MeritocraftModMenus.MenuAccessor _menu1 ? _menu1.getSlots().get(0).getItem() : ItemStack.EMPTY).getItem() == Items.EMERALD) {
			return false;
		}
		return true;
	}

	private static int getAmountInGUISlot(Entity entity, int sltid) {
		if (entity instanceof Player player && player.containerMenu instanceof MeritocraftModMenus.MenuAccessor menuAccessor) {
			ItemStack stack = menuAccessor.getSlots().get(sltid).getItem();
			if (stack != null)
				return stack.getCount();
		}
		return 0;
	}
}