package net.mcreator.meritocraft.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;

import net.mcreator.meritocraft.init.MeritocraftModMenus;

public class DifficultyIEasyProcedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		if (((entity instanceof Player _entity0 && _entity0.containerMenu instanceof MeritocraftModMenus.MenuAccessor _menu0) ? _menu0.getMenuState(2, "DIFICULTAD", 0.0) : 0.0) == 1) {
			return true;
		}
		return false;
	}
}