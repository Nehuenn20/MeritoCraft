package net.mcreator.meritocraft.procedures;

import net.neoforged.neoforge.event.tick.EntityTickEvent;
import net.neoforged.neoforge.common.NeoForgeMod;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.entity.animal.Squid;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.GlowSquid;
import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;

import javax.annotation.Nullable;

@EventBusSubscriber
public class SquidTickProcedure {
	@SubscribeEvent
	public static void onEntityTick(EntityTickEvent.Pre event) {
		execute(event, event.getEntity());
	}

	public static void execute(Entity entity) {
		execute(null, entity);
	}

	private static void execute(@Nullable Event event, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Squid || entity instanceof GlowSquid) {
			if (entity.getPersistentData().getDoubleOr("boost", 0) == 1) {
				if (entity instanceof LivingEntity _entity) {
					_entity.getAttribute(NeoForgeMod.SWIM_SPEED).removeModifier(ResourceLocation.parse("meritocraft:boost"));
				}
				entity.getPersistentData().putDouble("boost", 0);
			} else if (entity.getPersistentData().getDoubleOr("boost", 0) > 1) {
				entity.getPersistentData().putDouble("boost", (entity.getPersistentData().getDoubleOr("boost", 0) - 1));
			}
		}
	}
}