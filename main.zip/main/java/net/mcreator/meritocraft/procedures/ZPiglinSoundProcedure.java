package net.mcreator.meritocraft.procedures;

import net.neoforged.neoforge.event.tick.EntityTickEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.monster.ZombifiedPiglin;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.sounds.SoundSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.BlockPos;

import javax.annotation.Nullable;

@EventBusSubscriber
public class ZPiglinSoundProcedure {
	@SubscribeEvent
	public static void onEntityTick(EntityTickEvent.Pre event) {
		execute(event, event.getEntity().level(), event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getEntity());
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		execute(null, world, x, y, z, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		double sound = 0;
		if (entity instanceof ZombifiedPiglin) {
			if (entity.getPersistentData().getDoubleOr("speak_cooldown", 0) <= 0) {
				if (0.005 > Math.random()) {
					sound = Mth.nextInt(RandomSource.create(), 0, 40);
					if (sound <= 0.05) {
						if (world instanceof Level _level) {
							if (!_level.isClientSide()) {
								_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("meritocraft:piglin_arnau")), SoundSource.HOSTILE, (float) 1.5, 1);
							} else {
								_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("meritocraft:piglin_arnau")), SoundSource.HOSTILE, (float) 1.5, 1, false);
							}
						}
					} else if (sound <= 0.1) {
						if (world instanceof Level _level) {
							if (!_level.isClientSide()) {
								_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("meritocraft:piglin_catalina")), SoundSource.HOSTILE, (float) 1.5, 1);
							} else {
								_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("meritocraft:piglin_catalina")), SoundSource.HOSTILE, (float) 1.5, 1, false);
							}
						}
					} else if (sound <= 0.15) {
						if (world instanceof Level _level) {
							if (!_level.isClientSide()) {
								_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("meritocraft:piglin_emilio")), SoundSource.HOSTILE, (float) 1.5, 1);
							} else {
								_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("meritocraft:piglin_emilio")), SoundSource.HOSTILE, (float) 1.5, 1, false);
							}
						}
					} else if (sound <= 0.2) {
						if (world instanceof Level _level) {
							if (!_level.isClientSide()) {
								_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("meritocraft:piglin_liberto")), SoundSource.HOSTILE, (float) 1.5, 1);
							} else {
								_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("meritocraft:piglin_liberto")), SoundSource.HOSTILE, (float) 1.5, 1, false);
							}
						}
					} else if (sound <= 0.25) {
						if (world instanceof Level _level) {
							if (!_level.isClientSide()) {
								_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("meritocraft:piglin_manuel")), SoundSource.HOSTILE, (float) 1.5, 1);
							} else {
								_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("meritocraft:piglin_manuel")), SoundSource.HOSTILE, (float) 1.5, 1, false);
							}
						}
					} else if (sound <= 0.3) {
						if (world instanceof Level _level) {
							if (!_level.isClientSide()) {
								_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("meritocraft:piglin_teo")), SoundSource.HOSTILE, (float) 1.5, 1);
							} else {
								_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("meritocraft:piglin_teo")), SoundSource.HOSTILE, (float) 1.5, 1, false);
							}
						}
					} else if (sound <= 0.35) {
						if (world instanceof Level _level) {
							if (!_level.isClientSide()) {
								_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("meritocraft:piglin_tomas")), SoundSource.HOSTILE, (float) 1.5, 1);
							} else {
								_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("meritocraft:piglin_tomas")), SoundSource.HOSTILE, (float) 1.5, 1, false);
							}
						}
					} else if (sound <= 0.4) {
						if (world instanceof Level _level) {
							if (!_level.isClientSide()) {
								_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("meritocraft:piglin_japanese")), SoundSource.HOSTILE, (float) 1.5, 1);
							} else {
								_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("meritocraft:piglin_japanese")), SoundSource.HOSTILE, (float) 1.5, 1, false);
							}
						}
					} else if (sound <= 0.45) {
						if (world instanceof Level _level) {
							if (!_level.isClientSide()) {
								_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("meritocraft:piglin_chinese")), SoundSource.HOSTILE, (float) 1.5, 1);
							} else {
								_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("meritocraft:piglin_chinese")), SoundSource.HOSTILE, (float) 1.5, 1, false);
							}
						}
					} else if (sound <= 0.5) {
						if (world instanceof Level _level) {
							if (!_level.isClientSide()) {
								_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("meritocraft:piglin_nuria")), SoundSource.HOSTILE, (float) 1.5, 1);
							} else {
								_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("meritocraft:piglin_nuria")), SoundSource.HOSTILE, (float) 1.5, 1, false);
							}
						}
					} else if (sound <= 0.525) {
						if (world instanceof Level _level) {
							if (!_level.isClientSide()) {
								_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("meritocraft:piglin_larissa")), SoundSource.HOSTILE, (float) 1.5, 1);
							} else {
								_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("meritocraft:piglin_larissa")), SoundSource.HOSTILE, (float) 1.5, 1, false);
							}
						}
					}
					entity.getPersistentData().putDouble("speak_cooldown", 300);
				}
			} else {
				entity.getPersistentData().putDouble("speak_cooldown", (entity.getPersistentData().getDoubleOr("speak_cooldown", 0) - 1));
			}
		}
	}
}