package net.mcreator.meritocraft.procedures;

import net.minecraft.world.level.GameType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;

import net.mcreator.meritocraft.network.MeritocraftModVariables;

public class GSProcButtonSpriteProcedure {
	public static double execute(Entity entity) {
		if (entity == null)
			return 0;
		if (entity instanceof Player _plr0 && _plr0.gameMode() == GameType.ADVENTURE) {
			return 2;
		} else if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).creative) {
			return 0;
		}
		return 1;
	}
}