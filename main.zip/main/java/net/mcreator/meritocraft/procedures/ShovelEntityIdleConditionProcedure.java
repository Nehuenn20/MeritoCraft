package net.mcreator.meritocraft.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.meritocraft.entity.ShovelEntityEntity;

public class ShovelEntityIdleConditionProcedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		return (entity instanceof ShovelEntityEntity _datEntI ? _datEntI.getEntityData().get(ShovelEntityEntity.DATA_actionState) : 0) != 1;
	}
}