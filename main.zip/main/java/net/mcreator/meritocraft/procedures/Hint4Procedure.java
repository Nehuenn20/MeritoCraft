package net.mcreator.meritocraft.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.meritocraft.network.MeritocraftModVariables;

public class Hint4Procedure {
	public static String execute(Entity entity) {
		if (entity == null)
			return "";
		String hint = "";
		if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).adv_book_page == 0) {
			hint = "Hazte A\u00DAN M\u00C1S amigo de los cerdos";
		} else if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).adv_book_page == 1) {
			hint = "M\u00E1talo antes de que explote";
		} else if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).adv_book_page == 2) {
			hint = "Boxea con otro jugador (en single-player puedes con zombies :D)";
		} else if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).adv_book_page == 3) {
			hint = "Desatiende las necesidades b\u00E1sicas de un aldeano com\u00FAn";
		} else if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).adv_book_page == 4) {
			hint = "Fusiona los n\u00FAcleos de los 4 jefes con los de la pesca";
		}
		return hint;
	}
}