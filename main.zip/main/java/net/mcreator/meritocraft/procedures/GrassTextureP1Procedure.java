package net.mcreator.meritocraft.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.meritocraft.entity.GrassEntity;

public class GrassTextureP1Procedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		if ((entity instanceof GrassEntity _datEntI ? _datEntI.getEntityData().get(GrassEntity.DATA_SkinID) : 0) == 1) {
			return true;
		}
		return false;
	}
}