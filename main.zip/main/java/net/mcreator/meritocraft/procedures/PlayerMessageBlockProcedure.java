package net.mcreator.meritocraft.procedures;

import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.entity.Entity;

import net.mcreator.meritocraft.network.MeritocraftModVariables;

import javax.annotation.Nullable;

@EventBusSubscriber
public class PlayerMessageBlockProcedure {
	@SubscribeEvent
	public static void onPlayerTick(PlayerTickEvent.Post event) {
		execute(event, event.getEntity());
	}

	public static void execute(Entity entity) {
		execute(null, entity);
	}

	private static void execute(@Nullable Event event, Entity entity) {
		if (entity == null)
			return;
		if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).chat_block > 0 && entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).chat_block < 400) {
			{
				MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
				_vars.chat_block = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).chat_block + 1;
				_vars.markSyncDirty();
			}
		} else {
			if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).chat_block >= 400) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.chat_block = 0;
					_vars.markSyncDirty();
				}
			}
		}
	}
}