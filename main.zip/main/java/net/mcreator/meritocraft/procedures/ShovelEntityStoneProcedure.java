package net.mcreator.meritocraft.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.meritocraft.entity.ShovelEntityEntity;

public class ShovelEntityStoneProcedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		return (entity instanceof ShovelEntityEntity _datEntI ? _datEntI.getEntityData().get(ShovelEntityEntity.DATA_type) : 0) == 2;
	}
}