package net.mcreator.meritocraft.procedures;

import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.Minecraft;

import net.mcreator.meritocraft.network.MeritocraftModVariables;
import net.mcreator.meritocraft.client.RenderUtils;

import javax.annotation.Nullable;

import com.mojang.blaze3d.vertex.PoseStack;

@EventBusSubscriber(Dist.CLIENT)
public class LoSuponiaProcedure {
	@SubscribeEvent
	public static void onSkyRendered(RenderLevelStageEvent.AfterSky event) {
		Minecraft mc = Minecraft.getInstance();
		execute(event, mc.player.level(), mc.player, event.getPoseStack(), event);
	}

	public static void execute(LevelAccessor world, Entity entity, PoseStack poseStack, RenderLevelStageEvent.AfterSky skyRenderEvent) {
		execute(null, world, entity, poseStack, skyRenderEvent);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, Entity entity, PoseStack poseStack, RenderLevelStageEvent.AfterSky skyRenderEvent) {
		if (entity == null || poseStack == null || skyRenderEvent == null)
			return;
		if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).chat_block > 0 || entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).no_creative) {
			poseStack.pushPose();
			if (Math.round(world.dayTime() % 24000) < 6000) {
				RenderUtils.swapVanillaTexture(RenderUtils.SUN_LOCATION, ResourceLocation.parse("meritocraft:textures/screens/ls1.png"));
			} else {
				RenderUtils.swapVanillaTexture(RenderUtils.SUN_LOCATION, ResourceLocation.parse("meritocraft:textures/screens/ls2.png"));
			}
			if (Math.round(world.dayTime() % 24000) < 18000) {
				RenderUtils.swapVanillaTexture(RenderUtils.MOON_LOCATION, ResourceLocation.parse("meritocraft:textures/screens/lsm1.png"));
			} else {
				RenderUtils.swapVanillaTexture(RenderUtils.MOON_LOCATION, ResourceLocation.parse("meritocraft:textures/screens/lsm2.png"));
			}
			poseStack.popPose();
		} else {
			RenderUtils.swapVanillaTexture(RenderUtils.SUN_LOCATION, RenderUtils.SUN_LOCATION);
			RenderUtils.swapVanillaTexture(RenderUtils.MOON_LOCATION, RenderUtils.MOON_LOCATION);
		}
	}
}