package net.mcreator.meritocraft.procedures;

import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.entity.Entity;

import net.mcreator.meritocraft.network.MeritocraftModVariables;

import javax.annotation.Nullable;

@EventBusSubscriber
public class DragonDamageProcedure {
	@SubscribeEvent
	public static void onEntityAttacked(LivingIncomingDamageEvent event) {
		if (event.getEntity() != null) {
			execute(event, event.getSource().getEntity(), event.getAmount());
		}
	}

	public static void execute(Entity sourceentity, double amount) {
		execute(null, sourceentity, amount);
	}

	private static void execute(@Nullable Event event, Entity sourceentity, double amount) {
		if (sourceentity == null)
			return;
		if (sourceentity == MeritocraftModVariables.dragon_queen) {
			if (MeritocraftModVariables.dragon_king == null) {
				if (event instanceof LivingIncomingDamageEvent _event) {
					_event.setAmount((float) (amount * 2));
				}
			} else {
				if (event instanceof LivingIncomingDamageEvent _event) {
					_event.setAmount((float) (amount * 1.5));
				}
			}
		}
	}
}