package net.mcreator.meritocraft.procedures;

import net.minecraft.world.level.GameType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;

import net.mcreator.meritocraft.network.MeritocraftModVariables;

public class GSProcButtonProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (!(entity instanceof Player _plr0 && _plr0.gameMode() == GameType.ADVENTURE)) {
			if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).creative == true) {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.creative = false;
					_vars.markSyncDirty();
				}
			} else {
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.creative = true;
					_vars.markSyncDirty();
				}
			}
		}
	}
}