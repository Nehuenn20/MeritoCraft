package net.mcreator.meritocraft.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;

import net.mcreator.meritocraft.init.MeritocraftModMenus;

public class DifficultyISliderProcedure {
	public static double execute(Entity entity) {
		if (entity == null)
			return 0;
		double difficulty = 0;
		if (((entity instanceof Player _entity0 && _entity0.containerMenu instanceof MeritocraftModMenus.MenuAccessor _menu0) ? _menu0.getMenuState(2, "DIFICULTAD", 0.0) : 0.0) == 0) {
			difficulty = 0;
		} else if (((entity instanceof Player _entity1 && _entity1.containerMenu instanceof MeritocraftModMenus.MenuAccessor _menu1) ? _menu1.getMenuState(2, "DIFICULTAD", 0.0) : 0.0) == 1) {
			difficulty = 1;
		} else if (((entity instanceof Player _entity2 && _entity2.containerMenu instanceof MeritocraftModMenus.MenuAccessor _menu2) ? _menu2.getMenuState(2, "DIFICULTAD", 0.0) : 0.0) == 2) {
			difficulty = 2;
		} else {
			difficulty = 3;
		}
		return difficulty;
	}
}