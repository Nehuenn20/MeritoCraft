package net.mcreator.meritocraft.procedures;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;

import net.mcreator.meritocraft.entity.ShovelEntityEntity;

public class ShovelEntityOnSpawnProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if ((entity.level().dimension()) == Level.OVERWORLD) {
			if (entity instanceof ShovelEntityEntity _datEntSetI)
				_datEntSetI.getEntityData().set(ShovelEntityEntity.DATA_type, Mth.nextInt(RandomSource.create(), 0, 3));
		} else {
			if (entity instanceof ShovelEntityEntity _datEntSetI)
				_datEntSetI.getEntityData().set(ShovelEntityEntity.DATA_type, Mth.nextInt(RandomSource.create(), 3, 5));
		}
		if ((entity instanceof ShovelEntityEntity _datEntI ? _datEntI.getEntityData().get(ShovelEntityEntity.DATA_type) : 0) == 0) {
			if (entity instanceof LivingEntity _livingEntity8 && _livingEntity8.getAttributes().hasAttribute(Attributes.MAX_HEALTH))
				_livingEntity8.getAttribute(Attributes.MAX_HEALTH).setBaseValue(6);
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth(6);
			if (entity instanceof LivingEntity _livingEntity10 && _livingEntity10.getAttributes().hasAttribute(Attributes.ATTACK_DAMAGE))
				_livingEntity10.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(2.5);
		} else if ((entity instanceof ShovelEntityEntity _datEntI ? _datEntI.getEntityData().get(ShovelEntityEntity.DATA_type) : 0) == 1) {
			if (entity instanceof LivingEntity _livingEntity12 && _livingEntity12.getAttributes().hasAttribute(Attributes.MAX_HEALTH))
				_livingEntity12.getAttribute(Attributes.MAX_HEALTH).setBaseValue(3);
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth(3);
			if (entity instanceof LivingEntity _livingEntity14 && _livingEntity14.getAttributes().hasAttribute(Attributes.ATTACK_DAMAGE))
				_livingEntity14.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(2.5);
		} else if ((entity instanceof ShovelEntityEntity _datEntI ? _datEntI.getEntityData().get(ShovelEntityEntity.DATA_type) : 0) == 2) {
			if (entity instanceof LivingEntity _livingEntity16 && _livingEntity16.getAttributes().hasAttribute(Attributes.MAX_HEALTH))
				_livingEntity16.getAttribute(Attributes.MAX_HEALTH).setBaseValue(9);
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth(9);
			if (entity instanceof LivingEntity _livingEntity18 && _livingEntity18.getAttributes().hasAttribute(Attributes.ATTACK_DAMAGE))
				_livingEntity18.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(3.5);
		} else if ((entity instanceof ShovelEntityEntity _datEntI ? _datEntI.getEntityData().get(ShovelEntityEntity.DATA_type) : 0) == 3) {
			if (entity instanceof LivingEntity _livingEntity20 && _livingEntity20.getAttributes().hasAttribute(Attributes.MAX_HEALTH))
				_livingEntity20.getAttribute(Attributes.MAX_HEALTH).setBaseValue(12);
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth(12);
			if (entity instanceof LivingEntity _livingEntity22 && _livingEntity22.getAttributes().hasAttribute(Attributes.ATTACK_DAMAGE))
				_livingEntity22.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(4.5);
		} else if ((entity instanceof ShovelEntityEntity _datEntI ? _datEntI.getEntityData().get(ShovelEntityEntity.DATA_type) : 0) == 4) {
			if (entity instanceof LivingEntity _livingEntity24 && _livingEntity24.getAttributes().hasAttribute(Attributes.MAX_HEALTH))
				_livingEntity24.getAttribute(Attributes.MAX_HEALTH).setBaseValue(15);
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth(15);
			if (entity instanceof LivingEntity _livingEntity26 && _livingEntity26.getAttributes().hasAttribute(Attributes.ATTACK_DAMAGE))
				_livingEntity26.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(5.5);
		} else {
			if (entity instanceof LivingEntity _livingEntity27 && _livingEntity27.getAttributes().hasAttribute(Attributes.MAX_HEALTH))
				_livingEntity27.getAttribute(Attributes.MAX_HEALTH).setBaseValue(18);
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth(18);
			if (entity instanceof LivingEntity _livingEntity29 && _livingEntity29.getAttributes().hasAttribute(Attributes.ATTACK_DAMAGE))
				_livingEntity29.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(6.5);
		}
	}
}