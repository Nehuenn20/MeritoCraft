package net.mcreator.meritocraft.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.Difficulty;

import net.mcreator.meritocraft.init.MeritocraftModMenus;

public class DifficultyIGUIIsOpenedProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if (world.getDifficulty() == Difficulty.EASY) {
			if (entity instanceof Player _player && _player.containerMenu instanceof MeritocraftModMenus.MenuAccessor _menu)
				_menu.sendMenuStateUpdate(_player, 2, "DIFICULTAD", 1, true);
		} else if (world.getDifficulty() == Difficulty.NORMAL) {
			if (entity instanceof Player _player && _player.containerMenu instanceof MeritocraftModMenus.MenuAccessor _menu)
				_menu.sendMenuStateUpdate(_player, 2, "DIFICULTAD", 2, true);
		} else if (world.getDifficulty() == Difficulty.HARD) {
			if (entity instanceof Player _player && _player.containerMenu instanceof MeritocraftModMenus.MenuAccessor _menu)
				_menu.sendMenuStateUpdate(_player, 2, "DIFICULTAD", 3, true);
		} else {
			if (entity instanceof Player _player && _player.containerMenu instanceof MeritocraftModMenus.MenuAccessor _menu)
				_menu.sendMenuStateUpdate(_player, 2, "DIFICULTAD", 0, true);
		}
	}
}