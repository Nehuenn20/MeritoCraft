package net.mcreator.meritocraft.procedures;

import org.checkerframework.checker.units.qual.s;

import net.neoforged.neoforge.items.IItemHandlerModifiable;
import net.neoforged.neoforge.capabilities.Capabilities;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.InteractionHand;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.advancements.AdvancementHolder;
import net.minecraft.ChatFormatting;

import java.util.Optional;

import java.net.URI;

public class VBStealProcedure {
	public static void execute(LevelAccessor world, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		ItemStack trade = ItemStack.EMPTY;
		double tradeq = 0;
		double randomnumber = 0;
		MutableComponent item = Component.empty();
		MutableComponent source_entity = Component.empty();
		if ((entity.getCapability(Capabilities.ItemHandler.ENTITY, null) instanceof IItemHandlerModifiable _modHandler0 ? _modHandler0.getStackInSlot(1).copy() : ItemStack.EMPTY).getItem() == Blocks.AIR.asItem()
				&& !((sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Blocks.AIR.asItem())) {
			trade = (sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).copy();
			tradeq = (sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getCount();
			if (entity.getCapability(Capabilities.ItemHandler.ENTITY, null) instanceof IItemHandlerModifiable _modHandler) {
				ItemStack _setstack = trade.copy();
				_setstack.setCount((int) tradeq);
				_modHandler.setStackInSlot(1, _setstack);
			}
			if (sourceentity instanceof LivingEntity _entity) {
				ItemStack _setstack8 = new ItemStack(Blocks.AIR).copy();
				_setstack8.setCount(1);
				_entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack8);
				if (_entity instanceof Player _player)
					_player.getInventory().setChanged();
			}
			randomnumber = Math.random();
			if (0.2 > randomnumber) {
				if (sourceentity instanceof Player _player && !_player.level().isClientSide())
					_player.displayClientMessage(Component.literal("Matanga dijo la changa"), false);
			} else if (0.4 > randomnumber) {
				if (sourceentity instanceof Player _player && !_player.level().isClientSide())
					_player.displayClientMessage(Component.literal("\u00A1Steeeeeeeeaaal!"), false);
			} else if (0.6 > randomnumber) {
				if (sourceentity instanceof Player _player && !_player.level().isClientSide())
					_player.displayClientMessage(Component.literal("Uy, \u00E9sto se vende caro"), false);
			} else if (0.8 > randomnumber) {
				if (sourceentity instanceof Player _player && !_player.level().isClientSide())
					_player.displayClientMessage(Component.literal("Si lo quer\u00E9s volver a ver vas a tener que pagar bastante..."), false);
			} else {
				if (sourceentity instanceof Player _player && !_player.level().isClientSide())
					_player.displayClientMessage(Component.literal("\u00C9sto me viene genial para limpiarme el culo"), false);
			}
			item = (MutableComponent) (trade.getDisplayName());
			source_entity = (MutableComponent) sourceentity.getDisplayName();
			if (!world.isClientSide() && world.getServer() != null)
				world.getServer().getPlayerList()
						.broadcastSystemMessage(
								Component.literal("<").append(((MutableComponent) entity.getDisplayName())).append(Component.literal("> \u00A1Vendo ")).append(item.withStyle(ChatFormatting.GOLD))
										.append(Component.literal(" (").append(Component.literal((BuiltInRegistries.ITEM.getKey(trade.getItem()).toString()))).append(Component.literal(")"))
												.append(Component.literal((" x" + new java.text.DecimalFormat("##").format(tradeq)))).withStyle(ChatFormatting.AQUA))
										.append(Component.literal(" reci\u00E9n robado de ")).append(source_entity.withStyle(ChatFormatting.AQUA)).append(Component.literal(" por tan solo "))
										.append(Component.literal("64 esmeraldas").withStyle(ChatFormatting.DARK_GREEN)).append(Component.literal("! Una ganga. Pueden encontrarme en: "))
										.append(ComponentEventGiver.clickEvent(
												Component.literal(
														(new java.text.DecimalFormat("##").format(entity.getX()) + "//" + new java.text.DecimalFormat("##").format(entity.getY()) + "//" + new java.text.DecimalFormat("##").format(entity.getZ())))
														.withStyle(ChatFormatting.AQUA),
												"SUGGEST_COMMAND",
												(new java.text.DecimalFormat("##").format(entity.getX()) + " " + new java.text.DecimalFormat("##").format(entity.getY()) + " " + new java.text.DecimalFormat("##").format(entity.getZ())))),
								false);
			if (sourceentity instanceof ServerPlayer _player && _player.level() instanceof ServerLevel _level) {
				AdvancementHolder _adv = _level.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_bandit"));
				if (_adv != null) {
					AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv);
					if (!_ap.isDone()) {
						for (String criteria : _ap.getRemainingCriteria())
							_player.getAdvancements().award(_adv, criteria);
					}
				}
			}
		}
	}

	private class ComponentEventGiver {
		private static MutableComponent clickEvent(MutableComponent comp, String type, String value) {
			if (type == "OPEN_URL") {
				return comp.withStyle(_style -> _style.withClickEvent(new ClickEvent.OpenUrl(URI.create(value))));
			} else if (type == "OPEN_FILE") {
				return comp.withStyle(_style -> _style.withClickEvent(new ClickEvent.OpenFile(value)));
			} else if (type == "RUN_COMMAND") {
				return comp.withStyle(_style -> _style.withClickEvent(new ClickEvent.RunCommand(value)));
			} else if (type == "COPY_TO_CLIPBOARD") {
				return comp.withStyle(_style -> _style.withClickEvent(new ClickEvent.CopyToClipboard(value)));
			} else if (type == "SUGGEST_COMMAND") {
				return comp.withStyle(_style -> _style.withClickEvent(new ClickEvent.SuggestCommand(value)));
			} else if (type == "CHANGE_PAGE") {
				return comp.withStyle(_style -> _style.withClickEvent(new ClickEvent.ChangePage(Optional.of(value).map(s -> {
					try {
						return Integer.parseInt(s);
					} catch (Exception e) {
					}
					return 0;
				}).orElse(0))));
			}
			return comp;
		}

		private static MutableComponent changePage(MutableComponent comp, int value) {
			return comp.withStyle(_style -> _style.withClickEvent(new ClickEvent.ChangePage(value)));
		}

		private static MutableComponent hoverEvent(MutableComponent comp, MutableComponent value) {
			return comp.withStyle(_style -> _style.withHoverEvent(new HoverEvent.ShowText(value)));
		}

		private static MutableComponent hoverEvent(MutableComponent comp, ItemStack value) {
			return comp.withStyle(_style -> _style.withHoverEvent(new HoverEvent.ShowItem(value)));
		}

		private static MutableComponent hoverEvent(MutableComponent comp, Entity ent) {
			return comp.withStyle(_style -> _style.withHoverEvent(new HoverEvent.ShowEntity(new HoverEvent.EntityTooltipInfo(ent.getType(), ent.getUUID(), ent.getDisplayName()))));
		}
	}
}