package net.mcreator.meritocraft.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.meritocraft.entity.ShovelEntityEntity;

public class ShovelEntityTickProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		double actionState = 0;
		actionState = entity instanceof ShovelEntityEntity _datEntI ? _datEntI.getEntityData().get(ShovelEntityEntity.DATA_actionState) : 0;
		if (actionState == 1) {
			entity.getPersistentData().putDouble("actionTicks", (entity.getPersistentData().getDoubleOr("actionTicks", 0) + 1));
			if (entity.getPersistentData().getDoubleOr("actionTicks", 0) == 24) {
				if (entity instanceof ShovelEntityEntity _datEntSetI)
					_datEntSetI.getEntityData().set(ShovelEntityEntity.DATA_actionState, 2);
				entity.getPersistentData().putDouble("actionTicks", 0);
			}
		} else if (actionState == 2) {
			entity.getPersistentData().putDouble("actionTicks", (entity.getPersistentData().getDoubleOr("actionTicks", 0) + 1));
			if (entity.getPersistentData().getDoubleOr("actionTicks", 0) == 20) {
				if (entity instanceof ShovelEntityEntity _datEntSetI)
					_datEntSetI.getEntityData().set(ShovelEntityEntity.DATA_actionState, 0);
				entity.getPersistentData().putDouble("actionTicks", 0);
			}
		}
	}
}