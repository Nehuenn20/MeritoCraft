package net.mcreator.meritocraft.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;

import net.mcreator.meritocraft.entity.ShovelEntityEntity;

public class ShovelEntityDiesProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		ItemStack drop = ItemStack.EMPTY;
		double prob = 0;
		if ((entity instanceof ShovelEntityEntity _datEntI ? _datEntI.getEntityData().get(ShovelEntityEntity.DATA_type) : 0) == 0) {
			prob = 0.2;
			drop = new ItemStack(Items.WOODEN_SHOVEL).copy();
		} else if ((entity instanceof ShovelEntityEntity _datEntI ? _datEntI.getEntityData().get(ShovelEntityEntity.DATA_type) : 0) == 1) {
			prob = 0.2;
			drop = new ItemStack(Items.GOLDEN_SHOVEL).copy();
		} else if ((entity instanceof ShovelEntityEntity _datEntI ? _datEntI.getEntityData().get(ShovelEntityEntity.DATA_type) : 0) == 2) {
			prob = 0.15;
			drop = new ItemStack(Items.STONE_SHOVEL).copy();
		} else if ((entity instanceof ShovelEntityEntity _datEntI ? _datEntI.getEntityData().get(ShovelEntityEntity.DATA_type) : 0) == 3) {
			prob = 0.1;
			drop = new ItemStack(Items.IRON_SHOVEL).copy();
		} else if ((entity instanceof ShovelEntityEntity _datEntI ? _datEntI.getEntityData().get(ShovelEntityEntity.DATA_type) : 0) == 4) {
			prob = 0.05;
			drop = new ItemStack(Items.DIAMOND_SHOVEL).copy();
		} else {
			prob = 0.01;
			drop = new ItemStack(Items.NETHERITE_SHOVEL).copy();
		}
		if (prob > Math.random()) {
			if (world instanceof ServerLevel _level) {
				ItemEntity entityToSpawn = new ItemEntity(_level, (x + 0.5), (y + 0.1), (z + 0.5), drop);
				entityToSpawn.setPickUpDelay(10);
				_level.addFreshEntity(entityToSpawn);
			}
		}
	}
}