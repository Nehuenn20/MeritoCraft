package net.mcreator.meritocraft.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.meritocraft.network.MeritocraftModVariables;

public class PotionBookGUIOpenedProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		double page = 0;
		{
			MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
			_vars.adv_book_page = 0;
			_vars.markSyncDirty();
		}
	}
}