package net.mcreator.meritocraft.procedures;

import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.mcreator.meritocraft.init.MeritocraftModItems;
import net.mcreator.meritocraft.entity.CraperEntity;

import javax.annotation.Nullable;

@EventBusSubscriber
public class CraperGunpowderStickProcedure {
	@SubscribeEvent
	public static void onPlayerTick(PlayerTickEvent.Post event) {
		execute(event, event.getEntity());
	}

	public static void execute(Entity entity) {
		execute(null, entity);
	}

	private static void execute(@Nullable Event event, Entity entity) {
		if (entity == null)
			return;
		Entity craper = null;
		double speedMultiplier = 0;
		if (entity.isPassenger()) {
			if ((entity.getVehicle()) instanceof CraperEntity && ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == MeritocraftModItems.GUNPOWDER_ON_A_STICK.get()
					|| (entity instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY).getItem() == MeritocraftModItems.GUNPOWDER_ON_A_STICK.get())) {
				craper = entity.getVehicle();
				{
					Entity _ent = craper;
					_ent.setYRot(entity.getYRot());
					_ent.setXRot(0);
					_ent.setYBodyRot(_ent.getYRot());
					_ent.setYHeadRot(_ent.getYRot());
					_ent.yRotO = _ent.getYRot();
					_ent.xRotO = _ent.getXRot();
					if (_ent instanceof LivingEntity _entity) {
						_entity.yBodyRotO = _entity.getYRot();
						_entity.yHeadRotO = _entity.getYRot();
					}
				}
				if (craper.getPersistentData().getDoubleOr("boostTime", 0) < craper.getPersistentData().getDoubleOr("boostTotal", 0)) {
					craper.getPersistentData().putDouble("boostTime", (craper.getPersistentData().getDoubleOr("boostTime", 0) + 1));
				}
				speedMultiplier = 1 + (craper.getPersistentData().getDoubleOr("boostTime", 0) < craper.getPersistentData().getDoubleOr("boostTotal", 0)
						? 1.15 * Math.sin(Math.PI * (craper.getPersistentData().getDoubleOr("boostTime", 0) / craper.getPersistentData().getDoubleOr("boostTotal", 0)))
						: 0);
				if (craper instanceof Mob _entity)
					_entity.getNavigation().moveTo((craper.getX() + craper.getLookAngle().x * 5), (craper.getY()), (craper.getZ() + craper.getLookAngle().z * 5), (1.2 * speedMultiplier));
			}
		}
	}
}