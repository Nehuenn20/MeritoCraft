package net.mcreator.meritocraft.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.network.chat.Component;

import net.mcreator.meritocraft.init.MeritocraftModMobEffects;

public class SpontaneousCTickProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		double counter = 0;
		boolean counterstart = false;
		if (!counterstart) {
			counter = 160;
			counterstart = true;
		}
		if (entity instanceof LivingEntity _livEnt0 && _livEnt0.hasEffect(MobEffects.FIRE_RESISTANCE) || entity.fireImmune()) {
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MeritocraftModMobEffects.SPONTANEOUS_COMBUSTION);
			entity.igniteForSeconds(0);
		}
		counter = counter - 1;
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal(("Combusti\u00F3n espont\u00E1nea en: " + Math.ceil(counter / 20))), true);
	}
}