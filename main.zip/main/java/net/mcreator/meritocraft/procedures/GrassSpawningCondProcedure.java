package net.mcreator.meritocraft.procedures;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

public class GrassSpawningCondProcedure {
	public static boolean execute(LevelAccessor world, double x, double y, double z) {
		if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Blocks.SHORT_GRASS || (world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Blocks.TALL_GRASS
				|| (world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Blocks.TALL_DRY_GRASS || (world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Blocks.SHORT_DRY_GRASS
				|| (world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Blocks.CRIMSON_ROOTS || (world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Blocks.WARPED_ROOTS) {
			world.setBlock(BlockPos.containing(x, y, z), Blocks.AIR.defaultBlockState(), 3);
			return true;
		}
		return false;
	}
}