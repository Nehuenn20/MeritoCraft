package net.mcreator.meritocraft.procedures;

import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.GameType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.monster.Slime;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;

import net.mcreator.meritocraft.network.MeritocraftModVariables;

import javax.annotation.Nullable;

import java.util.UUID;

@EventBusSubscriber
public class SlimeEatTickProcedure {
	@SubscribeEvent
	public static void onPlayerTick(PlayerTickEvent.Post event) {
		execute(event, event.getEntity().level(), event.getEntity());
	}

	public static void execute(LevelAccessor world, Entity entity) {
		execute(null, world, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).slimed == true) {
			if (!(null == (world instanceof ServerLevel _level0 ? getEntityFromUUID(_level0, entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).slimed_source) : null))) {
				if (4 > (entity.position()).distanceTo(((world instanceof ServerLevel _level3 ? getEntityFromUUID(_level3, entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).slimed_source) : null).position()))) {
					entity.startRiding((world instanceof ServerLevel _level6 ? getEntityFromUUID(_level6, entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).slimed_source) : null));
					if (entity instanceof LivingEntity _entity) {
						AttributeModifier modifier = new AttributeModifier(ResourceLocation.parse("meritocraft:slimed"), (-100), AttributeModifier.Operation.ADD_VALUE);
						if (!_entity.getAttribute(Attributes.ATTACK_SPEED).hasModifier(modifier.id())) {
							_entity.getAttribute(Attributes.ATTACK_SPEED).addPermanentModifier(modifier);
						}
					}
					if (entity instanceof LivingEntity _entity) {
						AttributeModifier modifier = new AttributeModifier(ResourceLocation.parse("meritocraft:slimed"), (-0.99), AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
						if (!_entity.getAttribute(Attributes.SCALE).hasModifier(modifier.id())) {
							_entity.getAttribute(Attributes.SCALE).addPermanentModifier(modifier);
						}
					}
					if (entity instanceof Player _player && !_player.level().isClientSide())
						_player.displayClientMessage(Component.literal("\u00A1Presiona Shift izquierdo para resistirte!"), true);
					if (entity instanceof Player _plr11 && _plr11.gameMode() == GameType.SURVIVAL) {
						if (entity instanceof ServerPlayer _player)
							_player.setGameMode(GameType.ADVENTURE);
					}
				}
			}
			if (!((entity.getVehicle()) instanceof Slime) || !entity.isPassenger()) {
				if (entity instanceof LivingEntity _entity) {
					_entity.getAttribute(Attributes.ATTACK_SPEED).removeModifier(ResourceLocation.parse("meritocraft:slimed"));
				}
				if (entity instanceof LivingEntity _entity) {
					_entity.getAttribute(Attributes.SCALE).removeModifier(ResourceLocation.parse("meritocraft:slimed"));
				}
				if (entity instanceof Player _plr18 && _plr18.gameMode() == GameType.ADVENTURE) {
					if (entity instanceof ServerPlayer _player)
						_player.setGameMode(GameType.SURVIVAL);
				}
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.slimed = false;
					_vars.markSyncDirty();
				}
			}
		}
	}

	private static Entity getEntityFromUUID(ServerLevel level, String uuid) {
		try {
			return level.getEntity(UUID.fromString(uuid));
		} catch (IllegalArgumentException e) {
			return null;
		}
	}
}