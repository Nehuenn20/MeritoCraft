package net.mcreator.meritocraft.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.advancements.AdvancementHolder;

import net.mcreator.meritocraft.network.MeritocraftModVariables;

import java.util.UUID;

public class SlimeEatResistProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).slimed == true) {
			if (!(null == (world instanceof ServerLevel _level0 ? getEntityFromUUID(_level0, entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).slimed_source) : null))) {
				(world instanceof ServerLevel _level4 ? getEntityFromUUID(_level4, entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).slimed_source) : null).hurt(new DamageSource(world.holderOrThrow(DamageTypes.THORNS), entity),
						(float) (entity instanceof LivingEntity _livEnt2 && _livEnt2.hasEffect(MobEffects.STRENGTH)
								? 1 + 1 + 2 * (entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(MobEffects.STRENGTH) ? _livEnt.getEffect(MobEffects.STRENGTH).getAmplifier() : 0)
								: 1));
				if (!((world instanceof ServerLevel _level7 ? getEntityFromUUID(_level7, entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).slimed_source) : null).isAlive())) {
					if (entity instanceof ServerPlayer _player && _player.level() instanceof ServerLevel _level) {
						AdvancementHolder _adv = _level.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_slime_eat"));
						if (_adv != null) {
							AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv);
							if (!_ap.isDone()) {
								for (String criteria : _ap.getRemainingCriteria())
									_player.getAdvancements().award(_adv, criteria);
							}
						}
					}
				}
			}
		}
	}

	private static Entity getEntityFromUUID(ServerLevel level, String uuid) {
		try {
			return level.getEntity(UUID.fromString(uuid));
		} catch (IllegalArgumentException e) {
			return null;
		}
	}
}