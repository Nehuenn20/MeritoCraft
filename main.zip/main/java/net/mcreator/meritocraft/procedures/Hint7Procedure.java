package net.mcreator.meritocraft.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.meritocraft.network.MeritocraftModVariables;

public class Hint7Procedure {
	public static String execute(Entity entity) {
		if (entity == null)
			return "";
		String hint = "";
		if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).adv_book_page == 0) {
			hint = "Haz desaparecer a las criaturas hostiles por arte de magia";
		} else if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).adv_book_page == 1) {
			hint = "Sum\u00E9rgete en el agua burbujeante del desierto";
		} else if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).adv_book_page == 2) {
			hint = "Ahuyenta a la presencia misteriosa";
		} else if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).adv_book_page == 3) {
			hint = "Intenta tocar el desierto";
		} else if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).adv_book_page == 4) {
			hint = "Inyecta una vacuna";
		}
		return hint;
	}
}