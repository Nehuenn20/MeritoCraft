package net.mcreator.meritocraft.procedures;

import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.monster.WitherSkeleton;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.tags.TagKey;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.BlockPos;

import javax.annotation.Nullable;

@EventBusSubscriber
public class SkeletonTeleportProcedure {
	@SubscribeEvent
	public static void onEntityAttacked(LivingIncomingDamageEvent event) {
		if (event.getEntity() != null) {
			execute(event, event.getEntity().level(), event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getEntity(), event.getSource().getDirectEntity());
		}
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, Entity immediatesourceentity) {
		execute(null, world, x, y, z, entity, immediatesourceentity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity, Entity immediatesourceentity) {
		if (entity == null || immediatesourceentity == null)
			return;
		double xnew = 0;
		double znew = 0;
		double xold = 0;
		double zold = 0;
		double attempts = 0;
		Entity riding = null;
		if (entity.getType().is(TagKey.create(Registries.ENTITY_TYPE, ResourceLocation.parse("minecraft:skeletons"))) && !(entity instanceof WitherSkeleton) && immediatesourceentity instanceof Player) {
			if (entity.isPassenger()) {
				riding = entity.getVehicle();
			}
			xold = x;
			zold = z;
			xnew = x;
			znew = z;
			while (!world.getEntitiesOfClass(Player.class, new AABB(Vec3.ZERO, Vec3.ZERO).move(new Vec3(xnew, y, znew)).inflate(4 / 2d), e -> true).isEmpty()
					|| !world.getBlockState(BlockPos.containing(xnew, y - 1, znew)).canOcclude() && !world.isEmptyBlock(BlockPos.containing(xnew, y, znew)) && !world.isEmptyBlock(BlockPos.containing(xnew, y + 1, znew))) {
				xnew = x + Mth.nextDouble(RandomSource.create(), 4, 10) * (0.5 > Math.random() ? -1 : 1);
				znew = z + Mth.nextDouble(RandomSource.create(), 4, 10) * (0.5 > Math.random() ? -1 : 1);
				xnew = 0.125 > Math.random() ? x : xnew;
				znew = 0.125 > Math.random() ? z : znew;
				attempts = attempts + 1;
				if (attempts >= 15) {
					break;
				}
			}
			if (attempts < 15 && (xnew != xold || znew != zold)) {
				if (riding == null) {
					{
						Entity _ent = entity;
						_ent.teleportTo(xnew, y, znew);
						if (_ent instanceof ServerPlayer _serverPlayer)
							_serverPlayer.connection.teleport(xnew, y, znew, _ent.getYRot(), _ent.getXRot());
					}
				} else {
					{
						Entity _ent = riding;
						_ent.teleportTo(xnew, y, znew);
						if (_ent instanceof ServerPlayer _serverPlayer)
							_serverPlayer.connection.teleport(xnew, y, znew, _ent.getYRot(), _ent.getXRot());
					}
					{
						Entity _ent = entity;
						_ent.teleportTo(xnew, y, znew);
						if (_ent instanceof ServerPlayer _serverPlayer)
							_serverPlayer.connection.teleport(xnew, y, znew, _ent.getYRot(), _ent.getXRot());
					}
					entity.startRiding(riding);
				}
				if (world instanceof Level _level) {
					if (!_level.isClientSide()) {
						_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("entity.enderman.teleport")), SoundSource.HOSTILE, 1, 1);
					} else {
						_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("entity.enderman.teleport")), SoundSource.HOSTILE, 1, 1, false);
					}
				}
			}
		}
	}
}