package net.mcreator.meritocraft.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

import net.mcreator.meritocraft.init.MeritocraftModBlocks;

public class EfedraValidPlacementConditionProcedure {
	public static boolean execute(LevelAccessor world, double x, double y, double z) {
		return MeritocraftModBlocks.EFEDRA.get().defaultBlockState().canSurvive(world, BlockPos.containing(x, y, z));
	}
}