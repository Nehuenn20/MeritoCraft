package net.mcreator.meritocraft.procedures;

import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.mcreator.meritocraft.MeritocraftMod;

import javax.annotation.Nullable;

@EventBusSubscriber
public class GolemBuffProcedure {
	@SubscribeEvent
	public static void onEntitySpawned(EntityJoinLevelEvent event) {
		execute(event, event.getLevel(), event.getEntity());
	}

	public static void execute(LevelAccessor world, Entity entity) {
		execute(null, world, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof IronGolem) {
			MeritocraftMod.queueServerWork(1, () -> {
				if (!(executeCommandGetResult(entity, "data get entity @s Tags")).contains("bandit_summon") && !(executeCommandGetResult(entity, "data get entity @s")).contains("PlayerCreated: 1b")) {
					if (0.2 > Math.random()) {
						if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
							_entity.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, -1, 2, false, false));
						if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
							_entity.addEffect(new MobEffectInstance(MobEffects.STRENGTH, -1, 3, false, false));
						if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
							_entity.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, -1, 2, false, false));
						if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
							_entity.addEffect(new MobEffectInstance(MobEffects.HASTE, -1, 2, false, false));
						if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
							_entity.addEffect(new MobEffectInstance(MobEffects.REGENERATION, -1, 2, false, false));
						if (entity instanceof LivingEntity _entity) {
							AttributeModifier modifier = new AttributeModifier(ResourceLocation.parse("meritocraft:buff"), 1, AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
							if (!_entity.getAttribute(Attributes.MOVEMENT_SPEED).hasModifier(modifier.id())) {
								_entity.getAttribute(Attributes.MOVEMENT_SPEED).addPermanentModifier(modifier);
							}
						}
						if (entity instanceof LivingEntity _entity) {
							AttributeModifier modifier = new AttributeModifier(ResourceLocation.parse("meritocraft:buff"), 2, AttributeModifier.Operation.ADD_VALUE);
							if (!_entity.getAttribute(Attributes.ARMOR_TOUGHNESS).hasModifier(modifier.id())) {
								_entity.getAttribute(Attributes.ARMOR_TOUGHNESS).addPermanentModifier(modifier);
							}
						}
						if (entity instanceof LivingEntity _entity) {
							AttributeModifier modifier = new AttributeModifier(ResourceLocation.parse("meritocraft:buff"), 4, AttributeModifier.Operation.ADD_VALUE);
							if (!_entity.getAttribute(Attributes.ARMOR).hasModifier(modifier.id())) {
								_entity.getAttribute(Attributes.ARMOR).addPermanentModifier(modifier);
							}
						}
						if (entity instanceof LivingEntity _entity) {
							AttributeModifier modifier = new AttributeModifier(ResourceLocation.parse("meritocraft:buff"), 4, AttributeModifier.Operation.ADD_VALUE);
							if (!_entity.getAttribute(Attributes.EXPLOSION_KNOCKBACK_RESISTANCE).hasModifier(modifier.id())) {
								_entity.getAttribute(Attributes.EXPLOSION_KNOCKBACK_RESISTANCE).addPermanentModifier(modifier);
							}
						}
						if (entity instanceof LivingEntity _entity) {
							AttributeModifier modifier = new AttributeModifier(ResourceLocation.parse("meritocraft:buff"), 2, AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
							if (!_entity.getAttribute(Attributes.FOLLOW_RANGE).hasModifier(modifier.id())) {
								_entity.getAttribute(Attributes.FOLLOW_RANGE).addPermanentModifier(modifier);
							}
						}
						if (entity instanceof LivingEntity _entity) {
							AttributeModifier modifier = new AttributeModifier(ResourceLocation.parse("meritocraft:buff"), 4, AttributeModifier.Operation.ADD_VALUE);
							if (!_entity.getAttribute(Attributes.KNOCKBACK_RESISTANCE).hasModifier(modifier.id())) {
								_entity.getAttribute(Attributes.KNOCKBACK_RESISTANCE).addPermanentModifier(modifier);
							}
						}
						if (entity instanceof LivingEntity _entity) {
							AttributeModifier modifier = new AttributeModifier(ResourceLocation.parse("meritocraft:buff"), 1, AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
							if (!_entity.getAttribute(Attributes.MAX_HEALTH).hasModifier(modifier.id())) {
								_entity.getAttribute(Attributes.MAX_HEALTH).addPermanentModifier(modifier);
							}
						}
						if (entity instanceof LivingEntity _entity)
							_entity.setHealth(200);
						if (entity instanceof LivingEntity _entity) {
							AttributeModifier modifier = new AttributeModifier(ResourceLocation.parse("meritocraft:buff"), 1.2, AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
							if (!_entity.getAttribute(Attributes.SCALE).hasModifier(modifier.id())) {
								_entity.getAttribute(Attributes.SCALE).addPermanentModifier(modifier);
							}
						}
						{
							Entity _ent = entity;
							if (!_ent.level().isClientSide() && _ent.getServer() != null) {
								_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
										_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent), "tag @s add ELITE");
							}
						}
					} else {
						if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
							_entity.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, -1, 0, false, false));
						if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
							_entity.addEffect(new MobEffectInstance(MobEffects.STRENGTH, -1, 1, false, false));
						if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
							_entity.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, -1, 1, false, false));
						if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
							_entity.addEffect(new MobEffectInstance(MobEffects.HASTE, -1, 1, false, false));
						if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
							_entity.addEffect(new MobEffectInstance(MobEffects.HEALTH_BOOST, -1, 4, false, false));
						if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
							_entity.addEffect(new MobEffectInstance(MobEffects.REGENERATION, -1, 0, false, false));
						if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
							_entity.addEffect(new MobEffectInstance(MobEffects.SPEED, -1, 1, false, false));
						if (entity instanceof LivingEntity _entity) {
							AttributeModifier modifier = new AttributeModifier(ResourceLocation.parse("meritocraft:buff"), 2, AttributeModifier.Operation.ADD_VALUE);
							if (!_entity.getAttribute(Attributes.ARMOR_TOUGHNESS).hasModifier(modifier.id())) {
								_entity.getAttribute(Attributes.ARMOR_TOUGHNESS).addPermanentModifier(modifier);
							}
						}
						if (entity instanceof LivingEntity _entity) {
							AttributeModifier modifier = new AttributeModifier(ResourceLocation.parse("meritocraft:buff"), 4, AttributeModifier.Operation.ADD_VALUE);
							if (!_entity.getAttribute(Attributes.ARMOR).hasModifier(modifier.id())) {
								_entity.getAttribute(Attributes.ARMOR).addPermanentModifier(modifier);
							}
						}
						if (entity instanceof LivingEntity _entity) {
							AttributeModifier modifier = new AttributeModifier(ResourceLocation.parse("meritocraft:buff"), 4, AttributeModifier.Operation.ADD_VALUE);
							if (!_entity.getAttribute(Attributes.EXPLOSION_KNOCKBACK_RESISTANCE).hasModifier(modifier.id())) {
								_entity.getAttribute(Attributes.EXPLOSION_KNOCKBACK_RESISTANCE).addPermanentModifier(modifier);
							}
						}
						if (entity instanceof LivingEntity _entity) {
							AttributeModifier modifier = new AttributeModifier(ResourceLocation.parse("meritocraft:buff"), 4, AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
							if (!_entity.getAttribute(Attributes.FOLLOW_RANGE).hasModifier(modifier.id())) {
								_entity.getAttribute(Attributes.FOLLOW_RANGE).addPermanentModifier(modifier);
							}
						}
						if (entity instanceof LivingEntity _entity) {
							AttributeModifier modifier = new AttributeModifier(ResourceLocation.parse("meritocraft:buff"), 4, AttributeModifier.Operation.ADD_VALUE);
							if (!_entity.getAttribute(Attributes.KNOCKBACK_RESISTANCE).hasModifier(modifier.id())) {
								_entity.getAttribute(Attributes.KNOCKBACK_RESISTANCE).addPermanentModifier(modifier);
							}
						}
						if (entity instanceof LivingEntity _entity) {
							AttributeModifier modifier = new AttributeModifier(ResourceLocation.parse("meritocraft:buff"), 0.2, AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
							if (!_entity.getAttribute(Attributes.SCALE).hasModifier(modifier.id())) {
								_entity.getAttribute(Attributes.SCALE).addPermanentModifier(modifier);
							}
						}
					}
				}
			});
		}
	}

	private static String executeCommandGetResult(Entity entity, String command) {
		StringBuilder result = new StringBuilder();
		if (!entity.level().isClientSide() && entity.getServer() != null) {
			CommandSource dataConsumer = new CommandSource() {
				@Override
				public void sendSystemMessage(Component message) {
					result.append(message.getString());
				}

				@Override
				public boolean acceptsSuccess() {
					return true;
				}

				@Override
				public boolean acceptsFailure() {
					return true;
				}

				@Override
				public boolean shouldInformAdmins() {
					return false;
				}
			};
			entity.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(dataConsumer, entity.position(), entity.getRotationVector(), entity.level() instanceof ServerLevel ? (ServerLevel) entity.level() : null, 4,
					entity.getName().getString(), entity.getDisplayName(), entity.level().getServer(), entity), command);
		}
		return result.toString();
	}
}