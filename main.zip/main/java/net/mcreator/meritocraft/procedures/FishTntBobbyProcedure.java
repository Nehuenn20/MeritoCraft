package net.mcreator.meritocraft.procedures;

import net.neoforged.neoforge.event.entity.player.ItemFishedEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.ICancellableEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.advancements.AdvancementHolder;

import javax.annotation.Nullable;

import java.util.UUID;
import java.util.Comparator;

@EventBusSubscriber
public class FishTntBobbyProcedure {
	@SubscribeEvent
	public static void onPlayerFishItem(ItemFishedEvent event) {
		execute(event, event.getEntity().level(), event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getEntity());
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		execute(null, world, x, y, z, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		Entity bobby = null;
		double dx = 0;
		double dy = 0;
		double dz = 0;
		double hdist = 0;
		double vdist = 0;
		double fuse = 0;
		double xbobby = 0;
		double zbobby = 0;
		if (0.15 > Math.random()) {
			{
				final Vec3 _center = new Vec3(x, y, z);
				for (Entity entityiterator : world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(100 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList()) {
					if ((world instanceof ServerLevel _level1 ? getEntityFromUUID(_level1, (entityiterator.getPersistentData().getStringOr("fish.player", ""))) : null) == entity) {
						bobby = entityiterator;
					}
				}
			}
			if (0.1 < Math.random()) {
				xbobby = bobby.getX();
				zbobby = bobby.getZ();
				dx = x - xbobby;
				dy = (y + 1.2) - Math.round(bobby.getY() * 8) / 8d;
				dz = z - zbobby;
				hdist = Math.hypot(dx, dz) + 1;
				vdist = 0.297 + dy * 0.053 + (Math.sqrt(hdist) + 1) * (0.047 - 0.001 * Math.min(hdist, 6)) + Math.pow(hdist, 0.66) * 0.02 + (hdist >= 4 && hdist <= 6 ? 0.006 : 0);
				if (world instanceof ServerLevel _level) {
					Entity entityToSpawn = EntityType.TNT.spawn(_level, BlockPos.containing(xbobby, bobby.getY() + 0.1, zbobby), EntitySpawnReason.MOB_SUMMONED);
					if (entityToSpawn != null) {
						entityToSpawn.setDeltaMovement((dx * 0.045), vdist, (dz * 0.045));
					}
				}
				fuse = Math.round((dy + hdist + 4) * 2);
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							("data merge entity @e[type=tnt,limit=1,sort=nearest] {explosion_power:6,fuse:" + fuse + "}"));
			} else {
				for (int index0 = 0; index0 < 10; index0++) {
					xbobby = bobby.getX() + Mth.nextDouble(RandomSource.create(), -5, 5);
					zbobby = bobby.getZ() + Mth.nextDouble(RandomSource.create(), -5, 5);
					dx = x - bobby.getX();
					dy = (y + 1.2) - Math.round(bobby.getY() * 8) / 8d;
					dz = z - bobby.getZ();
					hdist = Math.hypot(dx, dz) + 1;
					vdist = 0.297 + dy * 0.053 + (Math.sqrt(hdist) + 1) * (0.047 - 0.001 * Math.min(hdist, 6)) + Math.pow(hdist, 0.66) * 0.02 + (hdist >= 4 && hdist <= 6 ? 0.006 : 0);
					if (world instanceof ServerLevel _level) {
						Entity entityToSpawn = EntityType.TNT.spawn(_level, BlockPos.containing(xbobby, bobby.getY() + 0.1, zbobby), EntitySpawnReason.MOB_SUMMONED);
						if (entityToSpawn != null) {
							entityToSpawn.setDeltaMovement((dx * 0.045), vdist, (dz * 0.045));
						}
					}
					fuse = Math.round((dy + hdist + 4) * 2);
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								("execute as @e[type=tnt,limit=10,sort=nearest] run data merge entity @s {explosion_power:6,fuse:" + fuse + "}"));
				}
			}
			if (!(entity instanceof ServerPlayer _plr20 && _plr20.level() instanceof ServerLevel _serverLevel20
					&& _plr20.getAdvancements().getOrStartProgress(_serverLevel20.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_fish_tnt"))).isDone())) {
				if (entity instanceof Player _player && !_player.level().isClientSide())
					_player.displayClientMessage(Component.literal("<Nehuenn20> Hacer esta maldita par\u00E1bola fue sufrimiento puro, as\u00ED que espero que exploten :D"), false);
				if (entity instanceof ServerPlayer _player && _player.level() instanceof ServerLevel _level) {
					AdvancementHolder _adv = _level.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_fish_tnt"));
					if (_adv != null) {
						AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv);
						if (!_ap.isDone()) {
							for (String criteria : _ap.getRemainingCriteria())
								_player.getAdvancements().award(_adv, criteria);
						}
					}
				}
			}
			if (event instanceof ICancellableEvent _cancellable) {
				_cancellable.setCanceled(true);
			}
		}
	}

	private static Entity getEntityFromUUID(ServerLevel level, String uuid) {
		try {
			return level.getEntity(UUID.fromString(uuid));
		} catch (IllegalArgumentException e) {
			return null;
		}
	}
}