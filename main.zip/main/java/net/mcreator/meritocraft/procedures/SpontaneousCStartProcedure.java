package net.mcreator.meritocraft.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;

public class SpontaneousCStartProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		entity.igniteForSeconds(8);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(
					Component.literal("Est\u00E1 a punto de suceder una combusti\u00F3n espont\u00E1nea, todos los \u00EDtems en tu inventario se quemar\u00E1n junto a t\u00ED \u00A1TIRALOS R\u00C1PIDO o USA POCI\u00D3N DE RESISTENCIA AL FUEGO!"),
					false);
	}
}