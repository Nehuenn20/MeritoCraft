package net.mcreator.meritocraft.procedures;

import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;

import net.mcreator.meritocraft.init.MeritocraftModMobEffects;

import javax.annotation.Nullable;

@EventBusSubscriber
public class SpontaneousCProcProcedure {
	@SubscribeEvent
	public static void onPlayerTick(PlayerTickEvent.Post event) {
		execute(event, event.getEntity());
	}

	public static void execute(Entity entity) {
		execute(null, entity);
	}

	private static void execute(@Nullable Event event, Entity entity) {
		if (entity == null)
			return;
		if (!(entity instanceof LivingEntity _livEnt0 && _livEnt0.hasEffect(MeritocraftModMobEffects.SPONTANEOUS_COMBUSTION)) && !(entity.fireImmune() || entity instanceof LivingEntity _livEnt2 && _livEnt2.hasEffect(MobEffects.FIRE_RESISTANCE))) {
			if (entity.isOnFire()) {
				if ((entity.level().dimension()) == Level.NETHER) {
					if (Mth.nextInt(RandomSource.create(), 0, 1200) == 0) {
						if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
							_entity.addEffect(new MobEffectInstance(MeritocraftModMobEffects.SPONTANEOUS_COMBUSTION, 160, 0, false, true));
					}
				} else {
					if (Mth.nextInt(RandomSource.create(), 0, 6000) == 0) {
						if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
							_entity.addEffect(new MobEffectInstance(MeritocraftModMobEffects.SPONTANEOUS_COMBUSTION, 160, 0, false, true));
					}
				}
			} else {
				if (Mth.nextInt(RandomSource.create(), 0, 432000) == 0) {
					if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(MeritocraftModMobEffects.SPONTANEOUS_COMBUSTION, 160, 0, false, true));
				}
			}
		}
	}
}