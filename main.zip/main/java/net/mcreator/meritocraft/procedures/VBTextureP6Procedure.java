package net.mcreator.meritocraft.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.meritocraft.entity.VillagerBanditEntity;

public class VBTextureP6Procedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		if ((entity instanceof VillagerBanditEntity _datEntI ? _datEntI.getEntityData().get(VillagerBanditEntity.DATA_profession) : 0) == 6) {
			return true;
		}
		return false;
	}
}