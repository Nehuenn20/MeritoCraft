package net.mcreator.meritocraft.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;

public class VBNightProcedure {
	public static boolean execute(LevelAccessor world) {
		if (!(world instanceof Level _lvl0 && _lvl0.isBrightOutside()) || world.getLevelData().isRaining() || world.getLevelData().isThundering()) {
			return true;
		}
		return false;
	}
}