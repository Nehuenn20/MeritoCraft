package net.mcreator.meritocraft.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;

public class AsthmaTickProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		double ticks = 0;
		entity.hurt(new DamageSource(world.holderOrThrow(DamageTypes.DROWN)), 1);
	}
}