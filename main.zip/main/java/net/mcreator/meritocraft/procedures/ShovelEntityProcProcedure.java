package net.mcreator.meritocraft.procedures;

import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.sounds.SoundSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.arguments.EntityAnchorArgument;

import net.mcreator.meritocraft.network.MeritocraftModVariables;
import net.mcreator.meritocraft.entity.ShovelEntityEntity;

import javax.annotation.Nullable;

@EventBusSubscriber
public class ShovelEntityProcProcedure {
	@SubscribeEvent
	public static void onEntityAttacked(LivingIncomingDamageEvent event) {
		if (event.getEntity() != null) {
			execute(event, event.getEntity().level(), event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getSource(), event.getEntity(), event.getSource().getDirectEntity(), event.getSource().getEntity(),
					event.getAmount());
		}
	}

	public static void execute(LevelAccessor world, double x, double y, double z, DamageSource damagesource, Entity entity, Entity immediatesourceentity, Entity sourceentity, double amount) {
		execute(null, world, x, y, z, damagesource, entity, immediatesourceentity, sourceentity, amount);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, DamageSource damagesource, Entity entity, Entity immediatesourceentity, Entity sourceentity, double amount) {
		if (damagesource == null || entity == null || immediatesourceentity == null || sourceentity == null)
			return;
		if (sourceentity instanceof ShovelEntityEntity) {
			if ((sourceentity instanceof ShovelEntityEntity _datEntI ? _datEntI.getEntityData().get(ShovelEntityEntity.DATA_actionState) : 0) == 0) {
				sourceentity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3(x, y, z));
				if (world instanceof Level _level) {
					if (!_level.isClientSide()) {
						_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("meritocraft:tlabaja")), SoundSource.HOSTILE, (float) 1.5, 1);
					} else {
						_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("meritocraft:tlabaja")), SoundSource.HOSTILE, (float) 1.5, 1, false);
					}
				}
				if (0.13 > Math.random() && entity instanceof Player) {
					{
						MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
						_vars.curriculum = 60;
						_vars.markSyncDirty();
					}
				}
				if (damagesource.is(DamageTypes.MOB_ATTACK)) {
					entity.hurt(new DamageSource(world.holderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.parse("meritocraft:shovel_entity_damage"))), immediatesourceentity, sourceentity), (float) amount);
					if (event instanceof LivingIncomingDamageEvent _event) {
						_event.setAmount(0);
					}
				}
				if (sourceentity instanceof ShovelEntityEntity _datEntSetI)
					_datEntSetI.getEntityData().set(ShovelEntityEntity.DATA_actionState, 1);
			}
		}
	}
}