package net.mcreator.meritocraft.procedures;

import net.neoforged.neoforge.event.entity.living.LivingEquipmentChangeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.animal.horse.Horse;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;

import javax.annotation.Nullable;

@EventBusSubscriber
public class HorseArmorProcedure {
	@SubscribeEvent
	public static void whenEntityChangeEquipment(LivingEquipmentChangeEvent event) {
		execute(event, event.getEntity(), event.getTo(), event.getSlot().getId());
	}

	public static void execute(Entity entity, ItemStack newitemstack, double equipmentslot) {
		execute(null, entity, newitemstack, equipmentslot);
	}

	private static void execute(@Nullable Event event, Entity entity, ItemStack newitemstack, double equipmentslot) {
		if (entity == null)
			return;
		double armorvalue = 0;
		ItemStack items = ItemStack.EMPTY;
		if (entity instanceof Horse && equipmentslot == 6) {
			items = newitemstack.copy();
			if (items.getItem() == Items.LEATHER_HORSE_ARMOR) {
				armorvalue = 3;
			} else if (items.getItem() == Items.IRON_HORSE_ARMOR) {
				armorvalue = 5;
			} else if (items.getItem() == Items.GOLDEN_HORSE_ARMOR) {
				armorvalue = 7;
			} else if (items.getItem() == Items.DIAMOND_HORSE_ARMOR) {
				armorvalue = 11;
			} else {
				armorvalue = 0;
			}
			if (entity instanceof LivingEntity _entity) {
				_entity.getAttribute(Attributes.MOVEMENT_SPEED).removeModifier(ResourceLocation.parse("meritocraft:heavy_armor"));
			}
			if (entity instanceof LivingEntity _entity) {
				AttributeModifier modifier = new AttributeModifier(ResourceLocation.parse("meritocraft:heavy_armor"), (armorvalue * (-0.01)), AttributeModifier.Operation.ADD_VALUE);
				if (!_entity.getAttribute(Attributes.MOVEMENT_SPEED).hasModifier(modifier.id())) {
					_entity.getAttribute(Attributes.MOVEMENT_SPEED).addPermanentModifier(modifier);
				}
			}
		}
	}
}