package net.mcreator.meritocraft.procedures;

import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.GameType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.animal.horse.Horse;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.InteractionHand;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.BlockPos;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.advancements.AdvancementHolder;

import net.mcreator.meritocraft.init.MeritocraftModMobEffects;
import net.mcreator.meritocraft.init.MeritocraftModItems;

import javax.annotation.Nullable;

@EventBusSubscriber
public class VaccineUseProcedure {
	@SubscribeEvent
	public static void onRightClickEntity(PlayerInteractEvent.EntityInteract event) {
		if (event.getHand() != InteractionHand.MAIN_HAND)
			return;
		execute(event, event.getLevel(), event.getPos().getX(), event.getPos().getY(), event.getPos().getZ(), event.getTarget(), event.getEntity());
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity) {
		execute(null, world, x, y, z, entity, sourceentity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		if (entity instanceof Horse) {
			if (entity instanceof LivingEntity _livingEntity1 && _livingEntity1.getAttribute(Attributes.MOVEMENT_SPEED).hasModifier(ResourceLocation.parse("meritocraft:asthma.base"))) {
				if ((sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == MeritocraftModItems.VACCINE.get()) {
					entity.getPersistentData().putBoolean("asthma.healed", true);
					if (entity instanceof LivingEntity _entity) {
						_entity.getAttribute(Attributes.MOVEMENT_SPEED).removeModifier(ResourceLocation.parse("meritocraft:asthma.base"));
					}
					entity.getPersistentData().putDouble("asthma", 0);
					if (entity instanceof LivingEntity _entity)
						_entity.removeEffect(MeritocraftModMobEffects.ASTHMA);
					if (sourceentity instanceof Player _player && !_player.level().isClientSide())
						_player.displayClientMessage(Component.literal("\u00A1Tu caballo se ha curado completamente del asma!"), true);
					if (sourceentity instanceof ServerPlayer _player && _player.level() instanceof ServerLevel _level) {
						AdvancementHolder _adv = _level.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_asthma_3"));
						if (_adv != null) {
							AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv);
							if (!_ap.isDone()) {
								for (String criteria : _ap.getRemainingCriteria())
									_player.getAdvancements().award(_adv, criteria);
							}
						}
					}
					if (world instanceof Level _level) {
						if (!_level.isClientSide()) {
							_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("item.spyglass.use")), SoundSource.PLAYERS, 2, 2);
						} else {
							_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("item.spyglass.use")), SoundSource.PLAYERS, 2, 2, false);
						}
					}
					if (!(sourceentity instanceof Player _plr11 && _plr11.gameMode() == GameType.CREATIVE)) {
						if (sourceentity instanceof LivingEntity _entity) {
							ItemStack _setstack12 = new ItemStack(MeritocraftModItems.EMPTY_VACCINE.get()).copy();
							_setstack12.setCount(1);
							_entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack12);
							if (_entity instanceof Player _player)
								_player.getInventory().setChanged();
						}
					}
				} else if ((sourceentity instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY).getItem() == MeritocraftModItems.VACCINE.get()) {
					entity.getPersistentData().putBoolean("asthma.healed", true);
					if (entity instanceof LivingEntity _entity) {
						_entity.getAttribute(Attributes.MOVEMENT_SPEED).removeModifier(ResourceLocation.parse("meritocraft:asthma.base"));
					}
					entity.getPersistentData().putDouble("asthma", 0);
					if (entity instanceof LivingEntity _entity)
						_entity.removeEffect(MeritocraftModMobEffects.ASTHMA);
					if (sourceentity instanceof Player _player && !_player.level().isClientSide())
						_player.displayClientMessage(Component.literal("\u00A1Tu caballo se ha curado completamente del asma!"), true);
					if (sourceentity instanceof ServerPlayer _player && _player.level() instanceof ServerLevel _level) {
						AdvancementHolder _adv = _level.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_asthma_3"));
						if (_adv != null) {
							AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv);
							if (!_ap.isDone()) {
								for (String criteria : _ap.getRemainingCriteria())
									_player.getAdvancements().award(_adv, criteria);
							}
						}
					}
					if (world instanceof Level _level) {
						if (!_level.isClientSide()) {
							_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("item.spyglass.use")), SoundSource.PLAYERS, 2, 2);
						} else {
							_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("item.spyglass.use")), SoundSource.PLAYERS, 2, 2, false);
						}
					}
					if (!(sourceentity instanceof Player _plr22 && _plr22.gameMode() == GameType.CREATIVE)) {
						if (sourceentity instanceof LivingEntity _entity) {
							ItemStack _setstack23 = new ItemStack(MeritocraftModItems.EMPTY_VACCINE.get()).copy();
							_setstack23.setCount(1);
							_entity.setItemInHand(InteractionHand.OFF_HAND, _setstack23);
							if (_entity instanceof Player _player)
								_player.getInventory().setChanged();
						}
					}
				}
			}
		}
	}
}