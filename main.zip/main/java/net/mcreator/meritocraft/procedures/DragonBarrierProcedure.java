package net.mcreator.meritocraft.procedures;

import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.core.BlockPos;
import net.minecraft.ChatFormatting;

import net.mcreator.meritocraft.network.MeritocraftModVariables;

import javax.annotation.Nullable;

import java.util.ArrayList;

@EventBusSubscriber
public class DragonBarrierProcedure {
	@SubscribeEvent
	public static void onPlayerTick(PlayerTickEvent.Post event) {
		execute(event, event.getEntity().level(), event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getEntity());
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		execute(null, world, x, y, z, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		double push = 0;
		if ((entity.level().dimension()) == Level.END) {
			if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).dragonSlayer == false) {
				push = 1;
			} else if (!world.getEntitiesOfClass(Player.class, new AABB(Vec3.ZERO, Vec3.ZERO).move(new Vec3(x, y, z)).inflate(300 / 2d), e -> true).isEmpty()) {
				for (Entity entityiterator : new ArrayList<>(world.players())) {
					if ((entityiterator.level().dimension()) == Level.END && entityiterator.getData(MeritocraftModVariables.PLAYER_VARIABLES).dragonSlayer == true && !(entity == entityiterator) && Math.abs(entityiterator.getX()) <= 300
							&& Math.abs(entityiterator.getZ()) <= 300) {
						push = 2;
					}
				}
			}
			if (push != 0) {
				if (Math.abs((entity.position()).distanceTo((new Vec3(0, y, 0)))) < 4) {
					entity.setDeltaMovement(new Vec3((entity.getX() / (entity.position()).distanceTo((new Vec3(0, y, 0)))), (entity.getDeltaMovement().y() * (-1)), (entity.getZ() / (entity.position()).distanceTo((new Vec3(0, y, 0))))));
					if ((world.getBlockState(BlockPos.containing(x, y - 1, z))).getBlock() == Blocks.END_PORTAL || (world.getBlockState(BlockPos.containing(x, y - 2, z))).getBlock() == Blocks.END_PORTAL) {
						{
							Entity _ent = entity;
							_ent.teleportTo(x, (y + 2), z);
							if (_ent instanceof ServerPlayer _serverPlayer)
								_serverPlayer.connection.teleport(x, (y + 2), z, _ent.getYRot(), _ent.getXRot());
						}
					}
					if (push == 1) {
						if (entity instanceof Player _player31 && !_player31.level().isClientSide()) {
							_player31.displayClientMessage(Component.literal("Debes atestiguar la muerte del drag\u00F3n en esta vida para traspasar la barrera").withStyle(ChatFormatting.DARK_PURPLE), true);
						}
					} else {
						if (entity instanceof Player _player34 && !_player34.level().isClientSide()) {
							_player34.displayClientMessage(Component.literal("Hay m\u00E1s de un jugador que atestigu\u00F3 la muerte del drag\u00F3n cerca").withStyle(ChatFormatting.DARK_PURPLE), true);
						}
					}
				}
			}
		}
	}
}