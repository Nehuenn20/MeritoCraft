package net.mcreator.meritocraft.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.meritocraft.network.MeritocraftModVariables;

public class Hint9Procedure {
	public static String execute(Entity entity) {
		if (entity == null)
			return "";
		String hint = "";
		if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).adv_book_page == 0) {
			hint = "No sos fan de los escudos \u00BFeh?";
		} else if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).adv_book_page == 1) {
			hint = "No vigiles tus pertenencias al interactuar con un aldeano com\u00FAn";
		} else if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).adv_book_page == 2) {
			hint = "Intenta usar m\u00E1s el chat";
		} else if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).adv_book_page == 3) {
			hint = "Amasa un pan";
		} else if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).adv_book_page == 4) {
			hint = "\u00A1Completa los dem\u00E1s logros y derrota al drag\u00F3n!";
		}
		return hint;
	}
}