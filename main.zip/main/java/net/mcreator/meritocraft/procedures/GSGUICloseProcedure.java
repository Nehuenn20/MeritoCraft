package net.mcreator.meritocraft.procedures;

import net.minecraft.world.level.GameType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;

import net.mcreator.meritocraft.network.MeritocraftModVariables;

public class GSGUICloseProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).creative == true) {
			if (entity instanceof ServerPlayer _player)
				_player.setGameMode(GameType.CREATIVE);
		} else if (!(entity instanceof Player _plr1 && _plr1.gameMode() == GameType.ADVENTURE)) {
			if (entity instanceof ServerPlayer _player)
				_player.setGameMode(GameType.SURVIVAL);
		}
	}
}