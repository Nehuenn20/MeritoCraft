package net.mcreator.meritocraft.procedures;

import net.minecraft.client.Minecraft;

import net.mcreator.meritocraft.client.toasts.MeritToast;
import net.mcreator.meritocraft.client.toasts.FinToast;

public class ToastPackageClientProcProcedure {
	public static void execute(String inboundString) {
		if (inboundString == null)
			return;
		if ((inboundString).equals("fin")) {
			Minecraft.getInstance().getToastManager().addToast(new FinToast());
		} else if ((inboundString).equals("merit")) {
			Minecraft.getInstance().getToastManager().addToast(new MeritToast());
		}
	}
}