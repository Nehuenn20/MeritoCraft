package net.mcreator.meritocraft.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.network.chat.Component;

import net.mcreator.meritocraft.init.MeritocraftModMobEffects;

public class AsthmaReactivationProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player) {
			entity.getPersistentData().putDouble("asthmalevel", (1 + entity.getPersistentData().getDoubleOr("asthmalevel", 0)));
			if (entity.getPersistentData().getDoubleOr("asthmalevel", 0) >= 5) {
				if (entity instanceof Player _player && !_player.level().isClientSide())
					_player.displayClientMessage(Component.literal("\u00A1Tu asma acaba de empeorar!"), true);
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(MeritocraftModMobEffects.ASTHMA, -1,
							1 + (entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(MeritocraftModMobEffects.ASTHMA) ? _livEnt.getEffect(MeritocraftModMobEffects.ASTHMA).getAmplifier() : 0)));
				entity.getPersistentData().putDouble("asthmalevel", 0);
			}
		}
	}
}