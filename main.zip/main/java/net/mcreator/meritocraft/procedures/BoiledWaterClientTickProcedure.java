package net.mcreator.meritocraft.procedures;

import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.sounds.SoundSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.BlockPos;

import javax.annotation.Nullable;

@EventBusSubscriber
public class BoiledWaterClientTickProcedure {
	@SubscribeEvent
	public static void onPlayerTick(PlayerTickEvent.Post event) {
		execute(event, event.getEntity().level(), event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ());
	}

	public static void execute(LevelAccessor world, double x, double y, double z) {
		execute(null, world, x, y, z);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z) {
		double sx = 0;
		double sy = 0;
		double sz = 0;
		double found = 0;
		if (world instanceof Level _lvl0 && _lvl0.isBrightOutside()) {
			sx = -4;
			for (int index0 = 0; index0 < 8; index0++) {
				sy = -4;
				for (int index1 = 0; index1 < 8; index1++) {
					sz = -4;
					for (int index2 = 0; index2 < 8; index2++) {
						if (world.getBiome(BlockPos.containing(x + sx, y + sy, z + sz)).value().getBaseTemperature() * 100f >= 150) {
							if ((world.getBlockState(BlockPos.containing(x + sx, y + sy, z + sz))).getBlock() == Blocks.WATER) {
								if (!((world.getBlockState(BlockPos.containing(x + sx, y + sy + 2, z + sz))).getBlock() == Blocks.WATER)) {
									if (0.03 > Math.random()) {
										world.addParticle(ParticleTypes.BUBBLE, (x + sx + Math.random()), (y + sy), (z + sz + Math.random()), 0, 1, 0);
										if (0.4 > Math.random()) {
											world.addParticle(ParticleTypes.BUBBLE, (x + sx + Math.random()), (y + sy), (z + sz + Math.random()), 0, 1, 0);
										}
										found = found + 1;
									}
								}
							}
							sz = sz + 1;
						}
					}
					sy = sy + 1;
				}
				sx = sx + 1;
			}
			for (int index3 = 0; index3 < (int) Math.min(found, 4); index3++) {
				if (world instanceof Level _level) {
					if (!_level.isClientSide()) {
						_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("block.bubble_column.bubble_pop")), SoundSource.AMBIENT, (float) 0.1, (float) 0.3);
					} else {
						_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("block.bubble_column.bubble_pop")), SoundSource.AMBIENT, (float) 0.1, (float) 0.3, false);
					}
				}
			}
		}
	}
}