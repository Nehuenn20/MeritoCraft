package net.mcreator.meritocraft.procedures;

import net.neoforged.neoforge.event.tick.EntityTickEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.advancements.AdvancementHolder;

import javax.annotation.Nullable;

import java.util.UUID;

@EventBusSubscriber
public class VillagerClaustrophobiaProcedure {
	@SubscribeEvent
	public static void onEntityTick(EntityTickEvent.Pre event) {
		execute(event, event.getEntity().level(), event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getEntity());
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		execute(null, world, x, y, z, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		double timer = 0;
		double insomnio_timer = 0;
		if (entity instanceof Villager) {
			if (!(entity.getPersistentData().getStringOr("interactedWith", "")).isEmpty()) {
				if (entity.getPersistentData().getDoubleOr("claustrophobia_timer", 0) == 0) {
					entity.getPersistentData().putDouble("xcord", (entity.getX()));
					entity.getPersistentData().putDouble("zcord", (entity.getZ()));
					timer = 0;
				}
				if (!(entity instanceof LivingEntity _livEnt7 && _livEnt7.isSleeping())) {
					entity.getPersistentData().putDouble("claustrophobia_timer", (entity.getPersistentData().getDoubleOr("claustrophobia_timer", 0) + 1));
				}
				timer = entity.getPersistentData().getDoubleOr("claustrophobia_timer", 0);
				if (timer == 1200) {
					if (!(Math.ceil(entity.getPersistentData().getDoubleOr("xcord", 0)) == Math.ceil(entity.getX()) && Math.ceil(entity.getPersistentData().getDoubleOr("zcord", 0)) == Math.ceil(entity.getZ()))) {
						entity.getPersistentData().putDouble("claustrophobia_timer", 0);
					}
				}
				if (timer == 2400) {
					if (!(Math.ceil(entity.getPersistentData().getDoubleOr("xcord", 0)) == Math.ceil(entity.getX()) && Math.ceil(entity.getPersistentData().getDoubleOr("zcord", 0)) == Math.ceil(entity.getZ()))) {
						entity.getPersistentData().putDouble("claustrophobia_timer", 0);
					}
				}
				if (timer == 3600) {
					if (!(Math.ceil(entity.getPersistentData().getDoubleOr("xcord", 0)) == Math.ceil(entity.getX()) && Math.ceil(entity.getPersistentData().getDoubleOr("zcord", 0)) == Math.ceil(entity.getZ()))) {
						entity.getPersistentData().putDouble("claustrophobia_timer", 0);
					}
				}
				if (timer == 4800) {
					if (!(Math.ceil(entity.getPersistentData().getDoubleOr("xcord", 0)) == Math.ceil(entity.getX()) && Math.ceil(entity.getPersistentData().getDoubleOr("zcord", 0)) == Math.ceil(entity.getZ()))) {
						entity.getPersistentData().putDouble("claustrophobia_timer", 0);
					}
				}
				if (timer >= 6000) {
					if (Math.ceil(entity.getPersistentData().getDoubleOr("xcord", 0)) == Math.ceil(entity.getX()) && Math.ceil(entity.getPersistentData().getDoubleOr("zcord", 0)) == Math.ceil(entity.getZ())) {
						if (world instanceof Level _level && !_level.isClientSide())
							_level.explode(null, x, y, z, 4, Level.ExplosionInteraction.MOB);
						if ((world instanceof ServerLevel _level37 ? getEntityFromUUID(_level37, (entity.getPersistentData().getStringOr("interactedWith", ""))) : null) instanceof ServerPlayer _player
								&& _player.level() instanceof ServerLevel _level) {
							AdvancementHolder _adv = _level.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_claustrophobia"));
							if (_adv != null) {
								AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv);
								if (!_ap.isDone()) {
									for (String criteria : _ap.getRemainingCriteria())
										_player.getAdvancements().award(_adv, criteria);
								}
							}
						}
					}
					entity.getPersistentData().putDouble("claustrophobia_timer", 0);
				}
				if (entity instanceof LivingEntity _livEnt40 && _livEnt40.isSleeping()) {
					entity.getPersistentData().putDouble("insomnio_timer", 0);
					if (entity.getPersistentData().getDoubleOr("insomnio_timer", 0) == 0) {
						insomnio_timer = 0;
					}
				} else {
					entity.getPersistentData().putDouble("insomnio_timer", (entity.getPersistentData().getDoubleOr("insomnio_timer", 0) + 1));
					insomnio_timer = entity.getPersistentData().getDoubleOr("insomnio_timer", 0);
					if (insomnio_timer >= 48000) {
						if (world instanceof Level _level && !_level.isClientSide())
							_level.explode(null, x, y, z, 4, Level.ExplosionInteraction.MOB);
						if ((world instanceof ServerLevel _level48 ? getEntityFromUUID(_level48, (entity.getPersistentData().getStringOr("interactedWith", ""))) : null) instanceof ServerPlayer _player
								&& _player.level() instanceof ServerLevel _level) {
							AdvancementHolder _adv = _level.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_insomnio"));
							if (_adv != null) {
								AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv);
								if (!_ap.isDone()) {
									for (String criteria : _ap.getRemainingCriteria())
										_player.getAdvancements().award(_adv, criteria);
								}
							}
						}
						entity.getPersistentData().putDouble("insomnio_timer", 0);
					}
				}
			}
		}
	}

	private static Entity getEntityFromUUID(ServerLevel level, String uuid) {
		try {
			return level.getEntity(UUID.fromString(uuid));
		} catch (IllegalArgumentException e) {
			return null;
		}
	}
}