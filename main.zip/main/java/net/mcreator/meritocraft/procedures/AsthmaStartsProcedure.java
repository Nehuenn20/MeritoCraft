package net.mcreator.meritocraft.procedures;

import net.minecraft.world.entity.animal.horse.Horse;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.meritocraft.init.MeritocraftModMobEffects;

public class AsthmaStartsProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		double slow = 0;
		if (entity instanceof LivingEntity _livEnt0 && _livEnt0.hasEffect(MeritocraftModMobEffects.CLEAR_BREATHING)
				|| entity instanceof Horse && !(entity instanceof LivingEntity _livingEntity2 && _livingEntity2.getAttribute(Attributes.MOVEMENT_SPEED).hasModifier(ResourceLocation.parse("meritocraft:asthma.base")))) {
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MeritocraftModMobEffects.ASTHMA);
		} else {
			slow = (entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(MeritocraftModMobEffects.ASTHMA) ? _livEnt.getEffect(MeritocraftModMobEffects.ASTHMA).getAmplifier() : 0) * (-0.1);
			if (entity instanceof LivingEntity _entity) {
				_entity.getAttribute(Attributes.MOVEMENT_SPEED).removeModifier(ResourceLocation.parse("meritocraft:asthma"));
			}
			if (entity instanceof LivingEntity _entity) {
				AttributeModifier modifier = new AttributeModifier(ResourceLocation.parse("meritocraft:asthma"), (slow >= -0.5 ? slow : -0.5), AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
				if (!_entity.getAttribute(Attributes.MOVEMENT_SPEED).hasModifier(modifier.id())) {
					_entity.getAttribute(Attributes.MOVEMENT_SPEED).addPermanentModifier(modifier);
				}
			}
		}
	}
}