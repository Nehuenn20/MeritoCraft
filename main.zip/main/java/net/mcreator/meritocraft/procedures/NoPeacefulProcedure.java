package net.mcreator.meritocraft.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.Difficulty;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.advancements.AdvancementHolder;

import net.mcreator.meritocraft.init.MeritocraftModMobEffects;

import java.util.ArrayList;

public class NoPeacefulProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		double diff = 0;
		if (world.getDifficulty() == Difficulty.PEACEFUL || world.getDifficulty() == Difficulty.EASY) {
			if (world.getDifficulty() == Difficulty.PEACEFUL) {
				diff = 0;
			} else {
				diff = 1;
			}
			if (world instanceof ServerLevel _level)
				_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
						"difficulty hard");
			for (Entity entityiterator : new ArrayList<>(world.players())) {
				if (diff == 0) {
					if (world instanceof Level _level && !_level.isClientSide())
						_level.explode(null, (entityiterator.getX()), (entityiterator.getY() + 1), (entityiterator.getZ()), 2, Level.ExplosionInteraction.NONE);
					if (entityiterator instanceof ServerPlayer _player && _player.level() instanceof ServerLevel _level) {
						AdvancementHolder _adv = _level.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_no_peaceful"));
						if (_adv != null) {
							AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv);
							if (!_ap.isDone()) {
								for (String criteria : _ap.getRemainingCriteria())
									_player.getAdvancements().award(_adv, criteria);
							}
						}
					}
				} else {
					if (world instanceof Level _level && !_level.isClientSide())
						_level.explode(null, (entityiterator.getX()), (entityiterator.getY() + 1), (entityiterator.getZ()), 1, Level.ExplosionInteraction.NONE);
					if (entityiterator instanceof ServerPlayer _player && _player.level() instanceof ServerLevel _level) {
						AdvancementHolder _adv = _level.getServer().getAdvancements().get(ResourceLocation.parse("meritocraft:adv_no_peaceful"));
						if (_adv != null) {
							AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv);
							if (!_ap.isDone()) {
								for (String criteria : _ap.getRemainingCriteria())
									_player.getAdvancements().award(_adv, criteria);
							}
						}
					}
				}
			}
		}
		if (world.getDifficulty() == Difficulty.NORMAL && !(entity instanceof LivingEntity _livEnt16 && _livEnt16.hasEffect(MeritocraftModMobEffects.NORMAL))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MeritocraftModMobEffects.NORMAL, -1, 0, false, false));
		} else if (!(world.getDifficulty() == Difficulty.NORMAL) && entity instanceof LivingEntity _livEnt19 && _livEnt19.hasEffect(MeritocraftModMobEffects.NORMAL)) {
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MeritocraftModMobEffects.NORMAL);
		}
	}
}