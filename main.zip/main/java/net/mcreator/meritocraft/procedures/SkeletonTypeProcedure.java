package net.mcreator.meritocraft.procedures;

import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.entity.monster.WitherSkeleton;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.tags.TagKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.particles.ParticleTypes;

import net.mcreator.meritocraft.init.MeritocraftModMobEffects;
import net.mcreator.meritocraft.init.MeritocraftModAttributes;

import javax.annotation.Nullable;

@EventBusSubscriber
public class SkeletonTypeProcedure {
	@SubscribeEvent
	public static void onEntityAttacked(LivingIncomingDamageEvent event) {
		if (event.getEntity() != null) {
			execute(event, event.getEntity().level(), event.getEntity(), event.getSource().getDirectEntity(), event.getSource().getEntity());
		}
	}

	public static void execute(LevelAccessor world, Entity entity, Entity immediatesourceentity, Entity sourceentity) {
		execute(null, world, entity, immediatesourceentity, sourceentity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, Entity entity, Entity immediatesourceentity, Entity sourceentity) {
		if (entity == null || immediatesourceentity == null || sourceentity == null)
			return;
		if (sourceentity.getType().is(TagKey.create(Registries.ENTITY_TYPE, ResourceLocation.parse("minecraft:skeletons")))) {
			if (!(entity instanceof LivingEntity _livEnt1 && _livEnt1.isBlocking()) && (immediatesourceentity instanceof Arrow || immediatesourceentity instanceof WitherSkeleton)) {
				if ((sourceentity instanceof LivingEntity _livingEntity4 && _livingEntity4.getAttributes().hasAttribute(MeritocraftModAttributes.SKELETON_ATTRIBUTE)
						? _livingEntity4.getAttribute(MeritocraftModAttributes.SKELETON_ATTRIBUTE).getBaseValue()
						: 0) == 4) {
					if (world instanceof Level _level && !_level.isClientSide())
						_level.explode(null, (immediatesourceentity.getX()), (immediatesourceentity.getY()), (immediatesourceentity.getZ()), 1, Level.ExplosionInteraction.MOB);
				} else if ((sourceentity instanceof LivingEntity _livingEntity9 && _livingEntity9.getAttributes().hasAttribute(MeritocraftModAttributes.SKELETON_ATTRIBUTE)
						? _livingEntity9.getAttribute(MeritocraftModAttributes.SKELETON_ATTRIBUTE).getBaseValue()
						: 0) == 5) {
					if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 80, 1, false, true));
				} else if ((sourceentity instanceof LivingEntity _livingEntity11 && _livingEntity11.getAttributes().hasAttribute(MeritocraftModAttributes.SKELETON_ATTRIBUTE)
						? _livingEntity11.getAttribute(MeritocraftModAttributes.SKELETON_ATTRIBUTE).getBaseValue()
						: 0) == 6) {
					if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.INSTANT_DAMAGE, 1, 0, false, false));
				} else if ((sourceentity instanceof LivingEntity _livingEntity13 && _livingEntity13.getAttributes().hasAttribute(MeritocraftModAttributes.SKELETON_ATTRIBUTE)
						? _livingEntity13.getAttribute(MeritocraftModAttributes.SKELETON_ATTRIBUTE).getBaseValue()
						: 0) == 7) {
					if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.WITHER, 80, 1, false, true));
				} else if ((sourceentity instanceof LivingEntity _livingEntity15 && _livingEntity15.getAttributes().hasAttribute(MeritocraftModAttributes.SKELETON_ATTRIBUTE)
						? _livingEntity15.getAttribute(MeritocraftModAttributes.SKELETON_ATTRIBUTE).getBaseValue()
						: 0) == 8) {
					if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.MINING_FATIGUE, 80, 1, false, true));
				} else if ((sourceentity instanceof LivingEntity _livingEntity17 && _livingEntity17.getAttributes().hasAttribute(MeritocraftModAttributes.SKELETON_ATTRIBUTE)
						? _livingEntity17.getAttribute(MeritocraftModAttributes.SKELETON_ATTRIBUTE).getBaseValue()
						: 0) == 9) {
					if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.NAUSEA, 160, 1, false, true));
				} else if ((sourceentity instanceof LivingEntity _livingEntity19 && _livingEntity19.getAttributes().hasAttribute(MeritocraftModAttributes.SKELETON_ATTRIBUTE)
						? _livingEntity19.getAttribute(MeritocraftModAttributes.SKELETON_ATTRIBUTE).getBaseValue()
						: 0) == 10) {
					if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.POISON, 60, 1, false, true));
				} else if ((sourceentity instanceof LivingEntity _livingEntity21 && _livingEntity21.getAttributes().hasAttribute(MeritocraftModAttributes.SKELETON_ATTRIBUTE)
						? _livingEntity21.getAttribute(MeritocraftModAttributes.SKELETON_ATTRIBUTE).getBaseValue()
						: 0) == 11) {
					if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 80, 2, false, true));
				} else if ((sourceentity instanceof LivingEntity _livingEntity23 && _livingEntity23.getAttributes().hasAttribute(MeritocraftModAttributes.SKELETON_ATTRIBUTE)
						? _livingEntity23.getAttribute(MeritocraftModAttributes.SKELETON_ATTRIBUTE).getBaseValue()
						: 0) == 12) {
					if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 80, 1, false, true));
				} else if ((sourceentity instanceof LivingEntity _livingEntity25 && _livingEntity25.getAttributes().hasAttribute(MeritocraftModAttributes.SKELETON_ATTRIBUTE)
						? _livingEntity25.getAttribute(MeritocraftModAttributes.SKELETON_ATTRIBUTE).getBaseValue()
						: 0) == 13) {
					entity.igniteForSeconds(4);
				} else if ((sourceentity instanceof LivingEntity _livingEntity27 && _livingEntity27.getAttributes().hasAttribute(MeritocraftModAttributes.SKELETON_ATTRIBUTE)
						? _livingEntity27.getAttribute(MeritocraftModAttributes.SKELETON_ATTRIBUTE).getBaseValue()
						: 0) == 14) {
					if (sourceentity instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.INSTANT_DAMAGE, 1, 0, false, true));
					if (world instanceof ServerLevel _level)
						_level.sendParticles(ParticleTypes.HEART, (sourceentity.getX()), (sourceentity.getY() + 2), (sourceentity.getZ()), 3, 0.2, 0.2, 0.2, 0.1);
				} else if ((sourceentity instanceof LivingEntity _livingEntity33 && _livingEntity33.getAttributes().hasAttribute(MeritocraftModAttributes.SKELETON_ATTRIBUTE)
						? _livingEntity33.getAttribute(MeritocraftModAttributes.SKELETON_ATTRIBUTE).getBaseValue()
						: 0) == 15) {
					if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(MeritocraftModMobEffects.HEMORRHAGE, 200,
								(int) ((entity instanceof LivingEntity _livEnt34 && _livEnt34.hasEffect(MeritocraftModMobEffects.HEMORRHAGE)
										? (entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(MeritocraftModMobEffects.HEMORRHAGE) ? _livEnt.getEffect(MeritocraftModMobEffects.HEMORRHAGE).getAmplifier() : 0)
										: -1) + 1),
								false, true));
					if (sourceentity instanceof LivingEntity _livingEntity38 && _livingEntity38.getAttributes().hasAttribute(Attributes.MAX_HEALTH))
						_livingEntity38.getAttribute(Attributes.MAX_HEALTH).setBaseValue(
								((sourceentity instanceof LivingEntity _livingEntity37 && _livingEntity37.getAttributes().hasAttribute(Attributes.MAX_HEALTH) ? _livingEntity37.getAttribute(Attributes.MAX_HEALTH).getBaseValue() : 0) + 2));
				}
			}
		}
	}
}