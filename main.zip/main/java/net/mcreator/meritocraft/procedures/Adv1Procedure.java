package net.mcreator.meritocraft.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.meritocraft.network.MeritocraftModVariables;

public class Adv1Procedure {
	public static String execute(Entity entity) {
		if (entity == null)
			return "";
		return entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).adv1;
	}
}