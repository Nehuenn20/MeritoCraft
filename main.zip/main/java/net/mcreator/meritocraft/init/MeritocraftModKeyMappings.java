/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.meritocraft.init;

import org.lwjgl.glfw.GLFW;

import net.neoforged.neoforge.client.network.ClientPacketDistributor;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping;

import net.mcreator.meritocraft.network.SlimeEatKeyResistMessage;
import net.mcreator.meritocraft.network.GamemodeSKeyMessage;

@EventBusSubscriber(Dist.CLIENT)
public class MeritocraftModKeyMappings {
	public static final KeyMapping GAMEMODE_S_KEY = new KeyMapping("key.meritocraft.gamemode_s_key", GLFW.GLFW_KEY_G, "key.categories.misc") {
		private boolean isDownOld = false;

		@Override
		public void setDown(boolean isDown) {
			super.setDown(isDown);
			if (isDownOld != isDown && isDown) {
				ClientPacketDistributor.sendToServer(new GamemodeSKeyMessage(0, 0));
				GamemodeSKeyMessage.pressAction(Minecraft.getInstance().player, 0, 0);
			}
			isDownOld = isDown;
		}
	};
	public static final KeyMapping SLIME_EAT_KEY_RESIST = new KeyMapping("key.meritocraft.slime_eat_key_resist", GLFW.GLFW_KEY_LEFT_SHIFT, "key.categories.misc") {
		private boolean isDownOld = false;

		@Override
		public void setDown(boolean isDown) {
			super.setDown(isDown);
			if (isDownOld != isDown && isDown) {
				ClientPacketDistributor.sendToServer(new SlimeEatKeyResistMessage(0, 0));
				SlimeEatKeyResistMessage.pressAction(Minecraft.getInstance().player, 0, 0);
			}
			isDownOld = isDown;
		}
	};

	@SubscribeEvent
	public static void registerKeyMappings(RegisterKeyMappingsEvent event) {
		event.register(GAMEMODE_S_KEY);
		event.register(SLIME_EAT_KEY_RESIST);
	}

	@EventBusSubscriber(Dist.CLIENT)
	public static class KeyEventListener {
		@SubscribeEvent
		public static void onClientTick(ClientTickEvent.Post event) {
			if (Minecraft.getInstance().screen == null) {
				GAMEMODE_S_KEY.consumeClick();
				SLIME_EAT_KEY_RESIST.consumeClick();
			}
		}
	}
}