/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.meritocraft.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.meritocraft.MeritocraftMod;

@EventBusSubscriber
public class MeritocraftModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MeritocraftMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(MeritocraftModItems.CRAPEST_SPAWN_EGG.get());
			tabData.accept(MeritocraftModItems.HEROBRINE_SPAWN_EGG.get());
			tabData.accept(MeritocraftModItems.VILLAGER_BANDIT_SPAWN_EGG.get());
			tabData.accept(MeritocraftModItems.GRASS_SPAWN_EGG.get());
			tabData.accept(MeritocraftModItems.CERDO_SPAWN_EGG.get());
			tabData.accept(MeritocraftModItems.CRAPER_SPAWN_EGG.get());
			tabData.accept(MeritocraftModItems.SHOVEL_ENTITY_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(MeritocraftModItems.BOILED_WATER_BUCKET.get());
			tabData.accept(MeritocraftModItems.DIFFICULTY_ITEM.get());
			tabData.accept(MeritocraftModItems.EMPTY_VACCINE.get());
			tabData.accept(MeritocraftModItems.VACCINE.get());
			tabData.accept(MeritocraftModItems.ADV_BOOK.get());
			tabData.accept(MeritocraftModItems.GUNPOWDER_ON_A_STICK.get());
			tabData.accept(MeritocraftModItems.POTION_BOOK.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.FOOD_AND_DRINKS) {
			tabData.accept(MeritocraftModItems.EFEDRA_FRUIT.get());
			tabData.accept(MeritocraftModItems.EFEDRA_STABILIZED_EXTRACT.get());
			tabData.accept(MeritocraftModItems.RAW_BREAD.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(MeritocraftModItems.EFEDRA_EXTRACT.get());
			tabData.accept(MeritocraftModItems.EFEDRA_STEM.get());
			tabData.accept(MeritocraftModItems.GOLEM_HEART.get());
			tabData.accept(MeritocraftModItems.WARDEN_HEART.get());
			tabData.accept(MeritocraftModItems.GUARDIAN_HEART.get());
			tabData.accept(MeritocraftModItems.SEA_HEART.get());
			tabData.accept(MeritocraftModItems.MAGIC_CATALYST.get());
			tabData.accept(MeritocraftModItems.SEA_SOUL.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(MeritocraftModItems.ANTI_ENDERMAN_HELMET.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(MeritocraftModItems.EFEDRA_SEED.get());
			tabData.accept(MeritocraftModBlocks.EFEDRA.get().asItem());
			tabData.accept(MeritocraftModBlocks.MELON_SLAB.get().asItem());
			tabData.accept(MeritocraftModBlocks.MELON_STAIR.get().asItem());
			tabData.accept(MeritocraftModBlocks.MELON_WALL.get().asItem());
			tabData.accept(MeritocraftModBlocks.GLISTERING_MELON_BLOCK.get().asItem());
			tabData.accept(MeritocraftModBlocks.GLISTERING_MELON_STAIR.get().asItem());
			tabData.accept(MeritocraftModBlocks.GLISTERING_MELON_SLAB.get().asItem());
			tabData.accept(MeritocraftModBlocks.GLISTERING_MELON_WALL.get().asItem());
		}
	}
}