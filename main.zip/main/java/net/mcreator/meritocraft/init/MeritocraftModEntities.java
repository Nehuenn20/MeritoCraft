/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.meritocraft.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.EventPriority;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;

import net.mcreator.meritocraft.entity.*;
import net.mcreator.meritocraft.MeritocraftMod;

@EventBusSubscriber
public class MeritocraftModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(Registries.ENTITY_TYPE, MeritocraftMod.MODID);
	public static final DeferredHolder<EntityType<?>, EntityType<CrapestEntity>> CRAPEST = register("crapest",
			EntityType.Builder.<CrapestEntity>of(CrapestEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.sized(0.9f, 0.9f));
	public static final DeferredHolder<EntityType<?>, EntityType<HerobrineEntity>> HEROBRINE = register("herobrine",
			EntityType.Builder.<HerobrineEntity>of(HerobrineEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune().ridingOffset(-0.6f).sized(0.6f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<VillagerBanditEntity>> VILLAGER_BANDIT = register("villager_bandit",
			EntityType.Builder.<VillagerBanditEntity>of(VillagerBanditEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.sized(0.6f, 1.95f));
	public static final DeferredHolder<EntityType<?>, EntityType<GrassEntity>> GRASS = register("grass",
			EntityType.Builder.<GrassEntity>of(GrassEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.sized(0.6f, 0.85f));
	public static final DeferredHolder<EntityType<?>, EntityType<CerdoEntity>> CERDO = register("cerdo",
			EntityType.Builder.<CerdoEntity>of(CerdoEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.sized(0.9f, 0.9f));
	public static final DeferredHolder<EntityType<?>, EntityType<CraperEntity>> CRAPER = register("craper",
			EntityType.Builder.<CraperEntity>of(CraperEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.sized(0.6f, 1.7f));
	public static final DeferredHolder<EntityType<?>, EntityType<ShovelEntityEntity>> SHOVEL_ENTITY = register("shovel_entity",
			EntityType.Builder.<ShovelEntityEntity>of(ShovelEntityEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.sized(0.6f, 0.8f));

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> DeferredHolder<EntityType<?>, EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(ResourceKey.create(Registries.ENTITY_TYPE, ResourceLocation.fromNamespaceAndPath(MeritocraftMod.MODID, registryname))));
	}

	@SubscribeEvent(priority = EventPriority.HIGHEST)
	public static void registerCapabilities(RegisterCapabilitiesEvent event) {
		event.registerEntity(Capabilities.ItemHandler.ENTITY, VILLAGER_BANDIT.get(), (living, context) -> living.getCombinedInventory());
	}

	@SubscribeEvent
	public static void init(RegisterSpawnPlacementsEvent event) {
		CrapestEntity.init(event);
		HerobrineEntity.init(event);
		VillagerBanditEntity.init(event);
		GrassEntity.init(event);
		CerdoEntity.init(event);
		CraperEntity.init(event);
		ShovelEntityEntity.init(event);
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(CRAPEST.get(), CrapestEntity.createAttributes().build());
		event.put(HEROBRINE.get(), HerobrineEntity.createAttributes().build());
		event.put(VILLAGER_BANDIT.get(), VillagerBanditEntity.createAttributes().build());
		event.put(GRASS.get(), GrassEntity.createAttributes().build());
		event.put(CERDO.get(), CerdoEntity.createAttributes().build());
		event.put(CRAPER.get(), CraperEntity.createAttributes().build());
		event.put(SHOVEL_ENTITY.get(), ShovelEntityEntity.createAttributes().build());
	}
}