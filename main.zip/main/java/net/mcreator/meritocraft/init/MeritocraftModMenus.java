/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.meritocraft.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;
import net.neoforged.neoforge.client.network.ClientPacketDistributor;

import net.minecraft.world.inventory.Slot;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.core.registries.Registries;
import net.minecraft.client.Minecraft;

import net.mcreator.meritocraft.world.inventory.VillagerBanditGUIMenu;
import net.mcreator.meritocraft.world.inventory.PotionBookGUIMenu;
import net.mcreator.meritocraft.world.inventory.GamemodeSGUIMenu;
import net.mcreator.meritocraft.world.inventory.DifficultyIGUIMenu;
import net.mcreator.meritocraft.world.inventory.AdvGUIMenu;
import net.mcreator.meritocraft.network.MenuStateUpdateMessage;
import net.mcreator.meritocraft.MeritocraftMod;

import java.util.Map;

public class MeritocraftModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(Registries.MENU, MeritocraftMod.MODID);
	public static final DeferredHolder<MenuType<?>, MenuType<DifficultyIGUIMenu>> DIFFICULTY_IGUI = REGISTRY.register("difficulty_igui", () -> IMenuTypeExtension.create(DifficultyIGUIMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<GamemodeSGUIMenu>> GAMEMODE_SGUI = REGISTRY.register("gamemode_sgui", () -> IMenuTypeExtension.create(GamemodeSGUIMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<VillagerBanditGUIMenu>> VILLAGER_BANDIT_GUI = REGISTRY.register("villager_bandit_gui", () -> IMenuTypeExtension.create(VillagerBanditGUIMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<AdvGUIMenu>> ADV_GUI = REGISTRY.register("adv_gui", () -> IMenuTypeExtension.create(AdvGUIMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<PotionBookGUIMenu>> POTION_BOOK_GUI = REGISTRY.register("potion_book_gui", () -> IMenuTypeExtension.create(PotionBookGUIMenu::new));

	public interface MenuAccessor {
		Map<String, Object> getMenuState();

		Map<Integer, Slot> getSlots();

		default void sendMenuStateUpdate(Player player, int elementType, String name, Object elementState, boolean needClientUpdate) {
			getMenuState().put(elementType + ":" + name, elementState);
			if (player instanceof ServerPlayer serverPlayer) {
				PacketDistributor.sendToPlayer(serverPlayer, new MenuStateUpdateMessage(elementType, name, elementState));
			} else if (player.level().isClientSide) {
				if (Minecraft.getInstance().screen instanceof MeritocraftModScreens.ScreenAccessor accessor && needClientUpdate)
					accessor.updateMenuState(elementType, name, elementState);
				ClientPacketDistributor.sendToServer(new MenuStateUpdateMessage(elementType, name, elementState));
			}
		}

		default <T> T getMenuState(int elementType, String name, T defaultValue) {
			try {
				return (T) getMenuState().getOrDefault(elementType + ":" + name, defaultValue);
			} catch (ClassCastException e) {
				return defaultValue;
			}
		}
	}
}