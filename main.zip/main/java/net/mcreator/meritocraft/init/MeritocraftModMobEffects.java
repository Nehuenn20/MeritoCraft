/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.meritocraft.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.entity.living.MobEffectEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.core.registries.Registries;

import net.mcreator.meritocraft.procedures.SpontaneousCExpiresProcedure;
import net.mcreator.meritocraft.procedures.LeptospirosisEndProcedure;
import net.mcreator.meritocraft.procedures.AsthmaEndsProcedure;
import net.mcreator.meritocraft.potion.*;
import net.mcreator.meritocraft.MeritocraftMod;

@EventBusSubscriber
public class MeritocraftModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(Registries.MOB_EFFECT, MeritocraftMod.MODID);
	public static final DeferredHolder<MobEffect, MobEffect> CURSE = REGISTRY.register("curse", () -> new CurseMobEffect());
	public static final DeferredHolder<MobEffect, MobEffect> ASTHMA = REGISTRY.register("asthma", () -> new AsthmaMobEffect());
	public static final DeferredHolder<MobEffect, MobEffect> CLEAR_BREATHING = REGISTRY.register("clear_breathing", () -> new ClearBreathingMobEffect());
	public static final DeferredHolder<MobEffect, MobEffect> NORMAL = REGISTRY.register("normal", () -> new NormalMobEffect());
	public static final DeferredHolder<MobEffect, MobEffect> SPONTANEOUS_COMBUSTION = REGISTRY.register("spontaneous_combustion", () -> new SpontaneousCombustionMobEffect());
	public static final DeferredHolder<MobEffect, MobEffect> HEMORRHAGE = REGISTRY.register("hemorrhage", () -> new HemorrhageMobEffect());
	public static final DeferredHolder<MobEffect, MobEffect> LEPTOSPIROSIS = REGISTRY.register("leptospirosis", () -> new LeptospirosisMobEffect());
	public static final DeferredHolder<MobEffect, MobEffect> BLESSED = REGISTRY.register("blessed", () -> new BlessedMobEffect());

	@SubscribeEvent
	public static void onEffectRemoved(MobEffectEvent.Remove event) {
		MobEffectInstance effectInstance = event.getEffectInstance();
		if (effectInstance != null) {
			expireEffects(event.getEntity(), effectInstance);
		}
	}

	@SubscribeEvent
	public static void onEffectExpired(MobEffectEvent.Expired event) {
		MobEffectInstance effectInstance = event.getEffectInstance();
		if (effectInstance != null) {
			expireEffects(event.getEntity(), effectInstance);
		}
	}

	private static void expireEffects(Entity entity, MobEffectInstance effectInstance) {
		if (effectInstance.getEffect().is(ASTHMA)) {
			AsthmaEndsProcedure.execute(entity.level(), entity.getX(), entity.getY(), entity.getZ(), entity);
		} else if (effectInstance.getEffect().is(SPONTANEOUS_COMBUSTION)) {
			SpontaneousCExpiresProcedure.execute(entity.level(), entity);
		} else if (effectInstance.getEffect().is(LEPTOSPIROSIS)) {
			LeptospirosisEndProcedure.execute(entity);
		}
	}
}