/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.meritocraft.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.meritocraft.client.renderer.*;

@EventBusSubscriber(Dist.CLIENT)
public class MeritocraftModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(MeritocraftModEntities.CRAPEST.get(), CrapestRenderer::new);
		event.registerEntityRenderer(MeritocraftModEntities.HEROBRINE.get(), HerobrineRenderer::new);
		event.registerEntityRenderer(MeritocraftModEntities.VILLAGER_BANDIT.get(), VillagerBanditRenderer::new);
		event.registerEntityRenderer(MeritocraftModEntities.GRASS.get(), GrassRenderer::new);
		event.registerEntityRenderer(MeritocraftModEntities.CERDO.get(), CerdoRenderer::new);
		event.registerEntityRenderer(MeritocraftModEntities.CRAPER.get(), CraperRenderer::new);
		event.registerEntityRenderer(MeritocraftModEntities.SHOVEL_ENTITY.get(), ShovelEntityRenderer::new);
	}
}