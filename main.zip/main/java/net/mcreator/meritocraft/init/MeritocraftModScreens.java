/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.meritocraft.init;

import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.meritocraft.client.gui.VillagerBanditGUIScreen;
import net.mcreator.meritocraft.client.gui.PotionBookGUIScreen;
import net.mcreator.meritocraft.client.gui.GamemodeSGUIScreen;
import net.mcreator.meritocraft.client.gui.DifficultyIGUIScreen;
import net.mcreator.meritocraft.client.gui.AdvGUIScreen;

@EventBusSubscriber(Dist.CLIENT)
public class MeritocraftModScreens {
	@SubscribeEvent
	public static void clientLoad(RegisterMenuScreensEvent event) {
		event.register(MeritocraftModMenus.DIFFICULTY_IGUI.get(), DifficultyIGUIScreen::new);
		event.register(MeritocraftModMenus.GAMEMODE_SGUI.get(), GamemodeSGUIScreen::new);
		event.register(MeritocraftModMenus.VILLAGER_BANDIT_GUI.get(), VillagerBanditGUIScreen::new);
		event.register(MeritocraftModMenus.ADV_GUI.get(), AdvGUIScreen::new);
		event.register(MeritocraftModMenus.POTION_BOOK_GUI.get(), PotionBookGUIScreen::new);
	}

	public interface ScreenAccessor {
		void updateMenuState(int elementType, String name, Object elementState);
	}
}