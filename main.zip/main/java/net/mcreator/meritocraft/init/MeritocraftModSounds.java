/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.meritocraft.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

import net.mcreator.meritocraft.MeritocraftMod;

public class MeritocraftModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(Registries.SOUND_EVENT, MeritocraftMod.MODID);
	public static final DeferredHolder<SoundEvent, SoundEvent> ONE_PUNCH = REGISTRY.register("one_punch", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("meritocraft", "one_punch")));
	public static final DeferredHolder<SoundEvent, SoundEvent> JA_GEI = REGISTRY.register("ja_gei", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("meritocraft", "ja_gei")));
	public static final DeferredHolder<SoundEvent, SoundEvent> LOSUPONIA = REGISTRY.register("losuponia", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("meritocraft", "losuponia")));
	public static final DeferredHolder<SoundEvent, SoundEvent> PIGLIN_ARNAU = REGISTRY.register("piglin_arnau", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("meritocraft", "piglin_arnau")));
	public static final DeferredHolder<SoundEvent, SoundEvent> PIGLIN_CATALINA = REGISTRY.register("piglin_catalina", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("meritocraft", "piglin_catalina")));
	public static final DeferredHolder<SoundEvent, SoundEvent> PIGLIN_EMILIO = REGISTRY.register("piglin_emilio", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("meritocraft", "piglin_emilio")));
	public static final DeferredHolder<SoundEvent, SoundEvent> PIGLIN_LIBERTO = REGISTRY.register("piglin_liberto", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("meritocraft", "piglin_liberto")));
	public static final DeferredHolder<SoundEvent, SoundEvent> PIGLIN_MANUEL = REGISTRY.register("piglin_manuel", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("meritocraft", "piglin_manuel")));
	public static final DeferredHolder<SoundEvent, SoundEvent> PIGLIN_TEO = REGISTRY.register("piglin_teo", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("meritocraft", "piglin_teo")));
	public static final DeferredHolder<SoundEvent, SoundEvent> PIGLIN_TOMAS = REGISTRY.register("piglin_tomas", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("meritocraft", "piglin_tomas")));
	public static final DeferredHolder<SoundEvent, SoundEvent> PIGLIN_JAPANESE = REGISTRY.register("piglin_japanese", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("meritocraft", "piglin_japanese")));
	public static final DeferredHolder<SoundEvent, SoundEvent> PIGLIN_CHINESE = REGISTRY.register("piglin_chinese", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("meritocraft", "piglin_chinese")));
	public static final DeferredHolder<SoundEvent, SoundEvent> PIGLIN_NURIA = REGISTRY.register("piglin_nuria", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("meritocraft", "piglin_nuria")));
	public static final DeferredHolder<SoundEvent, SoundEvent> PIGLIN_LARISSA = REGISTRY.register("piglin_larissa", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("meritocraft", "piglin_larissa")));
	public static final DeferredHolder<SoundEvent, SoundEvent> NGGYU_MRPIXELMUSIC = REGISTRY.register("nggyu_mrpixelmusic", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("meritocraft", "nggyu_mrpixelmusic")));
	public static final DeferredHolder<SoundEvent, SoundEvent> PABLO01 = REGISTRY.register("pablo01", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("meritocraft", "pablo01")));
	public static final DeferredHolder<SoundEvent, SoundEvent> PABLO02 = REGISTRY.register("pablo02", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("meritocraft", "pablo02")));
	public static final DeferredHolder<SoundEvent, SoundEvent> PABLO03 = REGISTRY.register("pablo03", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("meritocraft", "pablo03")));
	public static final DeferredHolder<SoundEvent, SoundEvent> TLABAJA = REGISTRY.register("tlabaja", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("meritocraft", "tlabaja")));
	public static final DeferredHolder<SoundEvent, SoundEvent> CALAMARDO = REGISTRY.register("calamardo", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("meritocraft", "calamardo")));
}