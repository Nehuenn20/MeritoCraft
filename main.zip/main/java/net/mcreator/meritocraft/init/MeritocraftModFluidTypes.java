/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.meritocraft.init;

import net.neoforged.neoforge.registries.NeoForgeRegistries;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.fluids.FluidType;

import net.mcreator.meritocraft.fluid.types.BoiledWaterFluidType;
import net.mcreator.meritocraft.MeritocraftMod;

public class MeritocraftModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(NeoForgeRegistries.FLUID_TYPES, MeritocraftMod.MODID);
	public static final DeferredHolder<FluidType, FluidType> BOILED_WATER_TYPE = REGISTRY.register("boiled_water", () -> new BoiledWaterFluidType());
}