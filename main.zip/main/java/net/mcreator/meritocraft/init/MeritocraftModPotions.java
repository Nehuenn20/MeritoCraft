/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.meritocraft.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.core.registries.Registries;

import net.mcreator.meritocraft.MeritocraftMod;

public class MeritocraftModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(Registries.POTION, MeritocraftMod.MODID);
	public static final DeferredHolder<Potion, Potion> SALBUTAMOL = REGISTRY.register("salbutamol",
			() -> new Potion("salbutamol", new MobEffectInstance(MeritocraftModMobEffects.CLEAR_BREATHING, 1200, 0, true, true), new MobEffectInstance(MobEffects.SPEED, 600, 1, false, true)));
	public static final DeferredHolder<Potion, Potion> MELON_JUICE_BOTTLE = REGISTRY.register("melon_juice_bottle", () -> new Potion("melon_juice_bottle", new MobEffectInstance(MeritocraftModMobEffects.BLESSED, 2400, 0, false, true)));
}