/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.meritocraft.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.ItemBlockRenderTypes;

import net.mcreator.meritocraft.fluid.BoiledWaterFluid;
import net.mcreator.meritocraft.MeritocraftMod;

public class MeritocraftModFluids {
	public static final DeferredRegister<Fluid> REGISTRY = DeferredRegister.create(BuiltInRegistries.FLUID, MeritocraftMod.MODID);
	public static final DeferredHolder<Fluid, FlowingFluid> BOILED_WATER = REGISTRY.register("boiled_water", () -> new BoiledWaterFluid.Source());
	public static final DeferredHolder<Fluid, FlowingFluid> FLOWING_BOILED_WATER = REGISTRY.register("flowing_boiled_water", () -> new BoiledWaterFluid.Flowing());

	@EventBusSubscriber(Dist.CLIENT)
	public static class FluidsClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			ItemBlockRenderTypes.setRenderLayer(BOILED_WATER.get(), ChunkSectionLayer.TRANSLUCENT);
			ItemBlockRenderTypes.setRenderLayer(FLOWING_BOILED_WATER.get(), ChunkSectionLayer.TRANSLUCENT);
		}
	}
}