/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.meritocraft.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.meritocraft.client.model.Modelgrass;
import net.mcreator.meritocraft.client.model.ModelShovel;

@EventBusSubscriber(Dist.CLIENT)
public class MeritocraftModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(Modelgrass.LAYER_LOCATION, Modelgrass::createBodyLayer);
		event.registerLayerDefinition(ModelShovel.LAYER_LOCATION, ModelShovel::createBodyLayer);
	}
}