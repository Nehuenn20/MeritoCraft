/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.meritocraft.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.fluids.capability.wrappers.FluidBucketWrapper;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.meritocraft.item.inventory.PotionBookInventoryCapability;
import net.mcreator.meritocraft.item.inventory.DifficultyItemInventoryCapability;
import net.mcreator.meritocraft.item.inventory.AdvBookInventoryCapability;
import net.mcreator.meritocraft.item.*;
import net.mcreator.meritocraft.MeritocraftMod;

import java.util.function.Function;

@EventBusSubscriber
public class MeritocraftModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(MeritocraftMod.MODID);
	public static final DeferredItem<Item> CRAPEST_SPAWN_EGG;
	public static final DeferredItem<Item> BOILED_WATER_BUCKET;
	public static final DeferredItem<Item> EFEDRA_SEED;
	public static final DeferredItem<Item> EFEDRA;
	public static final DeferredItem<Item> EFEDRA_FRUIT;
	public static final DeferredItem<Item> EFEDRA_EXTRACT;
	public static final DeferredItem<Item> EFEDRA_STEM;
	public static final DeferredItem<Item> EFEDRA_STABILIZED_EXTRACT;
	public static final DeferredItem<Item> DIFFICULTY_ITEM;
	public static final DeferredItem<Item> HEROBRINE_SPAWN_EGG;
	public static final DeferredItem<Item> VILLAGER_BANDIT_SPAWN_EGG;
	public static final DeferredItem<Item> RAW_BREAD;
	public static final DeferredItem<Item> ANTI_ENDERMAN_HELMET;
	public static final DeferredItem<Item> GRASS_SPAWN_EGG;
	public static final DeferredItem<Item> CERDO_SPAWN_EGG;
	public static final DeferredItem<Item> CRAPER_SPAWN_EGG;
	public static final DeferredItem<Item> EMPTY_VACCINE;
	public static final DeferredItem<Item> VACCINE;
	public static final DeferredItem<Item> ADV_BOOK;
	public static final DeferredItem<Item> GOLEM_HEART;
	public static final DeferredItem<Item> WARDEN_HEART;
	public static final DeferredItem<Item> GUARDIAN_HEART;
	public static final DeferredItem<Item> SEA_HEART;
	public static final DeferredItem<Item> MAGIC_CATALYST;
	public static final DeferredItem<Item> SEA_SOUL;
	public static final DeferredItem<Item> SHOVEL_ENTITY_SPAWN_EGG;
	public static final DeferredItem<Item> GUNPOWDER_ON_A_STICK;
	public static final DeferredItem<Item> GLISTERING_MELON_BLOCK;
	public static final DeferredItem<Item> MELON_SLAB;
	public static final DeferredItem<Item> MELON_STAIR;
	public static final DeferredItem<Item> GLISTERING_MELON_STAIR;
	public static final DeferredItem<Item> GLISTERING_MELON_SLAB;
	public static final DeferredItem<Item> MELON_WALL;
	public static final DeferredItem<Item> GLISTERING_MELON_WALL;
	public static final DeferredItem<Item> POTION_BOOK;
	static {
		CRAPEST_SPAWN_EGG = register("crapest_spawn_egg", properties -> new SpawnEggItem(MeritocraftModEntities.CRAPEST.get(), properties));
		BOILED_WATER_BUCKET = register("boiled_water_bucket", BoiledWaterItem::new);
		EFEDRA_SEED = register("efedra_seed", EfedraSeedItem::new);
		EFEDRA = block(MeritocraftModBlocks.EFEDRA);
		EFEDRA_FRUIT = register("efedra_fruit", EfedraFruitItem::new);
		EFEDRA_EXTRACT = register("efedra_extract", EfedraExtractItem::new);
		EFEDRA_STEM = register("efedra_stem", EfedraStemItem::new);
		EFEDRA_STABILIZED_EXTRACT = register("efedra_stabilized_extract", EfedraStabilizedExtractItem::new);
		DIFFICULTY_ITEM = register("difficulty_item", DifficultyItemItem::new);
		HEROBRINE_SPAWN_EGG = register("herobrine_spawn_egg", properties -> new SpawnEggItem(MeritocraftModEntities.HEROBRINE.get(), properties));
		VILLAGER_BANDIT_SPAWN_EGG = register("villager_bandit_spawn_egg", properties -> new SpawnEggItem(MeritocraftModEntities.VILLAGER_BANDIT.get(), properties));
		RAW_BREAD = register("raw_bread", RawBreadItem::new);
		ANTI_ENDERMAN_HELMET = register("anti_enderman_helmet", AntiEndermanItem.Helmet::new);
		GRASS_SPAWN_EGG = register("grass_spawn_egg", properties -> new SpawnEggItem(MeritocraftModEntities.GRASS.get(), properties));
		CERDO_SPAWN_EGG = register("cerdo_spawn_egg", properties -> new SpawnEggItem(MeritocraftModEntities.CERDO.get(), properties));
		CRAPER_SPAWN_EGG = register("craper_spawn_egg", properties -> new SpawnEggItem(MeritocraftModEntities.CRAPER.get(), properties));
		EMPTY_VACCINE = register("empty_vaccine", EmptyVaccineItem::new);
		VACCINE = register("vaccine", VaccineItem::new);
		ADV_BOOK = register("adv_book", AdvBookItem::new);
		GOLEM_HEART = register("golem_heart", GolemHeartItem::new);
		WARDEN_HEART = register("warden_heart", WardenHeartItem::new);
		GUARDIAN_HEART = register("guardian_heart", GuardianHeartItem::new);
		SEA_HEART = register("sea_heart", SeaHeartItem::new);
		MAGIC_CATALYST = register("magic_catalyst", MagicCatalystItem::new);
		SEA_SOUL = register("sea_soul", SeaSoulItem::new);
		SHOVEL_ENTITY_SPAWN_EGG = register("shovel_entity_spawn_egg", properties -> new SpawnEggItem(MeritocraftModEntities.SHOVEL_ENTITY.get(), properties));
		GUNPOWDER_ON_A_STICK = register("gunpowder_on_a_stick", GunpowderOnAStickItem::new);
		GLISTERING_MELON_BLOCK = block(MeritocraftModBlocks.GLISTERING_MELON_BLOCK);
		MELON_SLAB = block(MeritocraftModBlocks.MELON_SLAB);
		MELON_STAIR = block(MeritocraftModBlocks.MELON_STAIR);
		GLISTERING_MELON_STAIR = block(MeritocraftModBlocks.GLISTERING_MELON_STAIR);
		GLISTERING_MELON_SLAB = block(MeritocraftModBlocks.GLISTERING_MELON_SLAB);
		MELON_WALL = block(MeritocraftModBlocks.MELON_WALL);
		GLISTERING_MELON_WALL = block(MeritocraftModBlocks.GLISTERING_MELON_WALL);
		POTION_BOOK = register("potion_book", PotionBookItem::new);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}

	@SubscribeEvent
	public static void registerCapabilities(RegisterCapabilitiesEvent event) {
		event.registerItem(Capabilities.ItemHandler.ITEM, (stack, context) -> new DifficultyItemInventoryCapability(stack), DIFFICULTY_ITEM.get());
		event.registerItem(Capabilities.ItemHandler.ITEM, (stack, context) -> new AdvBookInventoryCapability(stack), ADV_BOOK.get());
		event.registerItem(Capabilities.ItemHandler.ITEM, (stack, context) -> new PotionBookInventoryCapability(stack), POTION_BOOK.get());
		event.registerItem(Capabilities.FluidHandler.ITEM, (stack, context) -> new FluidBucketWrapper(stack), BOILED_WATER_BUCKET.get());
	}
}