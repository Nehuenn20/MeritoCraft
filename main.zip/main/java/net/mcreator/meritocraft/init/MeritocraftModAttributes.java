/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.meritocraft.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.entity.EntityAttributeModificationEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.entity.ai.attributes.RangedAttribute;
import net.minecraft.world.entity.ai.attributes.DefaultAttributes;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.meritocraft.MeritocraftMod;

import java.util.stream.Collectors;
import java.util.List;

@EventBusSubscriber
public class MeritocraftModAttributes {
	public static final DeferredRegister<Attribute> REGISTRY = DeferredRegister.create(BuiltInRegistries.ATTRIBUTE, MeritocraftMod.MODID);
	public static final DeferredHolder<Attribute, Attribute> SKELETON_ATTRIBUTE = REGISTRY.register("skeleton_attribute",
			() -> new RangedAttribute("attribute.meritocraft.skeleton_attribute", 0, 0, 15).setSyncable(true).setSentiment(Attribute.Sentiment.NEUTRAL));

	@SubscribeEvent
	public static void addAttributes(EntityAttributeModificationEvent event) {
		List.of(EntityType.SKELETON, EntityType.WITHER_SKELETON).stream().filter(DefaultAttributes::hasSupplier).map(entityType -> (EntityType<? extends LivingEntity>) entityType).collect(Collectors.toList())
				.forEach(entity -> event.add(entity, SKELETON_ATTRIBUTE));
	}
}