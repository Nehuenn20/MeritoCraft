package net.mcreator.meritocraft.potion;

import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.meritocraft.procedures.LeptospirosisTickConditionProcedure;
import net.mcreator.meritocraft.procedures.LeptospirosisStartProcedure;
import net.mcreator.meritocraft.procedures.LeptospirosisActiveTickProcedure;
import net.mcreator.meritocraft.MeritocraftMod;

public class LeptospirosisMobEffect extends MobEffect {
	public LeptospirosisMobEffect() {
		super(MobEffectCategory.HARMFUL, -3355444);
		this.addAttributeModifier(Attributes.MAX_ABSORPTION, ResourceLocation.fromNamespaceAndPath(MeritocraftMod.MODID, "effect.leptospirosis_0"), -1, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
	}

	@Override
	public void onEffectStarted(LivingEntity entity, int amplifier) {
		LeptospirosisStartProcedure.execute(entity);
	}

	@Override
	public boolean shouldApplyEffectTickThisTick(int duration, int amplifier) {
		return LeptospirosisTickConditionProcedure.execute(amplifier, duration);
	}

	@Override
	public boolean applyEffectTick(ServerLevel level, LivingEntity entity, int amplifier) {
		LeptospirosisActiveTickProcedure.execute(level, entity);
		return super.applyEffectTick(level, entity, amplifier);
	}
}