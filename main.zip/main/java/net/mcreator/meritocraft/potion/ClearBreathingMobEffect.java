package net.mcreator.meritocraft.potion;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.meritocraft.procedures.ClearBreathingStartedappliedProcedure;

public class ClearBreathingMobEffect extends MobEffect {
	public ClearBreathingMobEffect() {
		super(MobEffectCategory.BENEFICIAL, -5723992);
		this.withSoundOnAdded(BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("entity.wind_charge.wind_burst")));
	}

	@Override
	public void onEffectStarted(LivingEntity entity, int amplifier) {
		ClearBreathingStartedappliedProcedure.execute(entity);
	}
}