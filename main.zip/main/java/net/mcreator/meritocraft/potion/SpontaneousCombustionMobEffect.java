package net.mcreator.meritocraft.potion;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.particles.ParticleTypes;

import net.mcreator.meritocraft.procedures.SpontaneousCTickProcedure;
import net.mcreator.meritocraft.procedures.SpontaneousCStartProcedure;

public class SpontaneousCombustionMobEffect extends MobEffect {
	public SpontaneousCombustionMobEffect() {
		super(MobEffectCategory.HARMFUL, -3381760, mobEffectInstance -> ParticleTypes.SOUL_FIRE_FLAME);
		this.withSoundOnAdded(BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("block.fire.ambient")));
	}

	@Override
	public void onEffectStarted(LivingEntity entity, int amplifier) {
		SpontaneousCStartProcedure.execute(entity);
	}

	@Override
	public boolean shouldApplyEffectTickThisTick(int duration, int amplifier) {
		return true;
	}

	@Override
	public boolean applyEffectTick(ServerLevel level, LivingEntity entity, int amplifier) {
		SpontaneousCTickProcedure.execute(entity);
		return super.applyEffectTick(level, entity, amplifier);
	}
}