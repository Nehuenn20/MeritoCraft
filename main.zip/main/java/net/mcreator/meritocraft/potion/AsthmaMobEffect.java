package net.mcreator.meritocraft.potion;

import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.meritocraft.procedures.AsthmaTickProcedure;
import net.mcreator.meritocraft.procedures.AsthmaTickConditionProcedure;
import net.mcreator.meritocraft.procedures.AsthmaStartsProcedure;
import net.mcreator.meritocraft.procedures.AsthmaReactivationProcedure;
import net.mcreator.meritocraft.procedures.AsthmaEndsProcedure;
import net.mcreator.meritocraft.MeritocraftMod;

public class AsthmaMobEffect extends MobEffect {
	public AsthmaMobEffect() {
		super(MobEffectCategory.HARMFUL, -6684724);
		this.addAttributeModifier(Attributes.OXYGEN_BONUS, ResourceLocation.fromNamespaceAndPath(MeritocraftMod.MODID, "effect.asthma_0"), -0.25, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
	}

	@Override
	public void onEffectStarted(LivingEntity entity, int amplifier) {
		AsthmaStartsProcedure.execute(entity);
	}

	@Override
	public boolean shouldApplyEffectTickThisTick(int duration, int amplifier) {
		return AsthmaTickConditionProcedure.execute(amplifier, duration);
	}

	@Override
	public boolean applyEffectTick(ServerLevel level, LivingEntity entity, int amplifier) {
		AsthmaTickProcedure.execute(level, entity);
		return super.applyEffectTick(level, entity, amplifier);
	}

	@Override
	public void onMobHurt(ServerLevel level, LivingEntity entity, int amplifier, DamageSource damagesource, float damage) {
		AsthmaReactivationProcedure.execute(entity);
	}

	@Override
	public void onMobRemoved(ServerLevel level, LivingEntity entity, int amplifier, Entity.RemovalReason reason) {
		if (reason == Entity.RemovalReason.KILLED) {
			AsthmaEndsProcedure.execute(level, entity.getX(), entity.getY(), entity.getZ(), entity);
		}
	}
}