package net.mcreator.meritocraft.potion;

import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.meritocraft.MeritocraftMod;

public class BlessedMobEffect extends MobEffect {
	public BlessedMobEffect() {
		super(MobEffectCategory.BENEFICIAL, -52429);
		this.withSoundOnAdded(BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("block.beacon.power_select")));
		this.addAttributeModifier(Attributes.LUCK, ResourceLocation.fromNamespaceAndPath(MeritocraftMod.MODID, "effect.blessed_0"), 1, AttributeModifier.Operation.ADD_VALUE);
	}
}