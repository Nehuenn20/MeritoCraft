package net.mcreator.meritocraft.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class GolemHeartItem extends Item {
	public GolemHeartItem(Item.Properties properties) {
		super(properties.rarity(Rarity.RARE).fireResistant());
	}
}