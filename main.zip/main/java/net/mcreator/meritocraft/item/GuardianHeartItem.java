package net.mcreator.meritocraft.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class GuardianHeartItem extends Item {
	public GuardianHeartItem(Item.Properties properties) {
		super(properties.rarity(Rarity.RARE).fireResistant());
	}
}