package net.mcreator.meritocraft.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class SeaSoulItem extends Item {
	public SeaSoulItem(Item.Properties properties) {
		super(properties.rarity(Rarity.UNCOMMON));
	}
}