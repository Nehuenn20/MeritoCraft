package net.mcreator.meritocraft.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;

import net.mcreator.meritocraft.procedures.CraperGunpowderStickUseProcedure;

public class GunpowderOnAStickItem extends Item {
	public GunpowderOnAStickItem(Item.Properties properties) {
		super(properties.durability(25));
	}

	@Override
	public InteractionResult use(Level world, Player entity, InteractionHand hand) {
		InteractionResult ar = super.use(world, entity, hand);
		CraperGunpowderStickUseProcedure.execute(world, entity, entity.getItemInHand(hand));
		return ar;
	}
}