package net.mcreator.meritocraft.item.inventory;

import net.neoforged.neoforge.items.ComponentItemHandler;
import net.neoforged.neoforge.event.entity.item.ItemTossEvent;
import net.neoforged.neoforge.common.MutableDataComponentHolder;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.core.component.DataComponents;

import net.mcreator.meritocraft.world.inventory.AdvGUIMenu;
import net.mcreator.meritocraft.init.MeritocraftModItems;

import javax.annotation.Nonnull;

@EventBusSubscriber
public class AdvBookInventoryCapability extends ComponentItemHandler {
	@SubscribeEvent
	public static void onItemDropped(ItemTossEvent event) {
		if (event.getEntity().getItem().getItem() == MeritocraftModItems.ADV_BOOK.get()) {
			Player player = event.getPlayer();
			if (player.containerMenu instanceof AdvGUIMenu)
				player.closeContainer();
		}
	}

	public AdvBookInventoryCapability(MutableDataComponentHolder parent) {
		super(parent, DataComponents.CONTAINER, 0);
	}

	@Override
	public boolean isItemValid(int slot, @Nonnull ItemStack stack) {
		return stack.getItem() != MeritocraftModItems.ADV_BOOK.get();
	}

	@Override
	public ItemStack getStackInSlot(int slot) {
		return super.getStackInSlot(slot).copy();
	}
}