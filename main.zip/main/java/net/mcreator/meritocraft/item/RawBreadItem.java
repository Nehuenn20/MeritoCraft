package net.mcreator.meritocraft.item;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.entity.player.Player;

import net.mcreator.meritocraft.procedures.RawbreadCraftedProcedure;

public class RawBreadItem extends Item {
	public RawBreadItem(Item.Properties properties) {
		super(properties.food((new FoodProperties.Builder()).nutrition(1).saturationModifier(0.6f).build()));
	}

	@Override
	public void onCraftedBy(ItemStack itemstack, Player entity) {
		super.onCraftedBy(itemstack, entity);
		RawbreadCraftedProcedure.execute(entity);
	}
}