package net.mcreator.meritocraft.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class SeaHeartItem extends Item {
	public SeaHeartItem(Item.Properties properties) {
		super(properties.rarity(Rarity.RARE).fireResistant());
	}
}