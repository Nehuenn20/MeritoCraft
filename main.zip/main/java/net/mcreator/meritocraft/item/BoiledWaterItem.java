package net.mcreator.meritocraft.item;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import net.mcreator.meritocraft.init.MeritocraftModFluids;

public class BoiledWaterItem extends BucketItem {
	public BoiledWaterItem(Item.Properties properties) {
		super(MeritocraftModFluids.BOILED_WATER.get(), properties.craftRemainder(Items.BUCKET).stacksTo(1)

		);
	}
}