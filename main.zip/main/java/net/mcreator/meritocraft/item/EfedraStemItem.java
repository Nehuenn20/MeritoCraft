package net.mcreator.meritocraft.item;

import net.minecraft.world.item.Item;

public class EfedraStemItem extends Item {
	public EfedraStemItem(Item.Properties properties) {
		super(properties);
	}
}