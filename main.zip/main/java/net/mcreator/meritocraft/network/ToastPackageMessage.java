package net.mcreator.meritocraft.network;

import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.chat.Component;
import net.minecraft.network.RegistryFriendlyByteBuf;

import net.mcreator.meritocraft.procedures.ToastPackageClientProcProcedure;
import net.mcreator.meritocraft.MeritocraftMod;

@EventBusSubscriber
public record ToastPackageMessage(String extradata) implements CustomPacketPayload {
	public static final Type<ToastPackageMessage> TYPE = new Type<>(ResourceLocation.fromNamespaceAndPath(MeritocraftMod.MODID, "toast_package"));
	public static final StreamCodec<RegistryFriendlyByteBuf, ToastPackageMessage> STREAM_CODEC = StreamCodec.of((RegistryFriendlyByteBuf buffer, ToastPackageMessage message) -> {
		buffer.writeUtf(message.extradata);
	}, (RegistryFriendlyByteBuf buffer) -> new ToastPackageMessage(buffer.readUtf()));

	@Override
	public Type<ToastPackageMessage> type() {
		return TYPE;
	}

	public static void handleData(final ToastPackageMessage message, final IPayloadContext context) {
		if (context.flow() == PacketFlow.CLIENTBOUND) {
			context.enqueueWork(() -> {
				Player entity = context.player();
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				String inboundString = message.extradata;

				ToastPackageClientProcProcedure.execute(inboundString);
			}).exceptionally(e -> {
				context.connection().disconnect(Component.literal(e.getMessage()));
				return null;
			});
		}
	}

	@SubscribeEvent
	public static void registerMessage(FMLCommonSetupEvent event) {
		MeritocraftMod.addNetworkMessage(ToastPackageMessage.TYPE, ToastPackageMessage.STREAM_CODEC, ToastPackageMessage::handleData);
	}
}