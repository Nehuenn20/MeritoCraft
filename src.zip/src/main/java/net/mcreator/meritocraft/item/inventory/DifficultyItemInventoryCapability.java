package net.mcreator.meritocraft.item.inventory;

import net.neoforged.neoforge.transfer.item.ItemResource;
import net.neoforged.neoforge.transfer.item.ItemAccessItemHandler;
import net.neoforged.neoforge.transfer.access.ItemAccess;
import net.neoforged.neoforge.event.entity.item.ItemTossEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.entity.player.Player;
import net.minecraft.core.component.DataComponents;

import net.mcreator.meritocraft.world.inventory.DifficultyIGUIMenu;
import net.mcreator.meritocraft.init.MeritocraftModItems;

@EventBusSubscriber
public class DifficultyItemInventoryCapability extends ItemAccessItemHandler {
	@SubscribeEvent
	public static void onItemDropped(ItemTossEvent event) {
		if (event.getEntity().getItem().getItem() == MeritocraftModItems.DIFFICULTY_ITEM.get()) {
			Player player = event.getPlayer();
			if (player.containerMenu instanceof DifficultyIGUIMenu)
				player.closeContainer();
		}
	}

	public DifficultyItemInventoryCapability(ItemAccess access) {
		super(access, DataComponents.CONTAINER, 0);
	}

	@Override
	public boolean isValid(int index, ItemResource resource) {
		return super.isValid(index, resource) && resource.getItem() != MeritocraftModItems.DIFFICULTY_ITEM.get();
	}
}