package net.mcreator.meritocraft.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;

import net.mcreator.meritocraft.procedures.StabilizedEnderPearlRightclickedProcedure;

public class StabilizedEnderPearlItem extends Item {
	public StabilizedEnderPearlItem(Item.Properties properties) {
		super(properties.rarity(Rarity.UNCOMMON).stacksTo(16));
	}

	@Override
	public InteractionResult use(Level world, Player entity, InteractionHand hand) {
		InteractionResult ar = super.use(world, entity, hand);
		StabilizedEnderPearlRightclickedProcedure.execute(entity, entity.getItemInHand(hand));
		return ar;
	}
}