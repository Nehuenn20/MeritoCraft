package net.mcreator.meritocraft.client.gui;

import net.neoforged.neoforge.client.network.ClientPacketDistributor;
import net.neoforged.neoforge.client.gui.widget.ExtendedSlider;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.Identifier;
import net.minecraft.network.chat.Component;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import net.mcreator.meritocraft.world.inventory.DifficultyIGUIMenu;
import net.mcreator.meritocraft.procedures.DifficultyIPeacefulProcedure;
import net.mcreator.meritocraft.procedures.DifficultyINormalProcedure;
import net.mcreator.meritocraft.procedures.DifficultyIHardProcedure;
import net.mcreator.meritocraft.procedures.DifficultyIEasyProcedure;
import net.mcreator.meritocraft.network.DifficultyIGUISliderMessage;
import net.mcreator.meritocraft.network.DifficultyIGUIButtonMessage;
import net.mcreator.meritocraft.init.MeritocraftModScreens;

import com.mojang.blaze3d.platform.InputConstants;

public class DifficultyIGUIScreen extends AbstractContainerScreen<DifficultyIGUIMenu> implements MeritocraftModScreens.ScreenAccessor {
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	private boolean menuStateUpdateActive = false;
	private Button button_879;
	private ExtendedSlider DIFICULTAD;
	private static final Identifier BACKGROUND = Identifier.parse("meritocraft:textures/screens/difficulty_igui.png");

	public DifficultyIGUIScreen(DifficultyIGUIMenu container, Inventory inventory, Component text) {
		super(container, inventory, text, 240, 90);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
	}

	@Override
	public void updateMenuState(int elementType, String name, Object elementState) {
		menuStateUpdateActive = true;
		if (elementType == 2 && elementState instanceof Number n) {
			if (name.equals("DIFICULTAD"))
				DIFICULTAD.setValue(n.doubleValue());
		}
		menuStateUpdateActive = false;
	}

	@Override
	public boolean isPauseScreen() {
		return true;
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor guiGraphics, int mouseX, int mouseY, float partialTicks) {
		super.extractRenderState(guiGraphics, mouseX, mouseY, partialTicks);
	}

	@Override
	public void extractBackground(GuiGraphicsExtractor guiGraphics, int mouseX, int mouseY, float partialTicks) {
		super.extractBackground(guiGraphics, mouseX, mouseY, partialTicks);
		guiGraphics.blit(RenderPipelines.GUI_TEXTURED, BACKGROUND, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
	}

	@Override
	public boolean keyPressed(KeyEvent event) {
		int key = InputConstants.getKey(event).getValue();
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(event);
	}

	@Override
	protected void extractLabels(GuiGraphicsExtractor guiGraphics, int mouseX, int mouseY) {
		guiGraphics.text(this.font, Component.translatable("gui.meritocraft.difficulty_igui.label_dificultad"), 91, 5, -16751002, false);
		if (DifficultyIEasyProcedure.execute(entity))
			guiGraphics.text(this.font, Component.translatable("gui.meritocraft.difficulty_igui.label_empty"), 105, 46, -10040320, false);
		if (DifficultyINormalProcedure.execute(entity))
			guiGraphics.text(this.font, Component.translatable("gui.meritocraft.difficulty_igui.label_normal"), 102, 46, -6711040, false);
		if (DifficultyIHardProcedure.execute(entity))
			guiGraphics.text(this.font, Component.translatable("gui.meritocraft.difficulty_igui.label_dificil"), 100, 46, -6750208, false);
		if (DifficultyIPeacefulProcedure.execute(entity))
			guiGraphics.text(this.font, Component.translatable("gui.meritocraft.difficulty_igui.label_pacifico"), 97, 46, -16777216, false);
	}

	@Override
	public void init() {
		super.init();
		button_879 = Button.builder(Component.translatable("gui.meritocraft.difficulty_igui.button_879"), e -> {
			int x = DifficultyIGUIScreen.this.x;
			int y = DifficultyIGUIScreen.this.y;
			if (true) {
				ClientPacketDistributor.sendToServer(new DifficultyIGUIButtonMessage(0, x, y, z));
				DifficultyIGUIButtonMessage.handleButtonAction(entity, 0, x, y, z);
			}
		}).bounds(this.leftPos + 86, this.topPos + 61, 65, 20).build();
		this.addRenderableWidget(button_879);
		DIFICULTAD = new ExtendedSlider(this.leftPos + 28, this.topPos + 23, 182, 20, Component.translatable("gui.meritocraft.difficulty_igui.DIFICULTAD_prefix"), Component.translatable("gui.meritocraft.difficulty_igui.DIFICULTAD_suffix"), 0, 3, 0,
				1, 0, true) {
			@Override
			protected void applyValue() {
				if (!menuStateUpdateActive)
					menu.sendMenuStateUpdate(entity, 2, "DIFICULTAD", this.getValue(), false);
				ClientPacketDistributor.sendToServer(new DifficultyIGUISliderMessage(0, x, y, z, this.getValue()));
				DifficultyIGUISliderMessage.handleSliderAction(entity, 0, x, y, z, this.getValue());
			}
		};
		this.addRenderableWidget(DIFICULTAD);
		if (!menuStateUpdateActive)
			menu.sendMenuStateUpdate(entity, 2, "DIFICULTAD", DIFICULTAD.getValue(), false);
	}
}