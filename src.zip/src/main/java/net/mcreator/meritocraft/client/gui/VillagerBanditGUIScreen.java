package net.mcreator.meritocraft.client.gui;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.Identifier;
import net.minecraft.network.chat.Component;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import net.mcreator.meritocraft.world.inventory.VillagerBanditGUIMenu;
import net.mcreator.meritocraft.procedures.VBEmeraldSpriteProcedure;
import net.mcreator.meritocraft.init.MeritocraftModScreens;

import com.mojang.blaze3d.platform.InputConstants;

public class VillagerBanditGUIScreen extends AbstractContainerScreen<VillagerBanditGUIMenu> implements MeritocraftModScreens.ScreenAccessor {
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	private boolean menuStateUpdateActive = false;
	private static final Identifier BACKGROUND = Identifier.parse("meritocraft:textures/screens/villager_bandit_gui.png");
	private static final Identifier IMAGE_0 = Identifier.parse("meritocraft:textures/screens/x64.png");
	private static final Identifier IMAGE_1 = Identifier.parse("meritocraft:textures/screens/trade_arrow.png");
	private static final Identifier SPRITE_0 = Identifier.parse("meritocraft:textures/screens/emerald_slot.png");

	public VillagerBanditGUIScreen(VillagerBanditGUIMenu container, Inventory inventory, Component text) {
		super(container, inventory, text, 176, 166);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
	}

	@Override
	public void updateMenuState(int elementType, String name, Object elementState) {
		menuStateUpdateActive = true;
		menuStateUpdateActive = false;
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor guiGraphics, int mouseX, int mouseY, float partialTicks) {
		super.extractRenderState(guiGraphics, mouseX, mouseY, partialTicks);
	}

	@Override
	public void extractBackground(GuiGraphicsExtractor guiGraphics, int mouseX, int mouseY, float partialTicks) {
		super.extractBackground(guiGraphics, mouseX, mouseY, partialTicks);
		guiGraphics.blit(RenderPipelines.GUI_TEXTURED, BACKGROUND, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
		if (VBEmeraldSpriteProcedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, IMAGE_0, this.leftPos + 55, this.topPos + 49, 0, 0, 7, 5, 7, 5);
		}
		guiGraphics.blit(RenderPipelines.GUI_TEXTURED, IMAGE_1, this.leftPos + 77, this.topPos + 39, 0, 0, 22, 15, 22, 15);
		if (VBEmeraldSpriteProcedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, SPRITE_0, this.leftPos + 45, this.topPos + 38, 0, 0, 16, 16, 16, 16);
		}
	}

	@Override
	public boolean keyPressed(KeyEvent event) {
		int key = InputConstants.getKey(event).getValue();
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(event);
	}

	@Override
	protected void extractLabels(GuiGraphicsExtractor guiGraphics, int mouseX, int mouseY) {
	}

	@Override
	public void init() {
		super.init();
	}
}