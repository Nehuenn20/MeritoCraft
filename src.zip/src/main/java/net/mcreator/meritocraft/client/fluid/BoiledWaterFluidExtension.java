package net.mcreator.meritocraft.client.fluid;

import net.neoforged.neoforge.client.fluid.FluidTintSource;
import net.neoforged.neoforge.client.extensions.common.RegisterClientExtensionsEvent;
import net.neoforged.neoforge.client.extensions.common.IClientFluidTypeExtensions;
import net.neoforged.neoforge.client.event.RegisterFluidModelsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.resources.Identifier;
import net.minecraft.core.BlockPos;
import net.minecraft.client.resources.model.sprite.Material;
import net.minecraft.client.renderer.block.FluidModel;
import net.minecraft.client.renderer.block.BlockAndTintGetter;
import net.minecraft.client.renderer.BiomeColors;
import net.minecraft.client.Minecraft;

import net.mcreator.meritocraft.init.MeritocraftModFluids;
import net.mcreator.meritocraft.init.MeritocraftModFluidTypes;

@EventBusSubscriber(Dist.CLIENT)
public class BoiledWaterFluidExtension {
	@SubscribeEvent
	public static void registerRegisterFluidModels(RegisterFluidModelsEvent event) {
		event.register(new FluidModel.Unbaked(new Material(Identifier.parse("minecraft:block/water_still")), new Material(Identifier.parse("minecraft:block/water_flow")), null, new FluidTintSource() {
			@Override
			public int color(FluidState state) {
				return -13083194;
			}

			@Override
			public int colorInWorld(FluidState state, BlockState blockState, BlockAndTintGetter world, BlockPos pos) {
				return BiomeColors.getAverageWaterColor(world, pos) | 0xFF000000;
			}
		}), MeritocraftModFluids.BOILED_WATER, MeritocraftModFluids.FLOWING_BOILED_WATER);
	}

	@SubscribeEvent
	public static void registerFluidTypeExtensions(RegisterClientExtensionsEvent event) {
		event.registerFluidType(new IClientFluidTypeExtensions() {
			private static final Identifier RENDER_OVERLAY_TEXTURE = Identifier.parse("meritocraft:textures/water_overlay.png");

			@Override
			public Identifier getRenderOverlayTexture(Minecraft minecraft) {
				return RENDER_OVERLAY_TEXTURE;
			}
		}, MeritocraftModFluidTypes.BOILED_WATER_TYPE);
	}
}