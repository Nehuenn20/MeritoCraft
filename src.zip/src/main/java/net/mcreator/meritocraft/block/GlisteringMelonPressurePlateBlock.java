package net.mcreator.meritocraft.block;

import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.properties.BlockSetType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.PressurePlateBlock;

public class GlisteringMelonPressurePlateBlock extends PressurePlateBlock {
	public GlisteringMelonPressurePlateBlock(BlockBehaviour.Properties properties) {
		super(BlockSetType.OAK, properties.sound(SoundType.WOOD).strength(1.2f, 10f).lightLevel(blockstate -> 7).speedFactor(1.2f).jumpFactor(1.2f).noOcclusion().pushReaction(PushReaction.DESTROY).isRedstoneConductor((bs, br, bp) -> false)
				.instrument(NoteBlockInstrument.BASS).forceSolidOn());
	}
}