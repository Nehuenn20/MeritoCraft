/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.meritocraft.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.meritocraft.block.*;
import net.mcreator.meritocraft.MeritocraftMod;

import java.util.function.Function;

public class MeritocraftModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(MeritocraftMod.MODID);
	public static final DeferredBlock<Block> BOILED_WATER;
	public static final DeferredBlock<Block> EFEDRA_SAPPLING;
	public static final DeferredBlock<Block> EFEDRA;
	public static final DeferredBlock<Block> GLISTERING_MELON_BLOCK;
	public static final DeferredBlock<Block> MELON_SLAB;
	public static final DeferredBlock<Block> MELON_STAIR;
	public static final DeferredBlock<Block> GLISTERING_MELON_STAIR;
	public static final DeferredBlock<Block> GLISTERING_MELON_SLAB;
	public static final DeferredBlock<Block> MELON_WALL;
	public static final DeferredBlock<Block> GLISTERING_MELON_WALL;
	public static final DeferredBlock<Block> GLISTERING_MELON_FENCE;
	public static final DeferredBlock<Block> GLISTERING_MELON_FENCE_GATE;
	public static final DeferredBlock<Block> GLISTERING_MELON_TRAP_DOOR;
	public static final DeferredBlock<Block> GLISTERING_MELON_PRESSURE_PLATE;
	public static final DeferredBlock<Block> GLISTERING_MELON_BUTTON;
	public static final DeferredBlock<Block> MELON_FENCE;
	public static final DeferredBlock<Block> MELON_FENCE_GATE;
	public static final DeferredBlock<Block> MELON_TRAP_DOOR;
	public static final DeferredBlock<Block> MELON_PRESSURE_PLATE;
	public static final DeferredBlock<Block> MELON_BUTTON;
	static {
		BOILED_WATER = register("boiled_water", BoiledWaterBlock::new);
		EFEDRA_SAPPLING = register("efedra_sappling", EfedraSapplingBlock::new);
		EFEDRA = register("efedra", EfedraBlock::new);
		GLISTERING_MELON_BLOCK = register("glistering_melon_block", GlisteringMelonBlockBlock::new);
		MELON_SLAB = register("melon_slab", MelonSlabBlock::new);
		MELON_STAIR = register("melon_stair", MelonStairBlock::new);
		GLISTERING_MELON_STAIR = register("glistering_melon_stair", GlisteringMelonStairBlock::new);
		GLISTERING_MELON_SLAB = register("glistering_melon_slab", GlisteringMelonSlabBlock::new);
		MELON_WALL = register("melon_wall", MelonWallBlock::new);
		GLISTERING_MELON_WALL = register("glistering_melon_wall", GlisteringMelonWallBlock::new);
		GLISTERING_MELON_FENCE = register("glistering_melon_fence", GlisteringMelonFenceBlock::new);
		GLISTERING_MELON_FENCE_GATE = register("glistering_melon_fence_gate", GlisteringMelonFenceGateBlock::new);
		GLISTERING_MELON_TRAP_DOOR = register("glistering_melon_trap_door", GlisteringMelonTrapDoorBlock::new);
		GLISTERING_MELON_PRESSURE_PLATE = register("glistering_melon_pressure_plate", GlisteringMelonPressurePlateBlock::new);
		GLISTERING_MELON_BUTTON = register("glistering_melon_button", GlisteringMelonButtonBlock::new);
		MELON_FENCE = register("melon_fence", MelonFenceBlock::new);
		MELON_FENCE_GATE = register("melon_fence_gate", MelonFenceGateBlock::new);
		MELON_TRAP_DOOR = register("melon_trap_door", MelonTrapDoorBlock::new);
		MELON_PRESSURE_PLATE = register("melon_pressure_plate", MelonPressurePlateBlock::new);
		MELON_BUTTON = register("melon_button", MelonButtonBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier);
	}
}