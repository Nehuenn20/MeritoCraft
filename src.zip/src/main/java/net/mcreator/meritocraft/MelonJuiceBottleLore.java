package net.mcreator.meritocraft;

import net.neoforged.neoforge.event.entity.player.ItemTooltipEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

@EventBusSubscriber(modid = "meritocraft", value = Dist.CLIENT)
public class MelonJuiceBottleLore {

	@SubscribeEvent
	public static void onItemTooltip(ItemTooltipEvent event) {
		if (event == null || event.getItemStack() == null)
			return;

		net.minecraft.world.item.ItemStack stack = event.getItemStack();
		
		// 1. Verificamos el componente de pociones
		if (stack.has(net.minecraft.core.component.DataComponents.POTION_CONTENTS)) {
			net.minecraft.world.item.alchemy.PotionContents contents = stack.get(net.minecraft.core.component.DataComponents.POTION_CONTENTS);
			
			if (contents != null && contents.potion() != null && contents.potion().isPresent()) {
				String potionName = "";
				
				java.util.Optional<net.minecraft.resources.ResourceKey<net.minecraft.world.item.alchemy.Potion>> optionalKey = contents.potion().get().unwrapKey();
				if (optionalKey != null && optionalKey.isPresent()) {
					potionName = optionalKey.get().identifier().toString();
				}
				
				// 2. Comparamos con tus registros de jugos de sandía
				if (potionName.equals("meritocraft:melon_juice_bottle") || potionName.equals("meritocraft:melon_juice_bottle_long")) {
					
					// TRUCO SEGURO PARA LA 2026.2: Alteramos el componente directamente en el ItemStack al vuelo.
					// Al mutar el ItemStack individual, el juego lo respeta tanto en el cliente como en el servidor de pruebas.
					if (stack.get(net.minecraft.core.component.DataComponents.MAX_STACK_SIZE) == null || stack.get(net.minecraft.core.component.DataComponents.MAX_STACK_SIZE) != 16) {
						stack.set(net.minecraft.core.component.DataComponents.MAX_STACK_SIZE, 16); // Cambia 16 por el stack que quieras (máximo 64)
					}

					net.minecraft.network.chat.Component loreText = net.minecraft.network.chat.Component.translatable("item.minecraft.potion.effect.melon_juice_bottle.lore");
					event.getToolTip().add(loreText);
				}
			}
		}
	}
}
