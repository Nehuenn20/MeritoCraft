package net.mcreator.meritocraft;

import net.neoforged.neoforge.event.server.ServerStartingEvent;
import net.neoforged.neoforge.event.entity.player.ItemTooltipEvent;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

@EventBusSubscriber
public class MelonJuiceBottleLore {
	public MelonJuiceBottleLore() {
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		new MelonJuiceBottleLore();
	}

	@SubscribeEvent
	public static void clientLoad(FMLClientSetupEvent event) {
	}

	@EventBusSubscriber
	private static class MelonJuiceBottleLoreForgeBusEvents {
		@SubscribeEvent
		public static void serverLoad(ServerStartingEvent event) {
		}

		@SubscribeEvent
		public static void onItemTooltip(ItemTooltipEvent event) {
			net.minecraft.world.item.ItemStack stack = event.getItemStack();
			
			// Detecta cualquier tipo de botella de poción (normal, splash o lingering)
			if (stack.has(net.minecraft.core.component.DataComponents.POTION_CONTENTS)) {
				net.minecraft.world.item.alchemy.PotionContents contents = stack.get(net.minecraft.core.component.DataComponents.POTION_CONTENTS);
				
				if (contents != null && contents.potion().isPresent()) {
					String potionName = contents.potion().get().unwrapKey().map(key -> key.location().toString()).orElse("");
					
					// Compara con los nombres de tus registros de poción
					if (potionName.equals("meritocraft:melon_juice_bottle") || potionName.equals("meritocraft:melon_juice_bottle_long")) {
						
						// Crea el componente traducible de texto plano (sin color ni itálica manual)
						net.minecraft.network.chat.MutableComponent loreText = net.minecraft.network.chat.Component.translatable("item.minecraft.potion.effect.melon_juice_bottle.lore");

						event.getToolTip().add(loreText);
					}
				}
			}
		}
	}
}
