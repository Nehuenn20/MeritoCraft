package net.mcreator.meritocraft.potion;

import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.resources.Identifier;

import net.mcreator.meritocraft.MeritocraftMod;

public class HemorrhageMobEffect extends MobEffect {
	public HemorrhageMobEffect() {
		super(MobEffectCategory.HARMFUL, -3407872);
		this.addAttributeModifier(Attributes.MAX_HEALTH, Identifier.fromNamespaceAndPath(MeritocraftMod.MODID, "effect.hemorrhage_0"), -2, AttributeModifier.Operation.ADD_VALUE);
	}
}