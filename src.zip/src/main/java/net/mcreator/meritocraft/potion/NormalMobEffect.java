package net.mcreator.meritocraft.potion;

import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.resources.Identifier;

import net.mcreator.meritocraft.MeritocraftMod;

public class NormalMobEffect extends MobEffect {
	public NormalMobEffect() {
		super(MobEffectCategory.HARMFUL, -1);
		this.addAttributeModifier(Attributes.ATTACK_DAMAGE, Identifier.fromNamespaceAndPath(MeritocraftMod.MODID, "effect.normal_0"), -0.2, AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
		this.addAttributeModifier(Attributes.ATTACK_SPEED, Identifier.fromNamespaceAndPath(MeritocraftMod.MODID, "effect.normal_1"), -0.1, AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
		this.addAttributeModifier(Attributes.ARMOR, Identifier.fromNamespaceAndPath(MeritocraftMod.MODID, "effect.normal_2"), -0.2, AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
		this.addAttributeModifier(Attributes.MOVEMENT_SPEED, Identifier.fromNamespaceAndPath(MeritocraftMod.MODID, "effect.normal_3"), -0.1, AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
		this.addAttributeModifier(Attributes.BLOCK_BREAK_SPEED, Identifier.fromNamespaceAndPath(MeritocraftMod.MODID, "effect.normal_4"), -0.2, AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
		this.addAttributeModifier(Attributes.FALL_DAMAGE_MULTIPLIER, Identifier.fromNamespaceAndPath(MeritocraftMod.MODID, "effect.normal_5"), 0.3, AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
		this.addAttributeModifier(Attributes.BURNING_TIME, Identifier.fromNamespaceAndPath(MeritocraftMod.MODID, "effect.normal_6"), 0.2, AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
	}
}