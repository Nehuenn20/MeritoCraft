package net.mcreator.meritocraft.procedures;

import net.neoforged.neoforge.event.ModifyDefaultComponentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.Items;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Component;
import net.minecraft.core.component.DataComponents;

import net.mcreator.meritocraft.init.MeritocraftModPotions;

import javax.annotation.Nullable;

@EventBusSubscriber
public class MelonJuiceBottleStackableProcedure {
	@SubscribeEvent
	public static void onComponentModification(ModifyDefaultComponentsEvent event) {
		execute(event);
	}

	public static void execute() {
		execute(null);
	}

	private static void execute(@Nullable Event event) {
		MutableComponent lore = Component.empty();
		if (event instanceof ModifyDefaultComponentsEvent _modComponent1) {
			final int _value = 16;
			_modComponent1.modify((PotionContents.createItemStack(Items.POTION, MeritocraftModPotions.MELON_JUICE_BOTTLE)).getItem(), builder -> builder.set(DataComponents.MAX_STACK_SIZE, _value));
		}
		if (event instanceof ModifyDefaultComponentsEvent _modComponent3) {
			final int _value = 16;
			_modComponent3.modify((PotionContents.createItemStack(Items.SPLASH_POTION, MeritocraftModPotions.MELON_JUICE_BOTTLE)).getItem(), builder -> builder.set(DataComponents.MAX_STACK_SIZE, _value));
		}
		if (event instanceof ModifyDefaultComponentsEvent _modComponent5) {
			final int _value = 16;
			_modComponent5.modify((PotionContents.createItemStack(Items.LINGERING_POTION, MeritocraftModPotions.MELON_JUICE_BOTTLE)).getItem(), builder -> builder.set(DataComponents.MAX_STACK_SIZE, _value));
		}
		if (event instanceof ModifyDefaultComponentsEvent _modComponent7) {
			final int _value = 16;
			_modComponent7.modify((PotionContents.createItemStack(Items.POTION, MeritocraftModPotions.MELON_JUICE_BOTTLE_LONG)).getItem(), builder -> builder.set(DataComponents.MAX_STACK_SIZE, _value));
		}
		if (event instanceof ModifyDefaultComponentsEvent _modComponent9) {
			final int _value = 16;
			_modComponent9.modify((PotionContents.createItemStack(Items.SPLASH_POTION, MeritocraftModPotions.MELON_JUICE_BOTTLE_LONG)).getItem(), builder -> builder.set(DataComponents.MAX_STACK_SIZE, _value));
		}
		if (event instanceof ModifyDefaultComponentsEvent _modComponent11) {
			final int _value = 16;
			_modComponent11.modify((PotionContents.createItemStack(Items.LINGERING_POTION, MeritocraftModPotions.MELON_JUICE_BOTTLE_LONG)).getItem(), builder -> builder.set(DataComponents.MAX_STACK_SIZE, _value));
		}
	}
}