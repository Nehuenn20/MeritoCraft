package net.mcreator.meritocraft.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.meritocraft.network.MeritocraftModVariables;

public class HintCondition6Procedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		if ((entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).adv6).equals("???")) {
			return true;
		}
		return false;
	}
}