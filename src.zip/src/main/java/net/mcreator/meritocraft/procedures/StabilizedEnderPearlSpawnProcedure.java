package net.mcreator.meritocraft.procedures;

import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.entity.projectile.throwableitemprojectile.ThrownEnderpearl;
import net.minecraft.world.entity.Entity;

import javax.annotation.Nullable;

@EventBusSubscriber
public class StabilizedEnderPearlSpawnProcedure {
	@SubscribeEvent
	public static void onEntitySpawned(EntityJoinLevelEvent event) {
		execute(event, event.getEntity());
	}

	public static void execute(Entity entity) {
		execute(null, entity);
	}

	private static void execute(@Nullable Event event, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof ThrownEnderpearl) {// 1. Usamos la ruta unificada para ThrownEnderpearl en MCreator 2026.2
			if (entity instanceof net.minecraft.world.entity.projectile.throwableitemprojectile.ThrownEnderpearl _pearl) {
				net.minecraft.world.entity.Entity _owner = _pearl.getOwner();
				if (_owner instanceof net.minecraft.world.entity.LivingEntity _livingOwner) {
					// 2. ¡La gran corrección!: En 1.21.8 ResourceLocation ahora se llama Identifier de forma nativa
					net.minecraft.resources.Identifier _itemKey = net.minecraft.resources.Identifier.fromNamespaceAndPath("meritocraft", "stabilized_ender_pearl");
					net.minecraft.world.item.Item _myPearl = net.minecraft.core.registries.BuiltInRegistries.ITEM.get(_itemKey).map(net.minecraft.core.Holder::value).orElse(null);
					if (_myPearl != null) {
						net.minecraft.world.item.ItemStack _mainHand = _livingOwner.getMainHandItem();
						net.minecraft.world.item.ItemStack _offHand = _livingOwner.getOffhandItem();
						boolean _usedStabilized = false;
						if (_mainHand.is(_myPearl)) {
							_usedStabilized = true;
						} else if (_offHand.is(_myPearl) && _mainHand.isEmpty()) {
							_usedStabilized = true;
						}
						if (_usedStabilized) {
							// Seteamos el ítem modificado
							_pearl.setItem(new net.minecraft.world.item.ItemStack(_myPearl));
							// Guardamos la marca digital por String
							if (_pearl.getPersistentData() != null && _pearl.getUUID() != null) {
								_pearl.getPersistentData().putString("StabilizedPearlID", _pearl.getUUID().toString());
							}
						}
					}
				}
			}
		}
	}
}