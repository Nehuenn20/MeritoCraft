package net.mcreator.meritocraft.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.GameType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.permissions.LevelBasedPermissionSet;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.Identifier;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.advancements.AdvancementHolder;
import net.minecraft.ChatFormatting;

import net.mcreator.meritocraft.network.MeritocraftModVariables;
import net.mcreator.meritocraft.MeritocraftMod;

public class NoCreativeProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _plr0 && _plr0.gameMode() == GameType.CREATIVE || entity instanceof Player _plr1 && _plr1.gameMode() == GameType.SPECTATOR) {
			if (entity instanceof ServerPlayer _player)
				_player.setGameMode(GameType.ADVENTURE);
			{
				MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
				_vars.no_creative = true;
				_vars.markSyncDirty();
			}
			MeritocraftMod.queueServerWork(200, () -> {
				if (entity instanceof ServerPlayer _player)
					_player.setGameMode(GameType.SURVIVAL);
				{
					MeritocraftModVariables.PlayerVariables _vars = entity.getData(MeritocraftModVariables.PLAYER_VARIABLES);
					_vars.no_creative = false;
					_vars.markSyncDirty();
				}
			});
			for (int _i1 = 0; _i1 < Mth.nextInt(RandomSource.create(), 1, 10); _i1++) {
				if (entity instanceof ServerPlayer _player8)
					_player8.sendSystemMessage(Component.literal("Gei").withStyle(ChatFormatting.LIGHT_PURPLE), false);
			}
			if (entity instanceof ServerPlayer _player11)
				_player11.sendSystemMessage(Component.literal("Gei").withStyle(ChatFormatting.LIGHT_PURPLE), true);
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("meritocraft:ja_gei")), SoundSource.PLAYERS, 5, 1);
				} else {
					_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("meritocraft:ja_gei")), SoundSource.PLAYERS, 5, 1, false);
				}
			}
			{
				Entity _ent = entity;
				if (!_ent.level().isClientSide() && _ent.level().getServer() != null) {
					_ent.level().getServer().getCommands().performPrefixedCommand(
							new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, LevelBasedPermissionSet.OWNER, _ent.getName().getString(),
									_ent.getDisplayName(), _ent.level().getServer(), _ent),
							"give @s written_book[written_book_content={pages:[[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Gei\",\"bold\":true,\"color\":\"light_purple\"}]],[[{\"text\":\"Homosexual Gei\",\"bold\":true,\"underlined\":true,\"color\":\"light_purple\"}]]],title:Gei,author:\"Gein't\",generation:0},tooltip_display={hidden_components:[written_book_content]}]");
				}
			}
			if (entity instanceof ServerPlayer _player && _player.level() instanceof ServerLevel _level) {
				AdvancementHolder _adv = _level.getServer().getAdvancements().get(Identifier.parse("meritocraft:adv_gei"));
				if (_adv != null) {
					AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv);
					if (!_ap.isDone()) {
						for (String criteria : _ap.getRemainingCriteria())
							_player.getAdvancements().award(_adv, criteria);
					}
				}
			}
		}
	}
}