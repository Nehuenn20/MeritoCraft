package net.mcreator.meritocraft.procedures;

import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.Entity;
import net.minecraft.client.Minecraft;

import net.mcreator.meritocraft.network.MeritocraftModVariables;

import javax.annotation.Nullable;

import com.mojang.blaze3d.vertex.PoseStack;

@EventBusSubscriber(Dist.CLIENT)
public class LoSuponiaProcedure {
	@SubscribeEvent
	public static void onSkyRendered(RenderLevelStageEvent.AfterSky event) {
		Minecraft mc = Minecraft.getInstance();
		execute(event, mc.player.level(), mc.player, event.getPoseStack(), event);
	}

	public static void execute(LevelAccessor world, Entity entity, PoseStack poseStack, RenderLevelStageEvent.AfterSky skyRenderEvent) {
		execute(null, world, entity, poseStack, skyRenderEvent);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, Entity entity, PoseStack poseStack, RenderLevelStageEvent.AfterSky skyRenderEvent) {
		if (entity == null || poseStack == null || skyRenderEvent == null)
			return;
		if (entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).chat_block > 0 || entity.getData(MeritocraftModVariables.PLAYER_VARIABLES).no_creative) {
			poseStack.pushPose();
			if (Math.round((world instanceof Level _level0 ? _level0.getDefaultClockTime() : 0) % 24000) < 6000) {
			} else {
			}
			if (Math.round((world instanceof Level _level1 ? _level1.getDefaultClockTime() : 0) % 24000) < 18000) {
			} else {
			}
			poseStack.popPose();
		} else {
		}
	}
}