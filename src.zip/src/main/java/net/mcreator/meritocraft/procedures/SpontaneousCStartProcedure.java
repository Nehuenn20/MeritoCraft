package net.mcreator.meritocraft.procedures;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.permissions.LevelBasedPermissionSet;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.mcreator.meritocraft.init.MeritocraftModMobEffects;

public class SpontaneousCStartProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		entity.igniteForSeconds(
				(int) Math.ceil((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(MeritocraftModMobEffects.SPONTANEOUS_COMBUSTION) ? _livEnt.getEffect(MeritocraftModMobEffects.SPONTANEOUS_COMBUSTION).getDuration() : 0) / 20d));
		if (entity instanceof ServerPlayer _player)
			_player.sendSystemMessage(
					Component.literal("Est\u00E1 a punto de suceder una combusti\u00F3n espont\u00E1nea, todos los \u00EDtems en tu inventario se quemar\u00E1n junto a t\u00ED \u00A1TIRALOS R\u00C1PIDO o USA POCI\u00D3N DE RESISTENCIA AL FUEGO!"),
					false);
		{
			Entity _ent = entity;
			if (!_ent.level().isClientSide() && _ent.level().getServer() != null) {
				_ent.level().getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null,
						LevelBasedPermissionSet.OWNER, _ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent), "title @s title [{\"text\":\"\"}]");
			}
		}
		{
			Entity _ent = entity;
			if (!_ent.level().isClientSide() && _ent.level().getServer() != null) {
				_ent.level().getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null,
						LevelBasedPermissionSet.OWNER, _ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent), "title @s subtitle [{\"text\":\"\u00A1Combusti\u00F3n espont\u00E1nea!\",\"color\":\"#ce740d\"}]");
			}
		}
	}
}