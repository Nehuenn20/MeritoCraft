package net.mcreator.meritocraft.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.tags.TagKey;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.Registries;

public class LeptospirosisEndProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity.is(TagKey.create(Registries.ENTITY_TYPE, Identifier.parse("meritocraft:leptospirosis"))) || entity instanceof Player) {
			if (entity instanceof LivingEntity _entity) {
				_entity.getAttribute(Attributes.MOVEMENT_SPEED).removeModifier(Identifier.parse("meritocraft:leptospirosis"));
			}
			if (entity instanceof LivingEntity _entity) {
				_entity.getAttribute(Attributes.JUMP_STRENGTH).removeModifier(Identifier.parse("meritocraft:leptospirosis"));
			}
			if (entity instanceof Player) {
				if (entity instanceof LivingEntity _entity) {
					_entity.getAttribute(Attributes.ATTACK_SPEED).removeModifier(Identifier.parse("meritocraft:leptospirosis"));
				}
			}
		}
	}
}