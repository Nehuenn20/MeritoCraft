package net.mcreator.meritocraft.procedures;

import net.neoforged.neoforge.event.entity.EntityTeleportEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import javax.annotation.Nullable;

@EventBusSubscriber
public class StabilizedEnderPearlDamageProcedure {
	@SubscribeEvent
	public static void onEntityTeleportation(EntityTeleportEvent event) {
		execute(event);
	}

	public static void execute() {
		execute(null);
	}

	private static void execute(@Nullable Event event) {
		if (event instanceof net.neoforged.neoforge.event.entity.EntityTeleportEvent.EnderPearl _teleportEvent) {
			// Adaptamos el casteo del proyectil a la nueva ruta de paquete unificada
			if (_teleportEvent.getPearlEntity() instanceof net.minecraft.world.entity.projectile.throwableitemprojectile.ThrownEnderpearl _pearl) {
				if (_pearl != null && _pearl.getPersistentData() != null && _pearl.getPersistentData().contains("StabilizedPearlID")) {
					// Apagamos el daño de raíz
					_teleportEvent.setAttackDamage(0.0F);
				}
			}
		}
	}
}