package net.mcreator.meritocraft.procedures;

import net.neoforged.neoforge.event.entity.EntityTeleportEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import javax.annotation.Nullable;

@EventBusSubscriber
public class StabilizedEnderPearlDamageProcedure {
	@SubscribeEvent
	public static void onEntityTeleportation(EntityTeleportEvent event) {
		execute(event);
	}

	public static void execute() {
		execute(null);
	}

	private static void execute(@Nullable Event event) {
		// 1. Forzamos a Java a interpretar el evento en el formato de teletransporte de NeoForge
		if (event instanceof net.neoforged.neoforge.event.entity.EntityTeleportEvent.EnderPearl _teleportEvent) {
			// 2. Extraemos la entidad de la perla que está causando el viaje en este preciso instante
			net.minecraft.world.entity.projectile.ThrownEnderpearl _pearl = _teleportEvent.getPearlEntity();
			// 3. Verificamos si la perla contiene la marca String de tu perla modificada
			if (_pearl != null && _pearl.getPersistentData() != null && _pearl.getPersistentData().contains("StabilizedPearlID")) {
				// 4. ¡Apagamos el daño de raíz! Le seteamos el daño por teletransporte a cero (0.0F)
				_teleportEvent.setAttackDamage(0.0F);
			}
		}
	}
}