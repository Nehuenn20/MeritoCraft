package net.mcreator.meritocraft.procedures;

import net.neoforged.neoforge.transfer.transaction.Transaction;
import net.neoforged.neoforge.transfer.item.ItemUtil;
import net.neoforged.neoforge.transfer.item.ItemResource;
import net.neoforged.neoforge.transfer.ResourceHandler;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.Entity;
import net.minecraft.tags.TagKey;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.BlockPos;

import net.mcreator.meritocraft.init.MeritocraftModItems;

import javax.annotation.Nullable;

@EventBusSubscriber
public class BoilingWaterBucketProcedure {
	@SubscribeEvent
	public static void onPlayerTick(PlayerTickEvent.Post event) {
		execute(event, event.getEntity().level(), event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getEntity());
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		execute(null, world, x, y, z, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		double slot = 0;
		if (world instanceof Level _lvl0 && _lvl0.isBrightOutside()
				&& (world.getBiome(BlockPos.containing(x, y, z)).is(Identifier.parse("desert")) || world.getBiome(BlockPos.containing(x, y, z)).is(TagKey.create(Registries.BIOME, Identifier.parse("minecraft:is_badlands"))))) {
			if (entity.getCapability(Capabilities.Item.ENTITY, null) instanceof ResourceHandler<ItemResource> _resourceHandlerIter) {
				for (int _idx = 0; _idx < _resourceHandlerIter.size(); _idx++) {
					ItemStack itemstackiterator = ItemUtil.getStack(_resourceHandlerIter, _idx);
					if (itemstackiterator.getItem() == Items.WATER_BUCKET) {
						if (entity.getCapability(Capabilities.Item.ENTITY, null) instanceof ResourceHandler<ItemResource> _resourceHandler) {
							setStackInSlot(_resourceHandler, (int) slot, ItemResource.of(new ItemStack(MeritocraftModItems.BOILED_WATER_BUCKET.get())), 1);
						}
					}
					slot = slot + 1;
				}
			}
		} else if (world.getBiome(BlockPos.containing(x, y, z)).is(TagKey.create(Registries.BIOME, Identifier.parse("minecraft:is_nether")))) {
			if (entity.getCapability(Capabilities.Item.ENTITY, null) instanceof ResourceHandler<ItemResource> _resourceHandlerIter) {
				for (int _idx = 0; _idx < _resourceHandlerIter.size(); _idx++) {
					ItemStack itemstackiterator = ItemUtil.getStack(_resourceHandlerIter, _idx);
					if (itemstackiterator.getItem() == Items.WATER_BUCKET || itemstackiterator.getItem() == MeritocraftModItems.BOILED_WATER_BUCKET.get() || itemstackiterator.getItem() == Items.MILK_BUCKET) {
						if (entity.getCapability(Capabilities.Item.ENTITY, null) instanceof ResourceHandler<ItemResource> _resourceHandler) {
							setStackInSlot(_resourceHandler, (int) slot, ItemResource.of(new ItemStack(Items.BUCKET)), 1);
						}
					}
					slot = slot + 1;
				}
			}
		} else {
			if (entity.getCapability(Capabilities.Item.ENTITY, null) instanceof ResourceHandler<ItemResource> _resourceHandlerIter) {
				for (int _idx = 0; _idx < _resourceHandlerIter.size(); _idx++) {
					ItemStack itemstackiterator = ItemUtil.getStack(_resourceHandlerIter, _idx);
					if (itemstackiterator.getItem() == MeritocraftModItems.BOILED_WATER_BUCKET.get()) {
						if (entity.getCapability(Capabilities.Item.ENTITY, null) instanceof ResourceHandler<ItemResource> _resourceHandler) {
							setStackInSlot(_resourceHandler, (int) slot, ItemResource.of(new ItemStack(Items.WATER_BUCKET)), 1);
						}
					}
					slot = slot + 1;
				}
			}
		}
	}

	private static void setStackInSlot(ResourceHandler<ItemResource> handler, int index, ItemResource resource, int amount) {
		try (var tx = Transaction.openRoot()) {
			if (!handler.getResource(index).isEmpty())
				handler.extract(index, handler.getResource(index), handler.getAmountAsInt(index), tx);
			if (!resource.isEmpty() && amount > 0)
				handler.insert(index, resource, amount, tx);
			tx.commit();
		}
	}
}