package net.mcreator.meritocraft.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.animal.equine.ZombieHorse;
import net.minecraft.world.entity.animal.equine.Horse;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.resources.Identifier;
import net.minecraft.network.chat.Component;

import java.util.Comparator;

public class AsthmaEndsProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof LivingEntity _entity) {
			_entity.getAttribute(Attributes.MOVEMENT_SPEED).removeModifier(Identifier.parse("meritocraft:asthma"));
		}
		if (entity instanceof Player) {
			entity.getPersistentData().putDouble("asthmalevel", 0);
			if (entity instanceof ServerPlayer _player)
				_player.sendSystemMessage(Component.literal("El ataque de asma ha cesado"), true);
		}
		if ((entity instanceof Horse || entity instanceof ZombieHorse) && entity instanceof LivingEntity _livingEntity6 && _livingEntity6.getAttribute(Attributes.MOVEMENT_SPEED).hasModifier(Identifier.parse("meritocraft:asthma.base"))) {
			if ((findEntityInWorldRange(world, Player.class, x, y, z, 4)) instanceof ServerPlayer _player)
				_player.sendSystemMessage(Component.literal("El ataque de asma de tu caballo ha cesado"), true);
		}
	}

	private static Entity findEntityInWorldRange(LevelAccessor world, Class<? extends Entity> clazz, double x, double y, double z, double range) {
		return (Entity) world.getEntitiesOfClass(clazz, AABB.ofSize(new Vec3(x, y, z), range, range, range), e -> true).stream().sorted(Comparator.comparingDouble(e -> e.distanceToSqr(x, y, z))).findFirst().orElse(null);
	}
}