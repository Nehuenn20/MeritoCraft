package net.mcreator.meritocraft.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.network.chat.Component;

import net.mcreator.meritocraft.init.MeritocraftModMobEffects;

public class SpontaneousCTickProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(
					Component.literal(("Combusti\u00F3n espont\u00E1nea en: " + (new java.text.DecimalFormat("##").format(
							Math.round((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(MeritocraftModMobEffects.SPONTANEOUS_COMBUSTION) ? _livEnt.getEffect(MeritocraftModMobEffects.SPONTANEOUS_COMBUSTION).getDuration() : 0) / 20d))))),
					true);
		if (entity instanceof LivingEntity _livEnt2 && _livEnt2.hasEffect(MobEffects.FIRE_RESISTANCE) || entity.fireImmune()) {
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MeritocraftModMobEffects.SPONTANEOUS_COMBUSTION);
			entity.clearFire();
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal(""), true);
		}
	}
}